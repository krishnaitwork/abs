import * as vscode from 'vscode';
import { EnhancedCommandHandler } from './commands/EnhancedCommandHandler';
import { InlineDiffCommands } from './commands/InlineDiffCommands';
import { KPCopilotMode } from './modes/CopilotMode';
import { ProviderManager } from './providers/ProviderManager';
import { KPStatusBarManager } from './utils/StatusBarManager';
import { DiffChatPanel } from './webviews/DiffChatPanel';
import { KPChatPanel } from './webviews/KPChatPanel';
import { KPSettingsPanel } from './webviews/KPSettingsPanel';
import { KPSidebarProvider } from './webviews/KPSidebarProvider';

export function activate(context: vscode.ExtensionContext) {
  // Initialize Provider Manager
  const providerManager = ProviderManager.getInstance(context.secrets);

  // Initialize KP AI Status Bar
  const statusBarManager = new KPStatusBarManager(providerManager);
  context.subscriptions.push(statusBarManager);

  // Initialize Enhanced Command Handler
  const commandHandler = new EnhancedCommandHandler(providerManager);
  context.subscriptions.push(commandHandler);

  // Initialize Inline Diff Commands
  const inlineDiffCommands = new InlineDiffCommands(providerManager, context.extensionUri);
  context.subscriptions.push(inlineDiffCommands);

  // Initialize Copilot Mode (inline completions)
  const copilotMode = new KPCopilotMode(providerManager);
  context.subscriptions.push(copilotMode.register(context));

  // Register Sidebar Provider for true sidebar chat
  const sidebarProvider = new KPSidebarProvider(context.extensionUri, providerManager);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(KPSidebarProvider.viewType, sidebarProvider)
  );

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.toggleChat', () => {
      KPChatPanel.createOrShow(context.extensionUri, providerManager);
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.showModelSelector', () => {
      statusBarManager.showModelSelector();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.explainCode', () => {
      commandHandler.explainCode();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.generateTests', () => {
      commandHandler.generateTests();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.refactorCode', () => {
      commandHandler.refactorCode();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.fixErrors', () => {
      commandHandler.fixErrors();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.generateDocs', () => {
      commandHandler.generateDocs();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.generateFunctionFromComment', () => {
      commandHandler.generateFunctionFromComment();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.startAgent', () => {
      commandHandler.startAgent();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.stopAgent', () => {
      commandHandler.stopAgent();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.openSettings', () => {
      KPSettingsPanel.createOrShow(context.extensionUri, providerManager);
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kp-ai-coding-assistant.showSettings', () => {
      KPSettingsPanel.createOrShow(context.extensionUri, providerManager);
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.switchChatLocation', async () => {
      const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
      const currentLocation = config.get<string>('chatLocation', 'beside');

      const options = [
        { label: '📌 Right Panel', description: 'Open chat in right panel (recommended - files open in left)', value: 'beside' },
        { label: '🔧 Sidebar Panel', description: 'Open chat in dedicated sidebar (true extension panel)', value: 'sidebar' },
        { label: '📄 Editor Tab', description: 'Open chat as an editor tab (mixed with code files)', value: 'editor' }
      ];

      const selection = await vscode.window.showQuickPick(
        options.filter(option => option.value !== currentLocation),
        {
          placeHolder: 'Choose where to open the KP AI chat panel',
          title: 'KP AI Chat Location'
        }
      );

      if (selection) {
        await config.update('chatLocation', selection.value, vscode.ConfigurationTarget.Workspace);
        vscode.window.showInformationMessage(`KP AI: Chat location changed to ${selection.label}. Reopen chat to see the change.`);

        // Close current chat panel so it reopens in the new location
        if (KPChatPanel.currentPanel) {
          KPChatPanel.currentPanel.dispose();
        }
      }
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.acceptCompletion', (completion: string) => {
      const editor = vscode.window.activeTextEditor;
      if (editor) {
        editor.edit(editBuilder => {
          editBuilder.insert(editor.selection.active, completion);
        });
      }
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.clearCompletionCache', () => {
      copilotMode.clearCache();
      vscode.window.showInformationMessage('KP AI: Completion cache cleared');
    })
  );

  // Register Inline Diff Commands
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.showInlineDiff', () => {
      inlineDiffCommands.showInlineDiff();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.showDiffBetweenSelections', () => {
      inlineDiffCommands.showDiffBetweenSelections();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.applyCurrentDiff', () => {
      inlineDiffCommands.applyCurrentDiff();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.applySingleChange', () => {
      inlineDiffCommands.applySingleChange();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.rejectCurrentDiff', () => {
      inlineDiffCommands.rejectCurrentDiff();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.navigateToNextChange', () => {
      inlineDiffCommands.navigateToNextChange();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.navigateToPreviousChange', () => {
      inlineDiffCommands.navigateToPreviousChange();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.showDiffHistory', () => {
      inlineDiffCommands.showDiffHistory();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.clearDiffHistory', () => {
      inlineDiffCommands.clearDiffHistory();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.revertToPreviousDiff', () => {
      inlineDiffCommands.revertToPreviousDiff();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.showDiffSettings', () => {
      inlineDiffCommands.showDiffSettings();
    })
  );
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.testDiffChat', () => {
      // Create a test diff for demonstration
      const testDiff: any = {
        changes: [
          {
            type: 'insert' as const,
            range: { startLine: 0, endLine: 0, startCharacter: 0, endCharacter: 0 },
            content: '// Improved comment',
            description: 'Add better documentation',
            severity: 'info'
          },
          {
            type: 'replace' as const,
            range: { startLine: 1, endLine: 1, startCharacter: 0, endCharacter: 10 },
            originalContent: 'function test',
            content: 'function improvedTest',
            description: 'Improve function name',
            severity: 'info'
          }
        ],
        summary: '2 improvements made',
        canApply: true,
        source: 'ai'
      };
      
      DiffChatPanel.createOrShow(context.extensionUri, testDiff, 'test.js');
    })
  );

  // Add a simple test command to verify our custom diff works
  context.subscriptions.push(
    vscode.commands.registerCommand('kpAiAssistant.testCustomDiff', () => {
      vscode.window.showInformationMessage('KP AI: Testing custom diff command - use Ctrl+Shift+D instead of built-in AI');
      
      // Show a simple test diff
      const testDiff: any = {
        changes: [
          {
            type: 'replace' as const,
            range: { startLine: 0, endLine: 0, startCharacter: 0, endCharacter: 10 },
            originalContent: 'function old',
            content: 'function new',
            description: 'Test function rename',
            severity: 'info'
          }
        ],
        summary: '1 test change',
        canApply: true,
        source: 'test'
      };
      
      DiffChatPanel.createOrShow(context.extensionUri, testDiff, 'test.js');
    })
  );
}

export function deactivate() { }
