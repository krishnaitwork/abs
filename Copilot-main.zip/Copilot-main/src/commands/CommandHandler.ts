import * as vscode from 'vscode';
import { KPAgentMode } from '../modes/AgentMode';
import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';

export class KPCommandHandler {
  private providerManager: ProviderManager;
  private agentMode: KPAgentMode;
  private providerFactory: ProviderFactory;

  constructor(providerManager: ProviderManager) {
    this.providerManager = providerManager;
    this.agentMode = new KPAgentMode(providerManager);
    this.providerFactory = ProviderFactory.getInstance(providerManager);
  }

  public async explainCode(): Promise<void> {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage('KP AI: No active editor');
      return;
    }

    const selection = editor.selection;
    if (selection.isEmpty) {
      vscode.window.showInformationMessage('KP AI: Please select code to explain');
      return;
    }

    const code = editor.document.getText(selection);
    const language = editor.document.languageId;

    const explanation = await this.getAIResponse(
      `Explain this ${language} code in detail:\n\n\`\`\`${language}\n${code}\n\`\`\``,
      'You are KP AI, a coding assistant. Explain code clearly and provide insights about how it works, potential improvements, and best practices.'
    );

    this.showResponseInNewDocument(explanation, 'KP AI Code Explanation', 'markdown');
  }

  public async generateTests(): Promise<void> {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage('KP AI: No active editor');
      return;
    }

    const selection = editor.selection;
    const code = selection.isEmpty ?
      editor.document.getText() :
      editor.document.getText(selection);

    const language = editor.document.languageId;
    const fileName = editor.document.fileName;

    // Determine test framework based on language and project
    const testFramework = await this.detectTestFramework(language);

    const prompt = `Generate comprehensive unit tests for this ${language} code using ${testFramework}:

File: ${fileName}
\`\`\`${language}
${code}
\`\`\`

Include:
- Test cases for normal functionality
- Edge cases and error handling
- Mock dependencies if needed
- Clear test descriptions

Generate complete, runnable test code.`;

    const tests = await this.getAIResponse(
      prompt,
      'You are KP AI, a testing expert. Generate thorough, well-structured unit tests with clear descriptions and comprehensive coverage.'
    );

    // Create test file
    const testFileName = this.generateTestFileName(fileName, language);
    this.createNewFile(testFileName, tests);
  }

  public async refactorCode(): Promise<void> {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage('KP AI: No active editor');
      return;
    }

    const selection = editor.selection;
    if (selection.isEmpty) {
      vscode.window.showInformationMessage('KP AI: Please select code to refactor');
      return;
    }

    const code = editor.document.getText(selection);
    const language = editor.document.languageId;

    const prompt = `Refactor this ${language} code to improve:
- Readability and maintainability
- Performance
- Code organization
- Best practices adherence
- Error handling

Original code:
\`\`\`${language}
${code}
\`\`\`

Provide the refactored code with explanations of changes made.`;

    const refactoredCode = await this.getAIResponse(
      prompt,
      'You are KP AI, a refactoring expert. Improve code quality while maintaining functionality. Explain your changes clearly.'
    );

    // Show diff-like comparison
    this.showResponseInNewDocument(
      `# KP AI Code Refactoring\n\n## Original Code\n\`\`\`${language}\n${code}\n\`\`\`\n\n## Refactored Code\n${refactoredCode}`,
      'KP AI Refactoring Suggestions',
      'markdown'
    );
  }

  public async fixErrors(): Promise<void> {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage('KP AI: No active editor');
      return;
    }

    // Get diagnostics (errors/warnings) for current file
    const diagnostics = vscode.languages.getDiagnostics(editor.document.uri);

    if (diagnostics.length === 0) {
      vscode.window.showInformationMessage('KP AI: No errors found in current file');
      return;
    }

    const code = editor.document.getText();
    const language = editor.document.languageId;

    // Format diagnostics for AI
    const errorInfo = diagnostics.map(diag =>
      `Line ${diag.range.start.line + 1}: ${diag.message} (${diag.severity === 0 ? 'Error' : 'Warning'})`
    ).join('\n');

    const prompt = `Fix the errors and warnings in this ${language} code:

Code:
\`\`\`${language}
${code}
\`\`\`

Errors/Warnings:
${errorInfo}

Provide the corrected code with explanations of fixes applied.`;

    const fixedCode = await this.getAIResponse(
      prompt,
      'You are KP AI, a debugging expert. Fix code errors while maintaining functionality and explain your solutions clearly.'
    );

    this.showResponseInNewDocument(
      `# KP AI Error Fixes\n\n## Issues Found\n${errorInfo}\n\n## Fixed Code\n${fixedCode}`,
      'KP AI Error Fixes',
      'markdown'
    );
  }

  public async generateDocs(): Promise<void> {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage('KP AI: No active editor');
      return;
    }

    const selection = editor.selection;
    const code = selection.isEmpty ?
      editor.document.getText() :
      editor.document.getText(selection);

    const language = editor.document.languageId;
    const fileName = editor.document.fileName;

    const prompt = `Generate comprehensive documentation for this ${language} code:

File: ${fileName}
\`\`\`${language}
${code}
\`\`\`

Include:
- Function/method documentation with parameters and return values
- Class documentation
- Usage examples
- API documentation if applicable
- README sections if this is a full file

Use appropriate documentation format for ${language} (JSDoc, docstrings, etc.).`;

    const documentation = await this.getAIResponse(
      prompt,
      'You are KP AI, a documentation expert. Generate clear, comprehensive documentation following best practices for the given language.'
    );

    this.showResponseInNewDocument(documentation, 'KP AI Generated Documentation', 'markdown');
  }

  public async startAgent(): Promise<void> {
    const taskDescription = await vscode.window.showInputBox({
      prompt: 'KP AI Agent: Describe the task you want me to complete',
      placeHolder: 'e.g., Create a React component with tests and documentation',
      ignoreFocusOut: true
    });

    if (!taskDescription) {
      return;
    }

    try {
      vscode.window.showInformationMessage('KP AI Agent: Starting task execution...');
      await this.agentMode.startTask(taskDescription);
    } catch (error) {
      vscode.window.showErrorMessage(`KP AI Agent: ${error}`);
    }
  }

  public stopAgent(): void {
    this.agentMode.stopCurrentTask();
    vscode.window.showInformationMessage('KP AI Agent: Task stopped');
  }

  private async getAIResponse(prompt: string, systemMessage: string): Promise<string> {
    try {
      const response = await this.providerFactory.createCompletion({
        messages: [
          {
            id: 'system',
            role: 'system',
            content: systemMessage,
            timestamp: new Date()
          },
          {
            id: 'user',
            role: 'user',
            content: prompt,
            timestamp: new Date()
          }
        ],
        model: this.providerManager.getCurrentModel(),
        maxTokens: 2048,
        temperature: 0.3
      });

      return response.content;
    } catch (error) {
      throw new Error(`AI request failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async detectTestFramework(language: string): Promise<string> {
    // Simple detection based on package.json or common files
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    if (!workspaceFolder) {
      return this.getDefaultTestFramework(language);
    }

    try {
      const packageJsonUri = vscode.Uri.joinPath(workspaceFolder.uri, 'package.json');
      const packageJson = JSON.parse(
        Buffer.from(await vscode.workspace.fs.readFile(packageJsonUri)).toString()
      );

      const dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };

      if (dependencies.jest) return 'Jest';
      if (dependencies.mocha) return 'Mocha';
      if (dependencies.vitest) return 'Vitest';
      if (dependencies['@testing-library/react']) return 'React Testing Library with Jest';

    } catch (error) {
      // File doesn't exist or can't be parsed
    }

    return this.getDefaultTestFramework(language);
  }

  private getDefaultTestFramework(language: string): string {
    switch (language) {
      case 'javascript':
      case 'typescript':
      case 'javascriptreact':
      case 'typescriptreact':
        return 'Jest';
      case 'python':
        return 'pytest';
      case 'java':
        return 'JUnit 5';
      case 'csharp':
        return 'xUnit';
      case 'go':
        return 'Go testing package';
      case 'rust':
        return 'Rust built-in testing';
      default:
        return 'appropriate testing framework';
    }
  }

  private generateTestFileName(originalFile: string, language: string): string {
    const ext = originalFile.split('.').pop();
    const nameWithoutExt = originalFile.replace(`.${ext}`, '');

    switch (language) {
      case 'javascript':
      case 'typescript':
        return `${nameWithoutExt}.test.${ext}`;
      case 'python':
        return `test_${originalFile.split('/').pop()}`;
      case 'java':
        return `${nameWithoutExt}Test.java`;
      default:
        return `${nameWithoutExt}_test.${ext}`;
    }
  }

  private async showResponseInNewDocument(content: string, title: string, language: string = 'plaintext'): Promise<void> {
    const doc = await vscode.workspace.openTextDocument({
      content: content,
      language: language
    });

    const editor = await vscode.window.showTextDocument(doc);

    // Set title in tab (VS Code will show this as untitled with content)
    vscode.window.showInformationMessage(`KP AI: ${title} generated`);
  }

  private async createNewFile(fileName: string, content: string): Promise<void> {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
    if (!workspaceFolder) {
      await this.showResponseInNewDocument(content, fileName);
      return;
    }

    const fileUri = vscode.Uri.joinPath(workspaceFolder.uri, fileName);
    await vscode.workspace.fs.writeFile(fileUri, Buffer.from(content, 'utf8'));

    const doc = await vscode.workspace.openTextDocument(fileUri);
    await vscode.window.showTextDocument(doc);

    vscode.window.showInformationMessage(`KP AI: Created ${fileName}`);
  }

  public dispose(): void {
    this.agentMode.dispose();
  }
}
