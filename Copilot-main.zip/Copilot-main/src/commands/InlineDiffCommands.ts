import * as vscode from 'vscode';
import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';
import { DiffResult, InlineDiffOptions } from '../types';
import { DiffManager } from '../utils/DiffManager';
import { DiffChatPanel } from '../webviews/DiffChatPanel';

export class InlineDiffCommands {
    private diffManager: DiffManager;
    private providerManager: ProviderManager;
    private providerFactory: ProviderFactory;
    private extensionUri: vscode.Uri;

    constructor(providerManager: ProviderManager, extensionUri?: vscode.Uri) {
        this.diffManager = new DiffManager();
        this.providerManager = providerManager;
        this.providerFactory = ProviderFactory.getInstance(providerManager);
        this.extensionUri = extensionUri || vscode.Uri.file(__dirname);
    }

    public async showInlineDiff(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('KP AI: No active editor');
            return;
        }

        const selection = editor.selection;
        if (selection.isEmpty) {
            vscode.window.showInformationMessage('KP AI: Please select code to show diff for');
            return;
        }

        const originalCode = editor.document.getText(selection);
        const language = editor.document.languageId;
        const fileName = editor.document.fileName.split('/').pop() || 'Unknown file';

        // Get AI suggestions for the selected code
        const prompt = `Improve this ${language} code. Provide only the improved code without explanations:

\`\`\`${language}
${originalCode}
\`\`\``;

        try {
            const response = await this.getAIResponse(prompt);
            const improvedCode = this.extractCodeFromResponse(response, language);

            console.log('KP AI Diff Debug - Original code:', originalCode);
            console.log('KP AI Diff Debug - Improved code:', improvedCode);
            console.log('KP AI Diff Debug - Selection start line:', selection.start.line);

            // Create diff
            const diffResult = await this.diffManager.createDiff(
                originalCode,
                improvedCode,
                `AI improvements for ${language} code`,
                'ai',
                selection.start.line
            );

            console.log('KP AI Diff Debug - Diff result:', diffResult);
            console.log('KP AI Diff Debug - Number of changes:', diffResult.changes.length);

            // Show diff summary in chat panel instead of inline decorations
            await this.showDiffSummaryInChat(fileName, diffResult, editor, selection);

            vscode.window.showInformationMessage(`KP AI: Generated diff with ${diffResult.changes.length} changes`);

        } catch (error) {
            console.error('KP AI Diff Error:', error);
            vscode.window.showErrorMessage(`KP AI: Failed to generate diff: ${error}`);
        }
    }

    public async showDiffBetweenSelections(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('KP AI: No active editor');
            return;
        }

        const selections = editor.selections;
        if (selections.length !== 2) {
            vscode.window.showInformationMessage('KP AI: Please select exactly 2 code blocks to compare');
            return;
        }

        const [firstSelection, secondSelection] = selections;
        const firstCode = editor.document.getText(firstSelection);
        const secondCode = editor.document.getText(secondSelection);

        // Create diff between two selections
        const diffResult = await this.diffManager.createDiff(
            firstCode,
            secondCode,
            'Comparison between two code selections',
            'manual',
            Math.min(firstSelection.start.line, secondSelection.start.line)
        );

        // Show diff summary in chat panel
        const fileName = editor.document.fileName.split('/').pop() || 'Unknown file';
        await this.showDiffSummaryInChat(fileName, diffResult, editor, firstSelection);
    }

    public async applyCurrentDiff(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('KP AI: No active editor');
            return;
        }

        const currentDiff = this.diffManager.getCurrentDiff();
        if (!currentDiff) {
            vscode.window.showInformationMessage('KP AI: No active diff to apply');
            return;
        }

        await this.diffManager.applyDiff(editor, currentDiff);
    }

    public async applySingleChange(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('KP AI: No active editor');
            return;
        }

        const currentDiff = this.diffManager.getCurrentDiff();
        if (!currentDiff) {
            vscode.window.showInformationMessage('KP AI: No active diff to apply');
            return;
        }

        // Get change at cursor position
        const position = editor.selection.active;
        const change = this.diffManager.getCurrentDiff()?.changes.find((_, index) => {
            // This is a simplified approach - in a real implementation you'd want more sophisticated change detection
            return index === 0; // Apply first change for now
        });

        if (change) {
            const changeIndex = currentDiff.changes.indexOf(change);
            await this.diffManager.applySingleChange(editor, changeIndex);
        } else {
            vscode.window.showInformationMessage('KP AI: No change found at current position');
        }
    }

    public async rejectCurrentDiff(): Promise<void> {
        await this.diffManager.rejectDiff();
    }

    public async navigateToNextChange(): Promise<void> {
        this.diffManager.navigateToNextChange();
    }

    public async navigateToPreviousChange(): Promise<void> {
        this.diffManager.navigateToPreviousChange();
    }

    public async showDiffHistory(): Promise<void> {
        const history = this.diffManager.getDiffHistory();
        
        if (history.length === 0) {
            vscode.window.showInformationMessage('KP AI: No diff history available');
            return;
        }

        const items = history.map((diff, index) => ({
            label: `Diff ${history.length - index}`,
            description: diff.summary,
            detail: `${diff.changes.length} changes - ${diff.source}`,
            diff: diff
        }));

        const selection = await vscode.window.showQuickPick(items, {
            placeHolder: 'Select a diff from history to view',
            title: 'KP AI Diff History'
        });

        if (selection) {
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                await this.diffManager.showDiff(editor, selection.diff);
            }
        }
    }

    public async clearDiffHistory(): Promise<void> {
        this.diffManager.clearHistory();
    }

    public async revertToPreviousDiff(): Promise<void> {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('KP AI: No active editor');
            return;
        }

        await this.diffManager.revertToPreviousDiff(editor);
    }

    public async showDiffSettings(): Promise<void> {
        const options = await this.getDiffOptions();
        
        const result = await vscode.window.showQuickPick([
            { label: 'Show Inline Changes', value: 'inline', checked: options.showInline },
            { label: 'Show Gutter Indicators', value: 'gutter', checked: options.showGutter },
            { label: 'Show Overview Ruler', value: 'overview', checked: options.showOverview },
            { label: 'Highlight Changes', value: 'highlight', checked: options.highlightChanges },
            { label: 'Auto-apply Changes', value: 'autoApply', checked: options.autoApply }
        ], {
            placeHolder: 'Configure diff display options',
            title: 'KP AI Diff Settings',
            canPickMany: true
        });

        if (result) {
            const newOptions: InlineDiffOptions = {
                showInline: result.some(r => r.value === 'inline'),
                showGutter: result.some(r => r.value === 'gutter'),
                showOverview: result.some(r => r.value === 'overview'),
                highlightChanges: result.some(r => r.value === 'highlight'),
                autoApply: result.some(r => r.value === 'autoApply')
            };

            // Update configuration
            const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
            await config.update('inlineDiffOptions', newOptions, vscode.ConfigurationTarget.Workspace);

            vscode.window.showInformationMessage('KP AI: Diff settings updated');
        }
    }

    private async getAIResponse(prompt: string): Promise<string> {
        try {
            // Use the existing AI provider system through ProviderFactory
            const response = await this.providerFactory.createCompletion({
                messages: [
                    {
                        id: 'system',
                        role: 'system',
                        content: 'You are KP AI, a coding assistant. Provide improved code without explanations, focusing on best practices, readability, and performance.',
                        timestamp: new Date()
                    },
                    {
                        id: 'user',
                        role: 'user',
                        content: prompt,
                        timestamp: new Date()
                    }
                ],
                model: this.providerManager.getCurrentModel(),
                maxTokens: 2048,
                temperature: 0.3
            });

            return response.content;
        } catch (error) {
            console.error('AI response error:', error);
            throw new Error(`Failed to get AI response: ${error}`);
        }
    }

    private extractCodeFromResponse(response: string, language: string): string {
        // Extract code blocks from AI response
        const codeBlockRegex = new RegExp(`\`\`\`${language}\\n([\\s\\S]*?)\\n\`\`\``);
        const match = response.match(codeBlockRegex);
        
        if (match && match[1]) {
            return match[1];
        }

        // If no code block found, return the response as-is
        return response;
    }

    private async getDiffOptions(): Promise<InlineDiffOptions> {
        const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
        const savedOptions = config.get<InlineDiffOptions>('inlineDiffOptions');
        
        if (savedOptions) {
            return savedOptions;
        }

        return {
            showInline: true,
            showGutter: true,
            showOverview: true,
            highlightChanges: true,
            autoApply: false
        };
    }

    private async showDiffSummaryInChat(fileName: string, diffResult: DiffResult, editor: vscode.TextEditor, selection: vscode.Selection): Promise<void> {
        // Show the diff summary in the DiffChatPanel
        DiffChatPanel.createOrShow(this.extensionUri, diffResult, fileName);
    }



    public dispose(): void {
        this.diffManager.dispose();
    }
}
