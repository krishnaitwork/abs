import * as vscode from 'vscode';
import { DiffChange, DiffResult, InlineDiffOptions } from '../types';

export class InlineDiffProvider {
    private decorations: Map<string, vscode.TextEditorDecorationType> = new Map();
    private currentDiff: DiffResult | null = null;
    private currentEditor: vscode.TextEditor | null = null;

    constructor() {
        this.initializeDecorations();
    }

    private initializeDecorations(): void {
        // Insert decoration (green background)
        this.decorations.set('insert', vscode.window.createTextEditorDecorationType({
            backgroundColor: new vscode.ThemeColor('diffEditor.insertedTextBackground'),
            border: '1px solid',
            borderColor: new vscode.ThemeColor('diffEditor.insertedTextBorder'),
            isWholeLine: false
        }));

        // Delete decoration (red background)
        this.decorations.set('delete', vscode.window.createTextEditorDecorationType({
            backgroundColor: new vscode.ThemeColor('diffEditor.removedTextBackground'),
            border: '1px solid',
            borderColor: new vscode.ThemeColor('diffEditor.removedTextBorder'),
            isWholeLine: false
        }));

        // Replace decoration (blue background)
        this.decorations.set('replace', vscode.window.createTextEditorDecorationType({
            backgroundColor: new vscode.ThemeColor('diffEditor.modifiedTextBackground'),
            border: '1px solid',
            borderColor: new vscode.ThemeColor('diffEditor.modifiedTextBorder'),
            isWholeLine: false
        }));

        // Gutter decorations - using string paths instead of ThemeIcon
        this.decorations.set('gutter-insert', vscode.window.createTextEditorDecorationType({
            gutterIconPath: '$(add)',
            gutterIconSize: 'contain'
        }));

        this.decorations.set('gutter-delete', vscode.window.createTextEditorDecorationType({
            gutterIconPath: '$(remove)',
            gutterIconSize: 'contain'
        }));

        this.decorations.set('gutter-replace', vscode.window.createTextEditorDecorationType({
            gutterIconPath: '$(edit)',
            gutterIconSize: 'contain'
        }));

        // Overview ruler decorations
        this.decorations.set('overview-insert', vscode.window.createTextEditorDecorationType({
            overviewRulerColor: new vscode.ThemeColor('diffEditor.insertedTextBackground'),
            overviewRulerLane: vscode.OverviewRulerLane.Right
        }));

        this.decorations.set('overview-delete', vscode.window.createTextEditorDecorationType({
            overviewRulerColor: new vscode.ThemeColor('diffEditor.removedTextBackground'),
            overviewRulerLane: vscode.OverviewRulerLane.Right
        }));

        this.decorations.set('overview-replace', vscode.window.createTextEditorDecorationType({
            overviewRulerColor: new vscode.ThemeColor('diffEditor.modifiedTextBackground'),
            overviewRulerLane: vscode.OverviewRulerLane.Right
        }));
    }

    public showDiff(editor: vscode.TextEditor, diffResult: DiffResult, options: InlineDiffOptions = this.getDefaultOptions()): void {
        console.log('InlineDiffProvider.showDiff - Starting with', diffResult.changes.length, 'changes');
        console.log('InlineDiffProvider.showDiff - Options:', options);
        
        this.currentDiff = diffResult;
        this.currentEditor = editor;
        this.clearDecorations();

        if (!options.showInline && !options.showGutter && !options.showOverview) {
            console.log('InlineDiffProvider.showDiff - No display options enabled, returning');
            return;
        }

        // Separate decorations by change type
        const insertDecorations: vscode.DecorationOptions[] = [];
        const deleteDecorations: vscode.DecorationOptions[] = [];
        const replaceDecorations: vscode.DecorationOptions[] = [];

        diffResult.changes.forEach((change, index) => {
            const range = this.createRange(change.range);
            const hoverMessage = this.createHoverMessage(change, index + 1);
            
            console.log(`InlineDiffProvider.showDiff - Change ${index}:`, {
                type: change.type,
                range: change.range,
                vsCodeRange: range,
                description: change.description
            });
            
            const decoration: vscode.DecorationOptions = {
                range,
                hoverMessage
            };

            switch (change.type) {
                case 'insert':
                    insertDecorations.push(decoration);
                    break;
                case 'delete':
                    deleteDecorations.push(decoration);
                    break;
                case 'replace':
                    replaceDecorations.push(decoration);
                    break;
            }
        });

        console.log('InlineDiffProvider.showDiff - Decoration counts:', {
            insert: insertDecorations.length,
            delete: deleteDecorations.length,
            replace: replaceDecorations.length
        });

        // Apply decorations directly
        if (options.showInline) {
            console.log('InlineDiffProvider.showDiff - Applying inline decorations');
            editor.setDecorations(this.decorations.get('insert')!, insertDecorations);
            editor.setDecorations(this.decorations.get('delete')!, deleteDecorations);
            editor.setDecorations(this.decorations.get('replace')!, replaceDecorations);
        }

        if (options.showGutter) {
            console.log('InlineDiffProvider.showDiff - Applying gutter decorations');
            editor.setDecorations(this.decorations.get('gutter-insert')!, insertDecorations);
            editor.setDecorations(this.decorations.get('gutter-delete')!, deleteDecorations);
            editor.setDecorations(this.decorations.get('gutter-replace')!, replaceDecorations);
        }

        if (options.showOverview) {
            console.log('InlineDiffProvider.showDiff - Applying overview decorations');
            editor.setDecorations(this.decorations.get('overview-insert')!, insertDecorations);
            editor.setDecorations(this.decorations.get('overview-delete')!, deleteDecorations);
            editor.setDecorations(this.decorations.get('overview-replace')!, replaceDecorations);
        }

        console.log('InlineDiffProvider.showDiff - Completed decoration application');
    }

    public clearDiff(): void {
        this.clearDecorations();
        this.currentDiff = null;
        this.currentEditor = null;
    }

    public getCurrentDiff(): DiffResult | null {
        return this.currentDiff;
    }

    public navigateToNextChange(): void {
        if (!this.currentDiff || !this.currentEditor) return;

        const activePosition = this.currentEditor.selection.active;
        const nextChange = this.currentDiff.changes.find(change => {
            const range = this.createRange(change.range);
            return range.start.isAfter(activePosition);
        });

        if (nextChange) {
            const range = this.createRange(nextChange.range);
            this.currentEditor.selection = new vscode.Selection(range.start, range.end);
            this.currentEditor.revealRange(range, vscode.TextEditorRevealType.InCenter);
        } else {
            // Wrap to first change
            const firstChange = this.currentDiff.changes[0];
            if (firstChange) {
                const range = this.createRange(firstChange.range);
                this.currentEditor.selection = new vscode.Selection(range.start, range.end);
                this.currentEditor.revealRange(range, vscode.TextEditorRevealType.InCenter);
            }
        }
    }

    public navigateToPreviousChange(): void {
        if (!this.currentDiff || !this.currentEditor) return;

        const activePosition = this.currentEditor.selection.active;
        const previousChange = this.currentDiff.changes.reverse().find(change => {
            const range = this.createRange(change.range);
            return range.start.isBefore(activePosition);
        });

        if (previousChange) {
            const range = this.createRange(previousChange.range);
            this.currentEditor.selection = new vscode.Selection(range.start, range.end);
            this.currentEditor.revealRange(range, vscode.TextEditorRevealType.InCenter);
        } else {
            // Wrap to last change
            const lastChange = this.currentDiff.changes[this.currentDiff.changes.length - 1];
            if (lastChange) {
                const range = this.createRange(lastChange.range);
                this.currentEditor.selection = new vscode.Selection(range.start, range.end);
                this.currentEditor.revealRange(range, vscode.TextEditorRevealType.InCenter);
            }
        }
    }

    public getChangeAtPosition(position: vscode.Position): DiffChange | null {
        if (!this.currentDiff) return null;

        return this.currentDiff.changes.find(change => {
            const range = this.createRange(change.range);
            return range.contains(position);
        }) || null;
    }

    private createRange(diffRange: any): vscode.Range {
        return new vscode.Range(
            diffRange.startLine,
            diffRange.startCharacter,
            diffRange.endLine,
            diffRange.endCharacter
        );
    }

    private createHoverMessage(change: DiffChange, index: number): vscode.MarkdownString {
        const markdown = new vscode.MarkdownString();
        markdown.appendMarkdown(`**${change.type.toUpperCase()}** (${index})\n\n`);
        markdown.appendMarkdown(`${change.description}\n\n`);
        
        if (change.originalContent) {
            markdown.appendMarkdown(`**Original:**\n\`\`\`\n${change.originalContent}\n\`\`\`\n\n`);
        }
        
        if (change.content) {
            markdown.appendMarkdown(`**New:**\n\`\`\`\n${change.content}\n\`\`\``);
        }

        return markdown;
    }



    private clearDecorations(): void {
        if (this.currentEditor) {
            this.decorations.forEach(decoration => {
                this.currentEditor!.setDecorations(decoration, []);
            });
        }
    }

    private getDefaultOptions(): InlineDiffOptions {
        return {
            showInline: true,
            showGutter: true,
            showOverview: true,
            highlightChanges: true,
            autoApply: false
        };
    }

    public dispose(): void {
        this.clearDecorations();
        this.decorations.forEach(decoration => decoration.dispose());
        this.decorations.clear();
    }
}
