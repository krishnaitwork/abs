import * as vscode from 'vscode';
import { DiffChange, DiffResult, InlineDiffOptions } from '../types';
import { InlineDiffProvider } from './InlineDiffProvider';

export class DiffManager {
    private inlineDiffProvider: InlineDiffProvider;
    private currentDiff: DiffResult | null = null;
    private diffHistory: DiffResult[] = [];
    private maxHistorySize = 10;

    constructor() {
        this.inlineDiffProvider = new InlineDiffProvider();
    }

    public async createDiff(
        originalText: string,
        newText: string,
        description: string,
        source: 'ai' | 'manual' | 'git' = 'ai',
        startLine: number = 0
    ): Promise<DiffResult> {
        const changes = this.computeDiff(originalText, newText, startLine);
        
        const diffResult: DiffResult = {
            changes,
            summary: this.generateSummary(changes),
            canApply: changes.length > 0,
            source
        };

        // Add to history
        this.addToHistory(diffResult);

        return diffResult;
    }

    public async showDiff(editor: vscode.TextEditor, diffResult: DiffResult, options?: InlineDiffOptions): Promise<void> {
        this.currentDiff = diffResult;
        this.inlineDiffProvider.showDiff(editor, diffResult, options);
        
        // Show diff summary in status bar
        this.showDiffSummary(diffResult);
    }

    public async applyDiff(editor: vscode.TextEditor, diffResult: DiffResult): Promise<boolean> {
        if (!diffResult.canApply || diffResult.changes.length === 0) {
            return false;
        }

        try {
            await editor.edit(editBuilder => {
                // Sort changes by position (reverse order to avoid position shifts)
                const sortedChanges = [...diffResult.changes].sort((a, b) => {
                    if (a.range.startLine !== b.range.startLine) {
                        return b.range.startLine - a.range.startLine;
                    }
                    return b.range.startCharacter - a.range.startCharacter;
                });

                sortedChanges.forEach(change => {
                    const range = new vscode.Range(
                        change.range.startLine,
                        change.range.startCharacter,
                        change.range.endLine,
                        change.range.endCharacter
                    );

                    switch (change.type) {
                        case 'insert':
                            if (change.content) {
                                editBuilder.insert(range.start, change.content);
                            }
                            break;
                        case 'delete':
                            editBuilder.delete(range);
                            break;
                        case 'replace':
                            if (change.content) {
                                editBuilder.replace(range, change.content);
                            }
                            break;
                    }
                });
            });

            // Clear the diff display
            this.inlineDiffProvider.clearDiff();
            this.currentDiff = null;

            vscode.window.showInformationMessage(`KP AI: Applied ${diffResult.changes.length} changes`);
            return true;

        } catch (error) {
            vscode.window.showErrorMessage(`KP AI: Failed to apply diff: ${error}`);
            return false;
        }
    }

    public async applySingleChange(editor: vscode.TextEditor, changeIndex: number): Promise<boolean> {
        if (!this.currentDiff || changeIndex < 0 || changeIndex >= this.currentDiff.changes.length) {
            return false;
        }

        const change = this.currentDiff.changes[changeIndex];
        
        try {
            await editor.edit(editBuilder => {
                const range = new vscode.Range(
                    change.range.startLine,
                    change.range.startCharacter,
                    change.range.endLine,
                    change.range.endCharacter
                );

                switch (change.type) {
                    case 'insert':
                        if (change.content) {
                            editBuilder.insert(range.start, change.content);
                        }
                        break;
                    case 'delete':
                        editBuilder.delete(range);
                        break;
                    case 'replace':
                        if (change.content) {
                            editBuilder.replace(range, change.content);
                        }
                        break;
                }
            });

            // Remove the applied change from the current diff
            this.currentDiff.changes.splice(changeIndex, 1);
            
            if (this.currentDiff.changes.length === 0) {
                this.inlineDiffProvider.clearDiff();
                this.currentDiff = null;
                vscode.window.showInformationMessage('KP AI: All changes applied');
            } else {
                // Refresh the diff display
                this.inlineDiffProvider.showDiff(editor, this.currentDiff);
                vscode.window.showInformationMessage(`KP AI: Applied change ${changeIndex + 1}`);
            }

            return true;

        } catch (error) {
            vscode.window.showErrorMessage(`KP AI: Failed to apply change: ${error}`);
            return false;
        }
    }

    public async rejectDiff(): Promise<void> {
        if (this.currentDiff) {
            this.inlineDiffProvider.clearDiff();
            this.currentDiff = null;
            vscode.window.showInformationMessage('KP AI: Diff rejected');
        }
    }

    public navigateToNextChange(): void {
        this.inlineDiffProvider.navigateToNextChange();
    }

    public navigateToPreviousChange(): void {
        this.inlineDiffProvider.navigateToPreviousChange();
    }

    public getCurrentDiff(): DiffResult | null {
        return this.currentDiff;
    }

    public getDiffHistory(): DiffResult[] {
        return [...this.diffHistory];
    }

    public clearHistory(): void {
        this.diffHistory = [];
        vscode.window.showInformationMessage('KP AI: Diff history cleared');
    }

    public async revertToPreviousDiff(editor: vscode.TextEditor): Promise<boolean> {
        if (this.diffHistory.length < 2) {
            vscode.window.showInformationMessage('KP AI: No previous diff to revert to');
            return false;
        }

        // Remove current diff from history
        this.diffHistory.pop();
        
        // Get the previous diff
        const previousDiff = this.diffHistory[this.diffHistory.length - 1];
        
        if (previousDiff) {
            await this.showDiff(editor, previousDiff);
            vscode.window.showInformationMessage('KP AI: Reverted to previous diff');
            return true;
        }

        return false;
    }

    private computeDiff(originalText: string, newText: string, startLine: number = 0): DiffChange[] {
        const changes: DiffChange[] = [];
        const originalLines = originalText.split('\n');
        const newLines = newText.split('\n');

        // Improved diff algorithm that handles similar lines better
        let i = 0, j = 0;
        
        while (i < originalLines.length || j < newLines.length) {
            if (i < originalLines.length && j < newLines.length) {
                if (originalLines[i] === newLines[j]) {
                    // Lines are identical, move to next
                    i++;
                    j++;
                } else {
                    // Lines are different - check if it's a replacement or separate insert/delete
                    const nextOriginalMatch = this.findNextMatch(originalLines, i + 1, newLines, j);
                    const nextNewMatch = this.findNextMatch(newLines, j + 1, originalLines, i);
                    
                    if (nextOriginalMatch !== -1 && nextNewMatch !== -1) {
                        // Both have matches ahead, treat as replacement
                        changes.push({
                            type: 'replace',
                            range: {
                                startLine: startLine + i,
                                endLine: startLine + i,
                                startCharacter: 0,
                                endCharacter: originalLines[i].length
                            },
                            originalContent: originalLines[i],
                            content: newLines[j],
                            description: `Replace line: ${originalLines[i].substring(0, 30)} → ${newLines[j].substring(0, 30)}${newLines[j].length > 30 ? '...' : ''}`,
                            severity: 'info'
                        });
                        i++;
                        j++;
                    } else if (nextOriginalMatch !== -1) {
                        // Original has match ahead, insert new line
                        changes.push({
                            type: 'insert',
                            range: {
                                startLine: startLine + i,
                                endLine: startLine + i,
                                startCharacter: 0,
                                endCharacter: 0
                            },
                            content: newLines[j],
                            description: `Insert line: ${newLines[j].substring(0, 50)}${newLines[j].length > 50 ? '...' : ''}`,
                            severity: 'info'
                        });
                        j++;
                    } else if (nextNewMatch !== -1) {
                        // New has match ahead, delete original line
                        changes.push({
                            type: 'delete',
                            range: {
                                startLine: startLine + i,
                                endLine: startLine + i,
                                startCharacter: 0,
                                endCharacter: originalLines[i].length
                            },
                            originalContent: originalLines[i],
                            description: `Delete line: ${originalLines[i].substring(0, 50)}${originalLines[i].length > 50 ? '...' : ''}`,
                            severity: 'info'
                        });
                        i++;
                    } else {
                        // No matches ahead, treat as replacement
                        changes.push({
                            type: 'replace',
                            range: {
                                startLine: startLine + i,
                                endLine: startLine + i,
                                startCharacter: 0,
                                endCharacter: originalLines[i].length
                            },
                            originalContent: originalLines[i],
                            content: newLines[j],
                            description: `Replace line: ${originalLines[i].substring(0, 30)} → ${newLines[j].substring(0, 30)}${newLines[j].length > 30 ? '...' : ''}`,
                            severity: 'info'
                        });
                        i++;
                        j++;
                    }
                }
            } else if (j < newLines.length) {
                // Insert remaining new lines
                changes.push({
                    type: 'insert',
                    range: {
                        startLine: startLine + i,
                        endLine: startLine + i,
                        startCharacter: 0,
                        endCharacter: 0
                    },
                    content: newLines[j],
                    description: `Insert line: ${newLines[j].substring(0, 50)}${newLines[j].length > 50 ? '...' : ''}`,
                    severity: 'info'
                });
                j++;
            } else if (i < originalLines.length) {
                // Delete remaining original lines
                changes.push({
                    type: 'delete',
                    range: {
                        startLine: startLine + i,
                        endLine: startLine + i,
                        startCharacter: 0,
                        endCharacter: originalLines[i].length
                    },
                    originalContent: originalLines[i],
                    description: `Delete line: ${originalLines[i].substring(0, 50)}${originalLines[i].length > 50 ? '...' : ''}`,
                    severity: 'info'
                });
                i++;
            }
        }

        return changes;
    }

    private findNextMatch(lines: string[], startIndex: number, targetLines: string[], targetStartIndex: number): number {
        for (let i = startIndex; i < lines.length; i++) {
            for (let j = targetStartIndex; j < targetLines.length; j++) {
                if (lines[i] === targetLines[j]) {
                    return i;
                }
            }
        }
        return -1;
    }

    private generateSummary(changes: DiffChange[]): string {
        const insertCount = changes.filter(c => c.type === 'insert').length;
        const deleteCount = changes.filter(c => c.type === 'delete').length;
        const replaceCount = changes.filter(c => c.type === 'replace').length;

        const parts = [];
        if (insertCount > 0) parts.push(`${insertCount} insertions`);
        if (deleteCount > 0) parts.push(`${deleteCount} deletions`);
        if (replaceCount > 0) parts.push(`${replaceCount} replacements`);

        return parts.join(', ') || 'No changes';
    }

    private addToHistory(diffResult: DiffResult): void {
        this.diffHistory.push(diffResult);
        
        // Limit history size
        if (this.diffHistory.length > this.maxHistorySize) {
            this.diffHistory.shift();
        }
    }

    private showDiffSummary(diffResult: DiffResult): void {
        const summary = `${diffResult.changes.length} changes - ${diffResult.summary}`;
        vscode.window.showInformationMessage(`KP AI: ${summary}`);
    }

    public dispose(): void {
        this.inlineDiffProvider.dispose();
    }
}
