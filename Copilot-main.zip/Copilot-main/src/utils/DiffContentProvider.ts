import * as vscode from 'vscode';

export const DIFF_SCHEME = 'kpai-diff';
let registered = false;
let disposable: vscode.Disposable | undefined;

export function ensureDiffContentProvider() {
  if (registered) {
    return;
  }
  const provider: vscode.TextDocumentContentProvider = {
    onDidChange: undefined,
    provideTextDocumentContent: (uri: vscode.Uri): string => {
      try {
        const query = uri.query || '';
        const params = new URLSearchParams(query);
        const data = params.get('data') || '';
        const decoded = Buffer.from(decodeURIComponent(data), 'base64').toString('utf-8');
        return decoded;
      } catch (e) {
        console.error('KP AI: Failed to provide diff content for', uri.toString(), e);
        return '';
      }
    }
  };
  disposable = vscode.workspace.registerTextDocumentContentProvider(DIFF_SCHEME, provider);
  registered = true;
}

export function disposeDiffContentProvider() {
  if (disposable) {
    disposable.dispose();
    disposable = undefined;
    registered = false;
  }
}
