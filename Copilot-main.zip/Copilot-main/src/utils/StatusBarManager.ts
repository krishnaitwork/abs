import * as vscode from 'vscode';
import { ProviderManager } from '../providers/ProviderManager';

export class KPStatusBarManager {
  private statusBarItem: vscode.StatusBarItem;
  private providerManager: ProviderManager;

  constructor(providerManager: ProviderManager) {
    this.providerManager = providerManager;
    this.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    this.setupStatusBar();
  }

  private setupStatusBar() {
    this.updateStatusBar();
    this.statusBarItem.command = 'kpAiAssistant.showModelSelector';
    this.statusBarItem.show();
  }

  public updateStatusBar() {
    const currentProvider = this.providerManager.getCurrentProvider();
    const currentModel = this.providerManager.getCurrentModel();
    const provider = this.providerManager.getProvider(currentProvider);
    
    if (provider) {
      this.statusBarItem.text = `KP: ${provider.displayName} (${currentModel})`;
      this.statusBarItem.tooltip = `KP AI Assistant - Current: ${provider.displayName} - ${currentModel}\nClick to change model`;
    } else {
      this.statusBarItem.text = 'KP AI: Not configured';
      this.statusBarItem.tooltip = 'KP AI Assistant - Click to configure';
    }
  }

  public async showModelSelector() {
    const providers = this.providerManager.getProviders();
    const items: vscode.QuickPickItem[] = [];

    for (const provider of providers) {
      const models = this.providerManager.getModelsForProvider(provider.name);
      for (const model of models) {
        items.push({
          label: `${provider.displayName} - ${model.name}`,
          description: `${model.contextLength} tokens`,
          detail: provider.isLocal ? 'Local model' : `Cost: $${model.costPer1KTokens}/1K tokens`,
          picked: provider.name === this.providerManager.getCurrentProvider() && 
                  model.id === this.providerManager.getCurrentModel()
        });
      }
    }

    const selected = await vscode.window.showQuickPick(items, {
      placeHolder: 'Select AI model for KP Assistant',
      title: 'KP AI Model Selector'
    });

    if (selected) {
      // Parse provider and model from selection
      const [providerName, modelName] = selected.label.split(' - ');
      const provider = providers.find(p => p.displayName === providerName);
      if (provider) {
        const model = provider.models.find(m => m.name === modelName);
        if (model) {
          this.providerManager.setCurrentProvider(provider.name);
          this.providerManager.setCurrentModel(model.id);
          this.updateStatusBar();
          vscode.window.showInformationMessage(`KP AI: Switched to ${provider.displayName} - ${model.name}`);
        }
      }
    }
  }

  public dispose() {
    this.statusBarItem.dispose();
  }
}
