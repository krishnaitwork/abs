import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';
import { ChatConversation, ChatMessage } from '../types';

export class KPChatMode {
  private providerManager: ProviderManager;
  private providerFactory: ProviderFactory;
  private currentConversation: ChatConversation | null = null;
  private conversations: ChatConversation[] = [];

  constructor(providerManager: ProviderManager) {
    this.providerManager = providerManager;
    this.providerFactory = ProviderFactory.getInstance(providerManager);
  }

  public async startNewConversation(title?: string): Promise<ChatConversation> {
    const conversation: ChatConversation = {
      id: this.generateId(),
      title: title || `KP AI Chat ${new Date().toLocaleTimeString()}`,
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      model: this.providerManager.getCurrentModel()
    };

    this.conversations.push(conversation);
    this.currentConversation = conversation;
    return conversation;
  }

  public async sendMessage(
    content: string,
    context?: string,
    onToken?: (token: string) => void
  ): Promise<ChatMessage> {
    if (!this.currentConversation) {
      await this.startNewConversation();
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: this.generateId(),
      role: 'user',
      content: context ? `${context}\n\n${content}` : content,
      timestamp: new Date()
    };

    this.currentConversation!.messages.push(userMessage);

    // Check if this is a file creation request
    const isFileCreation = /create|make|generate.*\.(js|ts|py|html|css|json|md|txt|java|cpp|c|cs|xml|yml|yaml|sql|sh|ps1|php|rb|go|rs)/i.test(content);

    // Add file creation context if detected
    let enhancedContent = content;
    if (isFileCreation) {
      enhancedContent = `${content}\n\nIMPORTANT: Please provide the complete file content in a code block with the appropriate language identifier. Start your response with the filename as a comment.`;
    }

    // Get AI response using centralized provider factory
    const model = this.providerManager.getCurrentModel();

    try {
      let assistantMessage: ChatMessage;

      // Use centralized provider factory for all providers
      const response = await this.providerFactory.createCompletion({
        messages: [...this.currentConversation!.messages.slice(0, -1), {
          ...userMessage,
          content: enhancedContent
        }],
        model: model,
        maxTokens: 2048,
        temperature: 0.7
      });

      assistantMessage = {
        id: this.generateId(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        model: model,
        tokens: response.tokens.total
      };

      this.currentConversation!.messages.push(assistantMessage);
      this.currentConversation!.updatedAt = new Date();

      return assistantMessage;
    } catch (error) {
      console.error('Chat error:', error);

      // Create error message
      const errorMessage: ChatMessage = {
        id: this.generateId(),
        role: 'assistant',
        content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : String(error)}`,
        timestamp: new Date(),
        model: model,
        tokens: 0
      };

      this.currentConversation!.messages.push(errorMessage);
      this.currentConversation!.updatedAt = new Date();

      return errorMessage;
    }
  }

  public getCurrentConversation(): ChatConversation | null {
    return this.currentConversation;
  }

  public getConversations(): ChatConversation[] {
    return this.conversations;
  }

  public async loadConversation(conversationId: string): Promise<ChatConversation | null> {
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (conversation) {
      this.currentConversation = conversation;
      return conversation;
    }
    return null;
  }

  public async deleteConversation(conversationId: string): Promise<boolean> {
    const index = this.conversations.findIndex(c => c.id === conversationId);
    if (index !== -1) {
      this.conversations.splice(index, 1);
      if (this.currentConversation?.id === conversationId) {
        this.currentConversation = this.conversations.length > 0 ? this.conversations[0] : null;
      }
      return true;
    }
    return false;
  }

  public async clearConversations(): Promise<void> {
    this.conversations = [];
    this.currentConversation = null;
  }

  public async exportConversation(conversationId: string): Promise<string> {
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (!conversation) {
      throw new Error('Conversation not found');
    }

    let exportText = `# ${conversation.title}\n\n`;
    exportText += `Date: ${conversation.createdAt.toLocaleString()}\n`;
    exportText += `Model: ${conversation.model}\n\n`;
    exportText += `---\n\n`;

    for (const message of conversation.messages) {
      exportText += `**${message.role.toUpperCase()}** (${message.timestamp.toLocaleTimeString()}):\n`;
      exportText += `${message.content}\n\n`;
      exportText += `---\n\n`;
    }

    return exportText;
  }

  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
}
