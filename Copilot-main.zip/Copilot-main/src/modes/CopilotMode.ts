import * as vscode from 'vscode';
import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';

export class KPCopilotMode implements vscode.InlineCompletionItemProvider {
  private providerManager: ProviderManager;
  private providerFactory: ProviderFactory;
  private lastRequestTime: number = 0;
  private debounceDelay: number = 300; // Reduced for better responsiveness
  private maxContextLines: number = 100; // Increased context
  private completionCache: Map<string, string> = new Map();
  private isGenerating: boolean = false;

  constructor(providerManager: ProviderManager) {
    this.providerManager = providerManager;
    this.providerFactory = ProviderFactory.getInstance(providerManager);
  }

  public async provideInlineCompletionItems(
    document: vscode.TextDocument,
    position: vscode.Position,
    context: vscode.InlineCompletionContext,
    token: vscode.CancellationToken
  ): Promise<vscode.InlineCompletionItem[] | vscode.InlineCompletionList | undefined> {

    // Check if completions are enabled
    const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
    if (!config.get('inlineCompletions', true)) {
      return undefined;
    }

    // Debounce requests but allow immediate response for certain triggers
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;

    // Allow immediate response for certain triggers
    const shouldAllowImmediate = this.shouldAllowImmediateCompletion(context, position);
    if (!shouldAllowImmediate && timeSinceLastRequest < this.debounceDelay) {
      return undefined;
    }

    this.lastRequestTime = now;

    // Check if we're already generating
    if (this.isGenerating) {
      return undefined;
    }

    try {
      this.isGenerating = true;
      const completionText = await this.generateCompletion(document, position, token);

      if (!completionText || token.isCancellationRequested) {
        return undefined;
      }

      // Create multiple completion options for better user experience
      const completions: vscode.InlineCompletionItem[] = [];

      // Primary completion
      const primaryItem = new vscode.InlineCompletionItem(
        completionText,
        new vscode.Range(position, position)
      );
      primaryItem.command = {
        command: 'kpAiAssistant.acceptCompletion',
        title: 'Accept Completion',
        arguments: [completionText]
      };
      completions.push(primaryItem);

      // Alternative shorter completion if the primary is long
      if (completionText.split('\n').length > 3) {
        const firstLine = completionText.split('\n')[0];
        if (firstLine.trim()) {
          const shortItem = new vscode.InlineCompletionItem(
            firstLine,
            new vscode.Range(position, position)
          );
          shortItem.command = {
            command: 'kpAiAssistant.acceptCompletion',
            title: 'Accept Single Line',
            arguments: [firstLine]
          };
          completions.push(shortItem);
        }
      }

      return completions;
    } catch (error) {
      console.error('KP Copilot error:', error);
      return undefined;
    } finally {
      this.isGenerating = false;
    }
  }

  private shouldAllowImmediateCompletion(
    context: vscode.InlineCompletionContext,
    position: vscode.Position
  ): boolean {
    // Allow immediate completion for certain triggers
    if (context.triggerKind === vscode.InlineCompletionTriggerKind.Automatic) {
      return true;
    }

    // Allow for common code patterns
    const editor = vscode.window.activeTextEditor;
    if (!editor) return false;

    const line = editor.document.lineAt(position.line);
    const text = line.text.substring(0, position.character);

    // Common triggers that should get immediate response
    const immediateTriggers = [
      /^\s*function\s+\w*\s*\(/, // function declaration
      /^\s*class\s+\w*/, // class declaration
      /^\s*if\s*\(/, // if statement
      /^\s*for\s*\(/, // for loop
      /^\s*while\s*\(/, // while loop
      /^\s*try\s*{/, // try block
      /^\s*switch\s*\(/, // switch statement
      /^\s*return\s+/, // return statement
      /^\s*const\s+\w*\s*=/, // const declaration
      /^\s*let\s+\w*\s*=/, // let declaration
      /^\s*var\s+\w*\s*=/, // var declaration
      /^\s*import\s+/, // import statement
      /^\s*export\s+/, // export statement
      /^\s*\/\*\*/, // JSDoc comment
      /^\s*\/\/\s*/, // single line comment
    ];

    return immediateTriggers.some(pattern => pattern.test(text));
  }

  private async generateCompletion(
    document: vscode.TextDocument,
    position: vscode.Position,
    token: vscode.CancellationToken
  ): Promise<string | undefined> {

    // Get enhanced context around cursor
    const context = this.getEnhancedContext(document, position);
    if (!context.trim()) {
      return undefined;
    }

    // Check cache first
    const cacheKey = this.generateCacheKey(document, position, context);
    const cachedCompletion = this.completionCache.get(cacheKey);
    if (cachedCompletion) {
      return cachedCompletion;
    }

    try {
      // Use centralized provider factory
      const response = await this.providerFactory.createCompletion({
        messages: [
          {
            id: 'system',
            role: 'system',
            content: 'You are KP AI Copilot, an intelligent code completion assistant. Complete the code naturally, following the existing style and patterns. Return only the completion code without explanations or markdown formatting.',
            timestamp: new Date()
          },
          {
            id: 'user',
            role: 'user',
            content: this.buildCompletionPrompt(document, context, position),
            timestamp: new Date()
          }
        ],
        model: this.providerManager.getCurrentModel(),
        maxTokens: 300, // Increased for better completions
        temperature: 0.1, // Lower for more consistent completions
        stream: false
      });

      if (token.isCancellationRequested || !response) {
        return undefined;
      }

      const completion = this.processCompletionResponse(response.content);

      // Cache the result
      if (completion) {
        this.completionCache.set(cacheKey, completion);
      }

      // Limit cache size
      if (this.completionCache.size > 100) {
        const firstKey = this.completionCache.keys().next().value;
        if (firstKey !== undefined) {
          this.completionCache.delete(firstKey);
        }
      }

      return completion;
    } catch (error) {
      console.error('AI completion error:', error);
      return undefined;
    }
  }

  private getEnhancedContext(document: vscode.TextDocument, position: vscode.Position): string {
    const startLine = Math.max(0, position.line - this.maxContextLines);
    const endLine = Math.min(document.lineCount - 1, position.line + 20);

    let context = '';

    // Add preceding lines with line numbers for better context
    for (let i = startLine; i < position.line; i++) {
      const line = document.lineAt(i);
      context += `${i + 1}: ${line.text}\n`;
    }

    // Add current line up to cursor
    const currentLine = document.lineAt(position.line);
    context += `${position.line + 1}: ${currentLine.text.substring(0, position.character)}`;

    // Add project context if available
    const projectContext = this.getProjectContext(document);
    if (projectContext) {
      context = `Project Context:\n${projectContext}\n\nCode Context:\n${context}`;
    }

    return context;
  }

  private getProjectContext(document: vscode.TextDocument): string | undefined {
    try {
      const workspaceFolder = vscode.workspace.getWorkspaceFolder(document.uri);
      if (!workspaceFolder) return undefined;

      // Get package.json if it exists
      const packageJsonPath = vscode.Uri.joinPath(workspaceFolder.uri, 'package.json');
      // This would need to be async in a real implementation

      // Get file structure context
      const relativePath = vscode.workspace.asRelativePath(document.uri);
      const pathParts = relativePath.split('/');

      if (pathParts.length > 1) {
        return `File: ${relativePath}\nDirectory: ${pathParts.slice(0, -1).join('/')}`;
      }

      return `File: ${relativePath}`;
    } catch (error) {
      return undefined;
    }
  }

  private buildCompletionPrompt(
    document: vscode.TextDocument,
    context: string,
    position: vscode.Position
  ): string {
    const language = document.languageId;
    const fileName = document.fileName;

    // Get imports/dependencies for better context
    const imports = this.extractImports(document);
    const functionContext = this.extractFunctionContext(document, position);

    let prompt = `File: ${fileName}\nLanguage: ${language}\n\n`;

    if (imports.length > 0) {
      prompt += `Imports:\n${imports.join('\n')}\n\n`;
    }

    if (functionContext) {
      prompt += `Current Function Context:\n${functionContext}\n\n`;
    }

    prompt += `Code context:\n${context}`;
    prompt += '\n\nComplete the code naturally from where it left off. Return only the completion code without explanations, comments, or markdown formatting.';

    return prompt;
  }

  private extractFunctionContext(document: vscode.TextDocument, position: vscode.Position): string | undefined {
    try {
      // Find the current function/class context
      let currentLine = position.line;
      let functionStart = -1;

      // Look backwards for function/class declaration
      for (let i = currentLine; i >= 0; i--) {
        const line = document.lineAt(i).text.trim();
        if (line.match(/^(function|class|const|let|var)\s+\w+/) ||
          line.match(/^\w+\s*\([^)]*\)\s*{/) ||
          line.match(/^\w+\s*:\s*function\s*\(/)) {
          functionStart = i;
          break;
        }
      }

      if (functionStart !== -1) {
        let context = '';
        for (let i = functionStart; i <= Math.min(functionStart + 10, currentLine); i++) {
          context += document.lineAt(i).text + '\n';
        }
        return context.trim();
      }
    } catch (error) {
      // Ignore errors in context extraction
    }

    return undefined;
  }

  private extractImports(document: vscode.TextDocument): string[] {
    const imports: string[] = [];
    const importRegex = /^(import|from|#include|using|require|import\s+type)/;

    for (let i = 0; i < Math.min(30, document.lineCount); i++) {
      const line = document.lineAt(i).text.trim();
      if (importRegex.test(line)) {
        imports.push(line);
      }
    }

    return imports;
  }

  private processCompletionResponse(response: string): string {
    // Clean up the response
    let completion = response.trim();

    // Remove code fences if present
    completion = completion.replace(/^```[\w]*\n?/, '');
    completion = completion.replace(/\n?```$/, '');

    // Remove explanatory text (lines starting with //, #, etc.)
    const lines = completion.split('\n');
    const codeLines = lines.filter(line => {
      const trimmed = line.trim();
      return !trimmed.startsWith('//') &&
        !trimmed.startsWith('#') &&
        !trimmed.startsWith('/*') &&
        !trimmed.startsWith('*') &&
        !trimmed.startsWith('<!--') &&
        !trimmed.startsWith('-->') &&
        trimmed !== '';
    });

    // Limit to reasonable completion size but allow multi-line
    const maxLines = 15;
    const limitedLines = codeLines.slice(0, maxLines);

    return limitedLines.join('\n');
  }

  private generateCacheKey(document: vscode.TextDocument, position: vscode.Position, context: string | undefined): string {
    // Create a hash-like key for caching
    const contextStr = context || '';
    const key = `${document.uri.toString()}:${position.line}:${position.character}:${contextStr.substring(0, 200)}`;
    return Buffer.from(key).toString('base64').substring(0, 50);
  }

  public register(context: vscode.ExtensionContext): vscode.Disposable {
    return vscode.languages.registerInlineCompletionItemProvider(
      { pattern: '**' }, // All files
      this
    );
  }

  public clearCache(): void {
    this.completionCache.clear();
  }
}
