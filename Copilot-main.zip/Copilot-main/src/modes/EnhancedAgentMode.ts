import * as vscode from 'vscode';
import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';
import { AgentStep, AgentTask } from '../types';

export class EnhancedAgentMode {
    private providerManager: ProviderManager;
    private providerFactory: ProviderFactory;
    private currentTask: AgentTask | null = null;
    private isRunning: boolean = false;
    private outputChannel: vscode.OutputChannel;

    constructor(providerManager: ProviderManager) {
        this.providerManager = providerManager;
        this.providerFactory = ProviderFactory.getInstance(providerManager);
        this.outputChannel = vscode.window.createOutputChannel('KP AI Agent');
    }

    public async startTask(description: string): Promise<void> {
        if (this.isRunning) {
            vscode.window.showWarningMessage('KP AI Agent: Another task is already running');
            return;
        }

        this.isRunning = true;
        this.currentTask = {
            id: Date.now().toString(),
            description,
            status: 'running',
            steps: [],
            createdAt: new Date(),
            updatedAt: new Date()
        };

        try {
            this.outputChannel.show();
            this.outputChannel.appendLine(`🚀 Starting KP AI Agent Task: ${description}`);

            // Analyze the task and break it down into steps
            const steps = await this.analyzeTask(description);
            this.currentTask.steps = steps;

            // Execute each step
            for (const step of steps) {
                if (!this.isRunning) break;

                step.status = 'running';
                this.updateTaskStatus();

                this.outputChannel.appendLine(`\n📋 Executing Step: ${step.description}`);

                try {
                    const result = await this.executeStep(step);
                    step.status = 'completed';
                    step.result = result;
                    this.outputChannel.appendLine(`✅ Step completed: ${result}`);
                } catch (error) {
                    step.status = 'failed';
                    step.result = error instanceof Error ? error.message : String(error);
                    this.outputChannel.appendLine(`❌ Step failed: ${step.result}`);

                    // Ask user if they want to continue
                    const continueTask = await vscode.window.showWarningMessage(
                        `Step failed: ${step.description}. Continue with remaining steps?`,
                        'Continue', 'Stop'
                    );

                    if (continueTask === 'Stop') {
                        break;
                    }
                }

                this.updateTaskStatus();
            }

            if (this.isRunning) {
                this.currentTask.status = 'completed';
                this.outputChannel.appendLine('\n🎉 Task completed successfully!');
                vscode.window.showInformationMessage('KP AI Agent: Task completed successfully!');
            } else {
                this.currentTask.status = 'failed';
                this.outputChannel.appendLine('\n⏹️ Task stopped by user');
            }

        } catch (error) {
            this.currentTask.status = 'failed';
            this.outputChannel.appendLine(`\n💥 Task failed: ${error}`);
            vscode.window.showErrorMessage(`KP AI Agent: Task failed - ${error}`);
        } finally {
            this.isRunning = false;
            this.updateTaskStatus();
        }
    }

    public stopCurrentTask(): void {
        if (this.isRunning) {
            this.isRunning = false;
            if (this.currentTask) {
                this.currentTask.status = 'failed';
                this.currentTask.updatedAt = new Date();
            }
            this.outputChannel.appendLine('\n⏹️ Task stopped by user');
            vscode.window.showInformationMessage('KP AI Agent: Task stopped');
        }
    }

    private async analyzeTask(description: string): Promise<AgentStep[]> {
        const prompt = `Analyze this coding task and break it down into specific, executable steps:

Task: ${description}

Break down the task into 3-8 specific steps that can be executed sequentially. Each step should be:
- Specific and actionable
- Include the type of action needed (create file, modify code, run command, etc.)
- Clear about what should be accomplished

Format each step as:
1. Action: [specific action]
2. Action: [specific action]
...`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a task analysis expert. Break down complex coding tasks into specific, executable steps.');

        // Parse the response and create step objects
        const steps: AgentStep[] = [];
        const lines = response.split('\n');
        let stepNumber = 1;

        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.match(/^\d+\./)) {
                const action = trimmed.replace(/^\d+\.\s*/, '');
                steps.push({
                    id: `step-${stepNumber}`,
                    description: action,
                    action: this.determineActionType(action),
                    parameters: { action, stepNumber },
                    status: 'pending',
                    requiresApproval: false
                });
                stepNumber++;
            }
        }

        return steps;
    }

    private determineActionType(action: string): string {
        const lowerAction = action.toLowerCase();

        if (lowerAction.includes('create') || lowerAction.includes('generate') || lowerAction.includes('write')) {
            return 'create_file';
        } else if (lowerAction.includes('modify') || lowerAction.includes('update') || lowerAction.includes('edit')) {
            return 'modify_file';
        } else if (lowerAction.includes('run') || lowerAction.includes('execute') || lowerAction.includes('install')) {
            return 'run_command';
        } else if (lowerAction.includes('test') || lowerAction.includes('verify') || lowerAction.includes('check')) {
            return 'test_code';
        } else if (lowerAction.includes('refactor') || lowerAction.includes('optimize') || lowerAction.includes('improve')) {
            return 'refactor_code';
        } else {
            return 'general';
        }
    }

    private async executeStep(step: AgentStep): Promise<string> {
        switch (step.action) {
            case 'create_file':
                return await this.createFile(step);
            case 'modify_file':
                return await this.modifyFile(step);
            case 'run_command':
                return await this.runCommand(step);
            case 'test_code':
                return await this.testCode(step);
            case 'refactor_code':
                return await this.refactorCode(step);
            default:
                return await this.executeGeneralStep(step);
        }
    }

    private async createFile(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        // Extract file path and content from the action description
        const prompt = `Based on this action description, determine what file to create and its content:

Action: ${action}

Provide:
1. The file path/name (relative to workspace root)
2. The complete file content
3. A brief description of what was created

Format as:
File: [path]
Content:
[code content]
Description: [brief description]`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a file creation expert. Create complete, production-ready files based on action descriptions.');

        // Parse the response to extract file info
        const fileMatch = response.match(/File:\s*(.+)/);
        const contentMatch = response.match(/Content:\s*([\s\S]*?)(?=Description:|$)/);
        const descriptionMatch = response.match(/Description:\s*(.+)/);

        if (!fileMatch || !contentMatch) {
            throw new Error('Could not parse file creation response');
        }

        const filePath = fileMatch[1].trim();
        const content = contentMatch[1].trim();
        const description = descriptionMatch ? descriptionMatch[1].trim() : 'File created';

        // Create the file
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        if (!workspaceFolder) {
            throw new Error('No workspace folder found');
        }

        const fileUri = vscode.Uri.joinPath(workspaceFolder.uri, filePath);
        await vscode.workspace.fs.writeFile(fileUri, Buffer.from(content, 'utf8'));

        return `Created file: ${filePath} - ${description}`;
    }

    private async modifyFile(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        const prompt = `Based on this action description, determine what file to modify and how:

Action: ${action}

Provide:
1. The file path/name to modify
2. The specific changes to make
3. A brief description of the modifications

Format as:
File: [path]
Changes:
[detailed changes or new content]
Description: [brief description]`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a file modification expert. Provide specific, actionable changes to existing files.');

        // Parse the response
        const fileMatch = response.match(/File:\s*(.+)/);
        const changesMatch = response.match(/Changes:\s*([\s\S]*?)(?=Description:|$)/);
        const descriptionMatch = response.match(/Description:\s*(.+)/);

        if (!fileMatch || !changesMatch) {
            throw new Error('Could not parse file modification response');
        }

        const filePath = fileMatch[1].trim();
        const changes = changesMatch[1].trim();
        const description = descriptionMatch ? descriptionMatch[1].trim() : 'File modified';

        // For now, we'll show the changes in the output
        // In a full implementation, you'd want to actually apply the changes
        return `Modified file: ${filePath} - ${description}\nChanges: ${changes}`;
    }

    private async runCommand(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        const prompt = `Based on this action description, determine what command to run:

Action: ${action}

Provide:
1. The exact command to run
2. Any arguments or flags needed
3. A brief description of what the command does

Format as:
Command: [command]
Description: [brief description]`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a command execution expert. Provide specific, safe commands to run.');

        const commandMatch = response.match(/Command:\s*(.+)/);
        const descriptionMatch = response.match(/Description:\s*(.+)/);

        if (!commandMatch) {
            throw new Error('Could not parse command response');
        }

        const command = commandMatch[1].trim();
        const description = descriptionMatch ? descriptionMatch[1].trim() : 'Command executed';

        // For safety, we'll just report what command would be run
        // In a full implementation, you'd want to execute the command
        return `Would run command: ${command} - ${description}`;
    }

    private async testCode(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        const prompt = `Based on this action description, determine how to test the code:

Action: ${action}

Provide:
1. What to test
2. How to test it
3. Expected results

Format as:
Test: [what to test]
Method: [how to test]
Expected: [expected results]`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a testing expert. Provide specific testing instructions and expected outcomes.');

        const testMatch = response.match(/Test:\s*(.+)/);
        const methodMatch = response.match(/Method:\s*(.+)/);
        const expectedMatch = response.match(/Expected:\s*(.+)/);

        if (!testMatch) {
            throw new Error('Could not parse testing response');
        }

        const test = testMatch[1].trim();
        const method = methodMatch ? methodMatch[1].trim() : 'Manual verification';
        const expected = expectedMatch ? expectedMatch[1].trim() : 'Code works as expected';

        return `Testing: ${test}\nMethod: ${method}\nExpected: ${expected}`;
    }

    private async refactorCode(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        const prompt = `Based on this action description, determine how to refactor the code:

Action: ${action}

Provide:
1. What code to refactor
2. Specific improvements to make
3. Benefits of the refactoring

Format as:
Target: [what to refactor]
Improvements: [specific changes]
Benefits: [benefits of refactoring]`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a refactoring expert. Provide specific refactoring suggestions with clear benefits.');

        const targetMatch = response.match(/Target:\s*(.+)/);
        const improvementsMatch = response.match(/Improvements:\s*(.+)/);
        const benefitsMatch = response.match(/Benefits:\s*(.+)/);

        if (!targetMatch) {
            throw new Error('Could not parse refactoring response');
        }

        const target = targetMatch[1].trim();
        const improvements = improvementsMatch ? improvementsMatch[1].trim() : 'Code improvements';
        const benefits = benefitsMatch ? benefitsMatch[1].trim() : 'Better code quality';

        return `Refactoring: ${target}\nImprovements: ${improvements}\nBenefits: ${benefits}`;
    }

    private async executeGeneralStep(step: AgentStep): Promise<string> {
        const { action } = step.parameters;

        const prompt = `Execute this general step:

Action: ${action}

Provide a detailed response about what was accomplished, including any relevant details, code snippets, or results.`;

        const response = await this.getAIResponse(prompt, 'You are KP AI Agent, a general task execution expert. Execute tasks and provide detailed results.');

        return response;
    }

    private async getAIResponse(prompt: string, systemMessage: string): Promise<string> {
        try {
            // Use centralized provider factory
            const response = await this.providerFactory.createCompletion({
                messages: [
                    {
                        id: 'system',
                        role: 'system',
                        content: systemMessage,
                        timestamp: new Date()
                    },
                    {
                        id: 'user',
                        role: 'user',
                        content: prompt,
                        timestamp: new Date()
                    }
                ],
                model: this.providerManager.getCurrentModel(),
                maxTokens: 2048,
                temperature: 0.3
            });

            return response.content;
        } catch (error) {
            console.error('AI response error:', error);
            throw error;
        }
    }

    private updateTaskStatus(): void {
        if (this.currentTask) {
            this.currentTask.updatedAt = new Date();
            // In a full implementation, you'd want to update the UI here
        }
    }

    public getCurrentTask(): AgentTask | null {
        return this.currentTask;
    }

    public isTaskRunning(): boolean {
        return this.isRunning;
    }

    public dispose(): void {
        this.stopCurrentTask();
        this.outputChannel.dispose();
    }
}
