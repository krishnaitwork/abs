import * as vscode from 'vscode';
import { ProviderFactory } from '../providers/ProviderFactory';
import { ProviderManager } from '../providers/ProviderManager';
import { AgentStep, AgentTask } from '../types';

export class KPAgentMode {
  private providerManager: ProviderManager;
  private providerFactory: ProviderFactory;
  private currentTask: AgentTask | null = null;
  private isRunning: boolean = false;
  private shouldStop: boolean = false;
  private outputChannel: vscode.OutputChannel;
  private onApprovalRequest?: (step: AgentStep) => Promise<boolean>;
  private chatPanel?: vscode.WebviewPanel;
  private _onDiffProposed = new vscode.EventEmitter<{ filePath: string; originalContent: string; newContent: string }>();
  public readonly onDiffProposed = this._onDiffProposed.event;

  constructor(providerManager: ProviderManager) {
    this.providerManager = providerManager;
    this.providerFactory = ProviderFactory.getInstance(providerManager);
    this.outputChannel = vscode.window.createOutputChannel('KP AI Agent');
  }

  public setApprovalHandler(handler: (step: AgentStep) => Promise<boolean>): void {
    this.onApprovalRequest = handler;
  }

  public stopExecution(): void {
    this.shouldStop = true;
    this.isRunning = false;
    if (this.currentTask) {
      this.currentTask.status = 'stopped';
    }
    this.outputChannel.appendLine('KP AI Agent: Execution stopped by user');
  }

  public async startTask(description: string): Promise<AgentTask> {
    if (this.isRunning) {
      throw new Error('Agent is already running a task');
    }

    const task: AgentTask = {
      id: this.generateId(),
      description: description,
      status: 'pending',
      steps: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.currentTask = task;
    this.isRunning = true;

    this.outputChannel.appendLine(`KP AI Agent: Starting task - ${description}`);

    try {
      await this.planAndExecuteTask(task);
    } catch (error) {
      task.status = 'failed';
      this.outputChannel.appendLine(`KP AI Agent: Task failed - ${error}`);
      vscode.window.showErrorMessage(`KP AI Agent task failed: ${error}`);
    } finally {
      this.isRunning = false;
    }

    return task;
  }

  private async planAndExecuteTask(task: AgentTask): Promise<void> {
    // Step 1: Analyze the task and create a plan
    const planningStep: AgentStep = {
      id: this.generateId(),
      description: 'Analyzing task and creating execution plan',
      action: 'plan',
      parameters: { description: task.description },
      status: 'running'
    };

    task.steps.push(planningStep);
    this.outputChannel.appendLine(`Step 1: ${planningStep.description}`);

    const plan = await this.createTaskPlan(task.description);
    planningStep.result = plan;
    planningStep.status = 'completed';

    // Step 2: Execute each planned action
    for (let i = 0; i < plan.length; i++) {
      const plannedAction = plan[i];
      const executionStep: AgentStep = {
        id: this.generateId(),
        description: plannedAction.description,
        action: plannedAction.action,
        parameters: plannedAction.parameters,
        status: 'pending',
        requiresApproval: plannedAction.requiresApproval || false
      };

      task.steps.push(executionStep);
      this.outputChannel.appendLine(`Step ${i + 2}: ${executionStep.description}`);

      // Request approval if needed
      if (executionStep.requiresApproval) {
        let approved: boolean;

        if (this.onApprovalRequest) {
          approved = await this.onApprovalRequest(executionStep);
        } else {
          approved = await this.requestApproval(executionStep);
        }

        executionStep.approved = approved;

        if (!approved) {
          this.outputChannel.appendLine('Step cancelled by user');
          continue;
        }
      }

      // Execute the step
      executionStep.status = 'running';
      task.updatedAt = new Date();

      try {
        const result = await this.executeStep(executionStep);
        executionStep.result = result;
        executionStep.status = 'completed';
        this.outputChannel.appendLine(`Step completed: ${result.summary || 'Success'}`);
      } catch (error) {
        executionStep.status = 'failed';
        this.outputChannel.appendLine(`Step failed: ${error}`);

        // Ask if user wants to continue
        const continueExecution = await vscode.window.showWarningMessage(
          `KP AI Agent: Step failed - ${error}. Continue with remaining steps?`,
          'Continue',
          'Stop'
        );

        if (continueExecution !== 'Continue') {
          task.status = 'failed';
          return;
        }
      }
    }

    task.status = 'completed';
    this.outputChannel.appendLine('KP AI Agent: Task completed successfully');
    vscode.window.showInformationMessage('KP AI Agent: Task completed successfully');
  }

  private async createTaskPlan(description: string): Promise<any[]> {
    const model = this.providerManager.getCurrentModel();

    const planningPrompt = `Analyze this task and create a detailed execution plan:

Task: ${description}

Create a JSON array of steps, each with:
{
  "description": "What to do",
  "action": "create_file|modify_file|edit_file|run_command|analyze_code|generate_tests|ask_question|search_code|refactor_code|optimize_code|add_documentation|fix_bugs",
  "parameters": {
    "filePath": "path/to/file",
    "content": "file content or description",
    "command": "command to run",
    "question": "question to ask",
    "searchQuery": "what to search for",
    "changes": "description of changes to make"
  },
  "requiresApproval": true
}

Valid actions: 
- create_file: Create new files
- modify_file: Replace entire file content
- edit_file: Make specific changes to existing file (preferred for updates)
- run_command: Execute terminal commands
- analyze_code: Analyze code structure and quality
- generate_tests: Create test files
- ask_question: Ask questions and get explanations
- search_code: Search through codebase
- refactor_code: Improve code structure
- optimize_code: Improve performance
- add_documentation: Add or improve documentation
- fix_bugs: Fix identified issues

Be specific about file paths and content. Set requiresApproval=true for destructive operations.

IMPORTANT: 
- RESPOND WITH ONLY VALID JSON ARRAY - NO OTHER TEXT
- NO MARKDOWN CODE BLOCKS
- NO EXPLANATIONS OR COMMENTS
- ENSURE ALL STRINGS ARE PROPERLY QUOTED AND ESCAPED
- NO TRAILING COMMAS
- EXAMPLE: [{"description":"Create file","action":"create_file","parameters":{"filePath":"test.js","content":"console.log('hello')"},"requiresApproval":false}]`;

    try {
      const response = await this.providerFactory.createCompletion({
        messages: [{
          id: this.generateId(),
          role: 'user',
          content: planningPrompt,
          timestamp: new Date()
        }],
        model: model,
        maxTokens: 2048,
        temperature: 0.3
      });

      let jsonContent = response.content.trim();

      // Debug output
      this.outputChannel.appendLine(`KP AI Agent: Raw response: ${jsonContent.substring(0, 200)}...`);

      // Extract JSON from markdown code blocks if present
      const codeBlockMatch = jsonContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (codeBlockMatch) {
        jsonContent = codeBlockMatch[1].trim();
        this.outputChannel.appendLine(`KP AI Agent: Extracted JSON from code block`);
      }

      this.outputChannel.appendLine(`KP AI Agent: Parsing JSON: ${jsonContent.substring(0, 100)}...`);

      try {
        return JSON.parse(jsonContent);
      } catch (parseError) {
        this.outputChannel.appendLine(`KP AI Agent: Initial JSON parsing failed: ${parseError instanceof Error ? parseError.message : String(parseError)}`);

        // Enhanced fallback: Try multiple strategies to extract valid JSON
        let fallbackJson = null;

        // Strategy 1: Try to find and extract a JSON array
        const arrayMatches = jsonContent.match(/\[[\s\S]*?\]/g);
        if (arrayMatches) {
          for (const match of arrayMatches) {
            try {
              JSON.parse(match);
              fallbackJson = match;
              break;
            } catch (e) {
              continue;
            }
          }
        }

        // Strategy 2: If no valid array, try to find the largest JSON-like structure
        if (!fallbackJson) {
          // Find potential start and end of JSON array
          const startIndex = jsonContent.indexOf('[');
          if (startIndex !== -1) {
            let bracketCount = 0;
            let endIndex = -1;

            for (let i = startIndex; i < jsonContent.length; i++) {
              if (jsonContent[i] === '[') bracketCount++;
              if (jsonContent[i] === ']') bracketCount--;
              if (bracketCount === 0) {
                endIndex = i;
                break;
              }
            }

            if (endIndex !== -1) {
              fallbackJson = jsonContent.substring(startIndex, endIndex + 1);
            }
          }
        }

        // Strategy 3: Clean up common JSON issues
        if (fallbackJson) {
          // Fix common issues like trailing commas
          fallbackJson = fallbackJson
            .replace(/,\s*}/g, '}')  // Remove trailing commas in objects
            .replace(/,\s*]/g, ']')  // Remove trailing commas in arrays
            .replace(/\n/g, '\\n')   // Escape newlines
            .replace(/\r/g, '\\r')   // Escape carriage returns
            .replace(/\t/g, '\\t');  // Escape tabs
        }

        if (fallbackJson) {
          this.outputChannel.appendLine(`KP AI Agent: Fallback JSON block: ${fallbackJson.substring(0, 100)}...`);
          try {
            return JSON.parse(fallbackJson);
          } catch (fallbackError) {
            this.outputChannel.appendLine(`KP AI Agent: Fallback JSON parsing failed: ${fallbackError instanceof Error ? fallbackError.message : String(fallbackError)}`);

            // Last resort: Create a simple default task plan
            this.outputChannel.appendLine(`KP AI Agent: Creating default task plan as last resort`);
            return [{
              description: `Analyze and work on: ${description}`,
              action: "analyze_code",
              parameters: {
                searchQuery: description,
                changes: "Analyze the request and provide guidance"
              },
              requiresApproval: true
            }];
          }
        } else {
          this.outputChannel.appendLine(`KP AI Agent: No valid JSON structure found in response.`);
          this.outputChannel.appendLine(`KP AI Agent: Full extracted content: ${jsonContent}`);

          // Last resort: Create a simple default task plan
          this.outputChannel.appendLine(`KP AI Agent: Creating default task plan as last resort`);
          return [{
            description: `Analyze and work on: ${description}`,
            action: "analyze_code",
            parameters: {
              searchQuery: description,
              changes: "Analyze the request and provide guidance"
            },
            requiresApproval: true
          }];
        }
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.outputChannel.appendLine(`KP AI Agent: Outer catch - ${errorMessage}`);
      throw new Error(`Failed to parse task plan from AI response: ${errorMessage}`);
    }
  }

  private async analyzeWorkspace(): Promise<string> {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      return "No workspace folder open.";
    }

    const workspaceRoot = workspaceFolders[0].uri.fsPath;
    let context = `Workspace Root: ${workspaceRoot}\n\n`;

    try {
      // Get package.json info if it exists
      const packageJsonUri = vscode.Uri.joinPath(workspaceFolders[0].uri, 'package.json');
      try {
        const packageJsonContent = await vscode.workspace.fs.readFile(packageJsonUri);
        const packageJson = JSON.parse(packageJsonContent.toString());
        context += `Project Type: ${packageJson.name || 'Unknown'}\n`;
        context += `Main File: ${packageJson.main || 'Not specified'}\n`;
        if (packageJson.scripts) {
          context += `Scripts: ${Object.keys(packageJson.scripts).join(', ')}\n`;
        }
        context += '\n';
      } catch {
        // package.json doesn't exist or is invalid
      }

      // Analyze file structure
      context += "File Structure:\n";
      const files = await this.getWorkspaceFiles(workspaceFolders[0].uri);
      files.slice(0, 20).forEach(file => {
        context += `- ${file}\n`;
      });

      if (files.length > 20) {
        context += `... and ${files.length - 20} more files\n`;
      }

      // Identify main entry points
      const entryPoints = files.filter(f =>
        f.includes('index.') ||
        f.includes('main.') ||
        f.includes('app.') ||
        f.includes('extension.')
      );

      if (entryPoints.length > 0) {
        context += `\nPotential Entry Points: ${entryPoints.join(', ')}\n`;
      }

      return context;
    } catch (error) {
      return `Error analyzing workspace: ${error instanceof Error ? error.message : String(error)}`;
    }
  }

  private async getWorkspaceFiles(uri: vscode.Uri, relativePath: string = ''): Promise<string[]> {
    const files: string[] = [];

    try {
      const entries = await vscode.workspace.fs.readDirectory(uri);

      for (const [name, type] of entries) {
        const currentPath = relativePath ? `${relativePath}/${name}` : name;

        // Skip node_modules, .git, and other common ignore patterns
        if (name.startsWith('.') || name === 'node_modules' || name === 'out' || name === 'dist') {
          continue;
        }

        if (type === vscode.FileType.File) {
          files.push(currentPath);
        } else if (type === vscode.FileType.Directory && files.length < 100) {
          // Recursively get files from subdirectories (with limit)
          const subFiles = await this.getWorkspaceFiles(
            vscode.Uri.joinPath(uri, name),
            currentPath
          );
          files.push(...subFiles);
        }
      }
    } catch (error) {
      // Handle permission errors or other issues
    }

    return files;
  }

  private async executeStep(step: AgentStep): Promise<any> {
    // Best-effort populate missing filePath from description or active editor
    try {
      step.parameters = this.populateFilePath(step.action, step.parameters || {}, step.description || '');
    } catch (e) {
      // non-fatal; actions may still handle absence
    }
    switch (step.action) {
      case 'create_file':
        return await this.createFile(step.parameters);
      case 'modify_file':
        return await this.modifyFile(step.parameters);
      case 'edit_file':
        return await this.editFile(step.parameters);
      case 'run_command':
        return await this.runCommand(step.parameters);
      case 'analyze_code':
        return await this.analyzeCode(step.parameters);
      case 'generate_tests':
        return await this.generateTests(step.parameters);
      case 'ask_question':
        return await this.askQuestion(step.parameters);
      case 'search_code':
        return await this.searchCode(step.parameters);
      case 'refactor_code':
        return await this.refactorCode(step.parameters);
      case 'optimize_code':
        return await this.optimizeCode(step.parameters);
      case 'add_documentation':
        return await this.addDocumentation(step.parameters);
      case 'fix_bugs':
        return await this.fixBugs(step.parameters);
      default:
        throw new Error(`Unknown action: ${step.action}`);
    }
  }

  private populateFilePath(action: string, params: any, description: string): any {
    const updated = { ...(params || {}) };
    if (typeof updated.filePath === 'string' && updated.filePath.trim().length > 0) {
      return updated;
    }

    // Try from parameters hints
    let inferred = this.normalizePathLike(updated.filePath);

    // Try from description
    if (!inferred) {
      inferred = this.normalizePathLike(description);
    }

    // Fallback to active editor for file-modifying actions
    const actionsNeedingFile = new Set([
      'modify_file','edit_file','analyze_code','generate_tests','refactor_code','optimize_code','add_documentation','fix_bugs'
    ]);
    if (!inferred && actionsNeedingFile.has(action)) {
      const active = vscode.window.activeTextEditor?.document?.uri.fsPath;
      if (active) inferred = active;
    }

    if (inferred) {
      updated.filePath = inferred;
    }
    return updated;
  }

  private async createFile(params: any): Promise<any> {
    const { filePath, content } = params;
    if (!filePath) {
      throw new Error('create_file requires a filePath');
    }
    const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Create directory if it doesn't exist
    const dirPath = fullPath.substring(0, fullPath.lastIndexOf(process.platform === 'win32' ? '\\' : '/'));
    const dirUri = vscode.Uri.file(dirPath);

    try {
      await vscode.workspace.fs.createDirectory(dirUri);
      this.outputChannel.appendLine(`KP AI Agent: Created directory: ${dirPath}`);
    } catch (err) {
      // Directory might already exist, ignore error
      this.outputChannel.appendLine(`KP AI Agent: Directory already exists or error: ${err}`);
    }

    await vscode.workspace.fs.writeFile(uri, Buffer.from(content, 'utf8'));

    this.outputChannel.appendLine(`KP AI Agent: Created file: ${fullPath}`);

    return {
      summary: `Created file: ${filePath}`,
      filePath: fullPath,
      size: content.length
    };
  }

  private async modifyFile(params: any): Promise<any> {
  const { filePath, content: newContent } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    try {
      // Read existing file for diff
      let originalContent = '';
      try {
        const existingContent = await vscode.workspace.fs.readFile(uri);
        originalContent = existingContent.toString();
      } catch {
        // File doesn't exist, will be created
        originalContent = '';
      }

      // Show diff and get user approval if there's original content
      if (originalContent) {
        const approved = await this.showDiff(originalContent, newContent, filePath);
        if (!approved) {
          this.outputChannel.appendLine(`KP AI Agent: Changes rejected by user for ${filePath}`);
          return {
            summary: `Changes rejected for ${filePath}`,
            filePath: fullPath,
            status: 'rejected'
          };
        }
      }

      // Write the new content
      await vscode.workspace.fs.writeFile(uri, Buffer.from(newContent, 'utf8'));

      this.outputChannel.appendLine(`KP AI Agent: Modified file: ${fullPath}`);

      return {
        summary: `Modified file: ${filePath}`,
        filePath: fullPath,
        originalContent: originalContent,
        newContent: newContent
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error modifying file ${fullPath}: ${error}`);
      throw error;
    }
  }

  private async editFile(params: any): Promise<any> {
  const { filePath, changes } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Read existing file
    try {
      const existingContent = await vscode.workspace.fs.readFile(uri);
      const originalContent = existingContent.toString();
      let newContent = originalContent;

      // Apply changes based on the type
      if (Array.isArray(changes)) {
        for (const change of changes) {
          if (change.type === 'replace') {
            newContent = newContent.replace(change.search, change.replacement);
          } else if (change.type === 'append') {
            newContent += change.content;
          } else if (change.type === 'insert') {
            // Insert at specific line or position
            const lines = newContent.split('\n');
            if (change.line !== undefined && change.line < lines.length) {
              lines.splice(change.line, 0, change.content);
              newContent = lines.join('\n');
            }
          } else if (change.type === 'delete') {
            // Delete specific lines or content
            if (change.startLine !== undefined && change.endLine !== undefined) {
              const lines = newContent.split('\n');
              lines.splice(change.startLine, change.endLine - change.startLine + 1);
              newContent = lines.join('\n');
            }
          }
        }
      } else if (typeof changes === 'string') {
        // If changes is a string description, let AI generate actual code
        const codeToAdd = await this.generateCodeFromDescription(changes, originalContent, filePath);
        newContent += `\n\n${codeToAdd}`;
      }

      // Show diff and get user approval before applying changes
      const approved = await this.showDiff(originalContent, newContent, filePath);

      if (!approved) {
        this.outputChannel.appendLine(`KP AI Agent: Changes rejected by user for ${filePath}`);
        return {
          summary: `Changes rejected for ${filePath}`,
          filePath: fullPath,
          status: 'rejected'
        };
      }

      // Apply the changes
      await vscode.workspace.fs.writeFile(uri, Buffer.from(newContent, 'utf8'));

      this.outputChannel.appendLine(`KP AI Agent: Modified file: ${fullPath}`);

      return {
        summary: `Modified file: ${filePath}`,
        filePath: fullPath,
        changesApplied: Array.isArray(changes) ? changes.length : 1,
        originalContent: originalContent,
        newContent: newContent
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error modifying file ${fullPath}: ${error}`);
      throw error;
    }
  }

  private async runCommand(params: any): Promise<any> {
    const { command, cwd } = params;

    // Execute terminal command
    const terminal = vscode.window.createTerminal({
      name: 'KP AI Agent',
      cwd: cwd
    });

    terminal.sendText(command);

    return {
      summary: `Executed command: ${command}`,
      command: command,
      cwd: cwd
    };
  }

  private async analyzeCode(params: any): Promise<any> {
  const { filePath } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    try {
      const content = await vscode.workspace.fs.readFile(uri);

      // Simple analysis - could be enhanced with AI
      const lines = content.toString().split('\n');
      const analysis = {
        totalLines: lines.length,
        emptyLines: lines.filter(line => line.trim() === '').length,
        commentLines: lines.filter(line => line.trim().startsWith('//')).length
      };

      this.outputChannel.appendLine(`KP AI Agent: Analyzed file: ${fullPath}`);

      return {
        summary: `Analyzed file: ${filePath}`,
        filePath: fullPath,
        analysis: analysis
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error analyzing file ${fullPath}: ${error}`);
      throw error;
    }
  }

  private async generateTests(params: any): Promise<any> {
  const { filePath, testFramework } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    // Generate test file path
    const testFilePath = fullPath.replace(/\.(js|ts)$/, `.test.$1`);

    // Simple test template - would use AI for better generation
    const testContent = `// KP AI Generated Tests for ${filePath}
describe('${filePath}', () => {
  test('should pass', () => {
    expect(true).toBe(true);
  });
});`;

    const uri = vscode.Uri.file(testFilePath);
    await vscode.workspace.fs.writeFile(uri, Buffer.from(testContent, 'utf8'));

    this.outputChannel.appendLine(`KP AI Agent: Generated tests: ${testFilePath}`);

    return {
      summary: `Generated tests: ${testFilePath}`,
      testFilePath: testFilePath,
      framework: testFramework
    };
  }

  private async askQuestion(params: any): Promise<any> {
    const { question } = params;

    // For now, we'll use a simple approach - ask the AI directly and show in output
    // In a full implementation, this would open a chat panel
    this.outputChannel.appendLine(`KP AI Agent: Question: ${question}`);

    try {
      const model = this.providerManager.getCurrentModel();
      const response = await this.providerFactory.createCompletion({
        messages: [{
          id: this.generateId(),
          role: 'user',
          content: question,
          timestamp: new Date()
        }],
        model: model,
        maxTokens: 2048,
        temperature: 0.3
      });

      const answer = response.content;
      this.outputChannel.appendLine(`KP AI Agent: Answer: ${answer}`);

      // Show the answer in a new document
      const doc = await vscode.workspace.openTextDocument({
        content: `# KP AI Question & Answer\n\n## Question\n${question}\n\n## Answer\n${answer}`,
        language: 'markdown'
      });

      await vscode.window.showTextDocument(doc);

      return {
        summary: `Answered question: ${question}`,
        question: question,
        answer: answer
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error answering question: ${error}`);
      throw error;
    }
  }

  private async searchCode(params: any): Promise<any> {
    const { searchQuery } = params;

    // This is a placeholder for a more sophisticated search mechanism
    // For now, we'll just return a placeholder result
    this.outputChannel.appendLine(`KP AI Agent: Searching for "${searchQuery}" in workspace...`);

    return {
      summary: `Searched for: ${searchQuery}`,
      searchQuery: searchQuery,
      results: [
        { file: 'package.json', line: 1, content: 'Project configuration' },
        { file: 'src/index.js', line: 10, content: 'Main application entry point' },
        { file: 'README.md', line: 5, content: 'Project documentation' }
      ]
    };
  }

  private async refactorCode(params: any): Promise<any> {
  const { filePath, changes } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Read existing file
    try {
      const existingContent = await vscode.workspace.fs.readFile(uri);
      const originalContent = existingContent.toString();
      let newContent = originalContent;

      // Apply changes (simplified - would need more sophisticated logic)
      if (Array.isArray(changes)) {
        for (const change of changes) {
          if (change.type === 'replace') {
            newContent = newContent.replace(change.search, change.replacement);
          } else if (change.type === 'append') {
            newContent += change.content;
          }
        }
      } else if (typeof changes === 'string') {
        // If changes is a string description, let AI generate actual code
        const codeToAdd = await this.generateCodeFromDescription(changes, originalContent, filePath);
        newContent += `\n\n${codeToAdd}`;
      }

      // Show diff and get user approval before applying changes
      const approved = await this.showDiff(originalContent, newContent, filePath);
      if (!approved) {
        this.outputChannel.appendLine(`KP AI Agent: Changes rejected by user for ${filePath}`);
        return {
          summary: `Changes rejected for ${filePath}`,
          filePath: fullPath,
          status: 'rejected'
        };
      }

      // Apply the changes
      await vscode.workspace.fs.writeFile(uri, Buffer.from(newContent, 'utf8'));

      this.outputChannel.appendLine(`KP AI Agent: Refactored file: ${fullPath}`);

      return {
        summary: `Refactored file: ${filePath}`,
        filePath: fullPath,
        changesApplied: Array.isArray(changes) ? changes.length : 1,
        originalContent: originalContent,
        newContent: newContent
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error refactoring file ${fullPath}: ${error}`);
      throw error;
    }
  }

  private async optimizeCode(params: any): Promise<any> {
  const { filePath } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Read existing file
    try {
      const existingContent = await vscode.workspace.fs.readFile(uri);
      let content = existingContent.toString();

      // Simple optimization - could be enhanced with AI
      // For example, remove unused imports, simplify loops, etc.
      // This is a placeholder and would require a more sophisticated AI model
      this.outputChannel.appendLine(`KP AI Agent: Optimizing file: ${fullPath}`);

      return {
        summary: `Optimized file: ${filePath}`,
        filePath: fullPath,
        optimizationDetails: 'Placeholder optimization details'
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error optimizing file ${fullPath}: ${error}`);
      throw error;
    }
  }

  private async addDocumentation(params: any): Promise<any> {
  const { filePath, changes } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Read existing file
    try {
      const existingContent = await vscode.workspace.fs.readFile(uri);
      const originalContent = existingContent.toString();
      let newContent = originalContent;

      // Apply changes (simplified - would need more sophisticated logic)
      if (Array.isArray(changes)) {
        for (const change of changes) {
          if (change.type === 'replace') {
            newContent = newContent.replace(change.search, change.replacement);
          } else if (change.type === 'append') {
            newContent += change.content;
          }
        }
      } else if (typeof changes === 'string') {
        // If changes is a string description, let AI generate actual code
        const codeToAdd = await this.generateCodeFromDescription(changes, originalContent, filePath);
        newContent += `\n\n${codeToAdd}`;
      }

      // Show diff and get user approval before applying changes
      const approved = await this.showDiff(originalContent, newContent, filePath);
      if (!approved) {
        this.outputChannel.appendLine(`KP AI Agent: Changes rejected by user for ${filePath}`);
        return {
          summary: `Changes rejected for ${filePath}`,
          filePath: fullPath,
          status: 'rejected'
        };
      }

      // Apply the changes
      await vscode.workspace.fs.writeFile(uri, Buffer.from(newContent, 'utf8'));

      this.outputChannel.appendLine(`KP AI Agent: Added documentation: ${fullPath}`);

      return {
        summary: `Added documentation: ${filePath}`,
        filePath: fullPath,
        changesApplied: Array.isArray(changes) ? changes.length : 1,
        originalContent: originalContent,
        newContent: newContent
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error adding documentation to ${filePath}: ${error}`);
      throw error;
    }
  }

  private async fixBugs(params: any): Promise<any> {
  const { filePath, changes } = params;
  const fullPath = await this.resolveFilePathOrThrow(filePath);

    const uri = vscode.Uri.file(fullPath);

    // Read existing file
    try {
      const existingContent = await vscode.workspace.fs.readFile(uri);
      const originalContent = existingContent.toString();
      let newContent = originalContent;

      // Apply changes (simplified - would need more sophisticated logic)
      if (Array.isArray(changes)) {
        for (const change of changes) {
          if (change.type === 'replace') {
            newContent = newContent.replace(change.search, change.replacement);
          } else if (change.type === 'append') {
            newContent += change.content;
          }
        }
      } else if (typeof changes === 'string') {
        // If changes is a string description, let AI generate actual code
        const codeToAdd = await this.generateCodeFromDescription(changes, originalContent, filePath);
        newContent += `\n\n${codeToAdd}`;
      }

      // Show diff and get user approval before applying changes
      const approved = await this.showDiff(originalContent, newContent, filePath);
      if (!approved) {
        this.outputChannel.appendLine(`KP AI Agent: Changes rejected by user for ${filePath}`);
        return {
          summary: `Changes rejected for ${filePath}`,
          filePath: fullPath,
          status: 'rejected'
        };
      }

      // Apply the changes
      await vscode.workspace.fs.writeFile(uri, Buffer.from(newContent, 'utf8'));

      this.outputChannel.appendLine(`KP AI Agent: Fixed bugs: ${fullPath}`);

      return {
        summary: `Fixed bugs: ${filePath}`,
        filePath: fullPath,
        changesApplied: Array.isArray(changes) ? changes.length : 1,
        originalContent: originalContent,
        newContent: newContent
      };
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error fixing bugs in ${filePath}: ${error}`);
      throw error;
    }
  }

  private async requestApproval(step: AgentStep): Promise<boolean> {
    const action = await vscode.window.showWarningMessage(
      `KP AI Agent wants to execute: ${step.description}\n\nAction: ${step.action}\nParameters: ${JSON.stringify(step.parameters, null, 2)}`,
      { modal: true },
      'Approve',
      'Deny'
    );

    return action === 'Approve';
  }

  public stopCurrentTask(): void {
    if (this.currentTask) {
      this.currentTask.status = 'failed';
      this.isRunning = false;
      this.outputChannel.appendLine('KP AI Agent: Task stopped by user');
    }
  }

  public getCurrentTask(): AgentTask | null {
    return this.currentTask;
  }

  public isAgentRunning(): boolean {
    return this.isRunning;
  }

  private async generateCodeFromDescription(description: string, existingContent: string, filePath: string): Promise<string> {
    const model = this.providerManager.getCurrentModel();

    // Determine the programming language from file extension
    const extension = filePath.split('.').pop()?.toLowerCase();
    const language = extension === 'js' ? 'JavaScript' :
      extension === 'ts' ? 'TypeScript' :
        extension === 'py' ? 'Python' :
          extension === 'java' ? 'Java' :
            'JavaScript'; // default

    const prompt = `You are a coding assistant. Generate ${language} code based on this description: "${description}"

Existing file content:
\`\`\`${language.toLowerCase()}
${existingContent}
\`\`\`

Requirements:
1. Generate only the new code to be added (no comments, no explanations)
2. Make sure the code is syntactically correct and follows best practices
3. Do not duplicate existing functions or code
4. The code should integrate well with the existing content
5. Include proper function exports if needed (e.g., module.exports for Node.js)

Return only the code to be added:`;

    try {
      // Use centralized provider factory for all providers
      const response = await this.providerFactory.createCompletion({
        messages: [{
          id: this.generateId(),
          role: 'user',
          content: prompt,
          timestamp: new Date()
        }],
        model: model,
        maxTokens: 2048,
        temperature: 0.3
      });

      const result = response.content;

      // Clean up the response - remove code block markers if present
      let cleanCode = result?.trim() || '';
      if (cleanCode.startsWith('```')) {
        const lines = cleanCode.split('\n');
        lines.shift(); // Remove first ```
        if (lines[lines.length - 1].trim() === '```') {
          lines.pop(); // Remove last ```
        }
        cleanCode = lines.join('\n');
      }

      return cleanCode;
    } catch (error) {
      this.outputChannel.appendLine(`Error generating code: ${error}`);
      // Fallback to comment if AI generation fails
      return `// TODO: ${description}`;
    }
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  /**
 * Show a diff view between original and new content with user approval
 */
  private async showDiff(originalContent: string, newContent: string, fileName: string): Promise<boolean> {
    // No direct diff opening or modal prompts. Route approval via the configured handler (chat UI).
    try {
      if (this.onApprovalRequest) {
        const step = {
          id: this.generateId(),
          description: `Apply changes to ${fileName}`,
          action: 'modify_file',
          parameters: {
            filePath: fileName,
            originalContent,
            newContent
          },
          status: 'pending',
          requiresApproval: true
        } as any; // conforms to AgentStep shape

        // Let the approval handler present the diff link and await a decision
        const approved = await this.onApprovalRequest(step);
        this.outputChannel.appendLine(`KP AI Agent: Approval via chat for ${fileName}: ${approved ? 'approved' : 'rejected'}`);
        return approved;
      }

      // If no handler is set, default to reject to avoid unintended changes
      this.outputChannel.appendLine('KP AI Agent: No approval handler set; rejecting by default');
      return false;
    } catch (error) {
      this.outputChannel.appendLine(`KP AI Agent: Error during chat-based approval: ${error}`);
      return false;
    }
  }

  public dispose(): void {
    this.outputChannel.dispose();
    if (this.chatPanel) {
      this.chatPanel.dispose();
    }
  }

  private async resolveFilePathOrThrow(filePath?: string): Promise<string> {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0];

    // If filePath is a string, normalize common human phrases like "palindrome.js file under src folder"
    const normalized = this.normalizePathLike(filePath);
    if (normalized) {
      if (normalized.includes(':') || normalized.startsWith('/') || normalized.startsWith('\\')) {
        return normalized;
      }
      if (!workspaceFolder) {
        throw new Error('No workspace folder is open to resolve relative filePath');
      }
      
      // First try to find the file in the workspace
      const fullPath = vscode.Uri.joinPath(workspaceFolder.uri, normalized).fsPath;
      
      // Check if file exists, if not, search for it
      try {
        await vscode.workspace.fs.stat(vscode.Uri.file(fullPath));
        return fullPath;
      } catch {
        // File doesn't exist at exact path, search for it
        const foundFile = await this.findFileInWorkspace(normalized, workspaceFolder.uri);
        if (foundFile) {
          return foundFile;
        }
      }
      
      return fullPath; // Return the original path even if not found
    }

    // Fallback: use the active editor's document
    const active = vscode.window.activeTextEditor?.document?.uri.fsPath;
    if (active) {
      return active;
    }

    throw new Error('Action requires a valid filePath');
  }

  private async findFileInWorkspace(fileName: string, workspaceUri: vscode.Uri): Promise<string | undefined> {
    try {
      // Search for files matching the filename
      const pattern = `**/${fileName}`;
      const files = await vscode.workspace.findFiles(pattern, '**/node_modules/**');
      
      if (files.length > 0) {
        // Return the first match
        return files[0].fsPath;
      }
      
      // If no exact match, try partial matches
      const partialPattern = `**/*${fileName}*`;
      const partialFiles = await vscode.workspace.findFiles(partialPattern, '**/node_modules/**');
      
      if (partialFiles.length > 0) {
        return partialFiles[0].fsPath;
      }
      
      return undefined;
    } catch (error) {
      this.outputChannel.appendLine(`Error searching for file ${fileName}: ${error}`);
      return undefined;
    }
  }

  private normalizePathLike(input?: string): string | undefined {
    if (!input || typeof input !== 'string') return undefined;
    const trimmed = input.trim();
    // If already looks like a path with separators or drive
    if (/[:/\\]/.test(trimmed)) {
      // Replace phrases like " under src folder" -> prefix src/
      const m = trimmed.match(/([\w.-]+\.[A-Za-z0-9]+)\b/);
      if (m && /\bsrc\b/i.test(trimmed) && !trimmed.includes('src/')) {
        return `src/${m[1]}`.replace(/\\/g, '/');
      }
      return trimmed.replace(/\\/g, '/');
    }
    // Try to extract filename like foo.js from free text
    const fname = trimmed.match(/([\w.-]+\.[A-Za-z0-9]+)\b/);
    if (fname) {
      const hasSrc = /\bsrc\b/i.test(trimmed);
      return (hasSrc ? `src/${fname[1]}` : fname[1]).replace(/\\/g, '/');
    }
    return undefined;
  }
}
