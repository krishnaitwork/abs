export interface AIProvider {
  name: string;
  displayName: string;
  baseUrl: string;
  models: AIModel[];
  apiKeyRequired: boolean;
  isLocal?: boolean;
}

export interface AIModel {
  id: string;
  name: string;
  contextLength: number;
  costPer1KTokens?: number;
  description?: string;
}

export interface ProviderConfig {
  apiKey?: string;
  baseUrl: string;
  models: string[];
  defaultModel: string;
  enabled: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  model?: string;
  tokens?: number;
}

export interface ChatConversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
  model: string;
}

export interface CompletionRequest {
  messages: ChatMessage[];
  model: string;
  maxTokens?: number;
  temperature?: number;
  stream?: boolean;
}

export interface CompletionResponse {
  content: string;
  model: string;
  tokens: {
    prompt: number;
    completion: number;
    total: number;
  };
  finishReason: string;
}

export enum OperatingMode {
  ASK = 'ask',
  AGENT = 'agent', 
  COPILOT = 'copilot'
}

export interface AgentTask {
  id: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'stopped';
  steps: AgentStep[];
  createdAt: Date;
  updatedAt: Date;
}

export interface AgentStep {
  id: string;
  description: string;
  action: string;
  parameters: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: any;
  requiresApproval?: boolean;
  approved?: boolean;
}

export interface DiffRange {
    startLine: number;
    endLine: number;
    startCharacter: number;
    endCharacter: number;
}

export interface DiffChange {
    type: 'insert' | 'delete' | 'replace';
    range: DiffRange;
    content?: string;
    originalContent?: string;
    description: string;
    severity: 'info' | 'warning' | 'error';
}

export interface DiffResult {
    changes: DiffChange[];
    summary: string;
    canApply: boolean;
    source: 'ai' | 'manual' | 'git';
}

export interface InlineDiffOptions {
    showInline: boolean;
    showGutter: boolean;
    showOverview: boolean;
    highlightChanges: boolean;
    autoApply: boolean;
}
