import axios from 'axios';
import { CompletionRequest, CompletionResponse } from '../types';
import { IAIProvider } from './ProviderFactory';

export class OpenAIProvider implements IAIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://api.openai.com/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  public async createCompletion(request: CompletionRequest): Promise<CompletionResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: request.model,
          messages: request.messages.map(msg => ({
            role: msg.role,
            content: msg.content
          })),
          max_tokens: request.maxTokens || 1000,
          temperature: request.temperature || 0.7,
          stream: request.stream || false
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`
          }
        }
      );

      const content = response.data.choices[0]?.message?.content || '';

      return {
        content: content,
        model: request.model,
        tokens: {
          prompt: response.data.usage?.prompt_tokens || 0,
          completion: response.data.usage?.completion_tokens || 0,
          total: response.data.usage?.total_tokens || 0
        },
        finishReason: response.data.choices[0]?.finish_reason || 'stop'
      };
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw new Error(`OpenAI API error: ${error}`);
    }
  }
}
