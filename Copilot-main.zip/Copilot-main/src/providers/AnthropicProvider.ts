import axios from 'axios';
import { CompletionRequest, CompletionResponse } from '../types';
import { IAIProvider } from './ProviderFactory';

export class AnthropicProvider implements IAIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://api.anthropic.com/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  public async createCompletion(request: CompletionRequest): Promise<CompletionResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/messages`,
        {
          model: request.model,
          max_tokens: request.maxTokens || 1000,
          temperature: request.temperature || 0.7,
          messages: request.messages.map(msg => ({
            role: msg.role,
            content: msg.content
          }))
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01'
          }
        }
      );

      const content = response.data.content[0]?.text || '';
      
      return {
        content: content,
        model: request.model,
        tokens: {
          prompt: response.data.usage?.input_tokens || 0,
          completion: response.data.usage?.output_tokens || 0,
          total: (response.data.usage?.input_tokens || 0) + (response.data.usage?.output_tokens || 0)
        },
        finishReason: response.data.stop_reason || 'stop'
      };
    } catch (error) {
      console.error('Anthropic API error:', error);
      throw new Error(`Anthropic API error: ${error}`);
    }
  }
}
