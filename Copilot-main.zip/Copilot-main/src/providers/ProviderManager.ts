import * as vscode from 'vscode';
import { AIModel, AIProvider, ProviderConfig } from '../types';

export class ProviderManager {
  private static instance: ProviderManager;
  private providers: Map<string, AIProvider> = new Map();
  private configs: Map<string, ProviderConfig> = new Map();
  private secretStorage: vscode.SecretStorage;
  private currentProvider: string = 'openai';
  private currentModel: string = 'gpt-4';

  constructor(secretStorage: vscode.SecretStorage) {
    this.secretStorage = secretStorage;
    this.initializeProviders();
    // Don't await loadSettings in constructor, make it sync
    this.loadSettingsSync();
  }

  private loadSettingsSync() {
    // Load saved provider and model from workspace settings synchronously
    try {
      const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
      const savedProvider = config.get<string>('currentProvider');
      const savedModel = config.get<string>('currentModel');

      console.log('ProviderManager: Loading settings - provider:', savedProvider, 'model:', savedModel);

      if (savedProvider && this.providers.has(savedProvider)) {
        this.currentProvider = savedProvider;
        if (savedModel) {
          const provider = this.providers.get(savedProvider);
          const modelExists = provider?.models.some(m => m.id === savedModel);
          if (modelExists) {
            this.currentModel = savedModel;
          }
        }
      }

      console.log('ProviderManager: Final settings - provider:', this.currentProvider, 'model:', this.currentModel);
    } catch (error) {
      console.error('ProviderManager: Error loading settings:', error);
    }
  }

  private async loadSettings() {
    // Keep this for backwards compatibility but make it sync
    this.loadSettingsSync();
  }

  private async saveSettings() {
    // Save current provider and model to workspace settings
    const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
    await config.update('currentProvider', this.currentProvider, vscode.ConfigurationTarget.Workspace);
    await config.update('currentModel', this.currentModel, vscode.ConfigurationTarget.Workspace);
  }

  public static getInstance(secretStorage?: vscode.SecretStorage): ProviderManager {
    if (!ProviderManager.instance && secretStorage) {
      ProviderManager.instance = new ProviderManager(secretStorage);
    }
    return ProviderManager.instance;
  }

  private initializeProviders() {
    // OpenAI Provider
    const openaiProvider: AIProvider = {
      name: 'openai',
      displayName: 'OpenAI',
      baseUrl: 'https://api.openai.com/v1',
      apiKeyRequired: true,
      models: [
        { id: 'gpt-4', name: 'GPT-4', contextLength: 8192, costPer1KTokens: 0.03 },
        { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', contextLength: 128000, costPer1KTokens: 0.01 },
        { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', contextLength: 4096, costPer1KTokens: 0.002 },
        { id: 'o1-preview', name: 'O1 Preview', contextLength: 32768, costPer1KTokens: 0.015 },
        { id: 'o1-mini', name: 'O1 Mini', contextLength: 65536, costPer1KTokens: 0.003 }
      ]
    };

    // Anthropic Provider
    const anthropicProvider: AIProvider = {
      name: 'anthropic',
      displayName: 'Anthropic',
      baseUrl: 'https://api.anthropic.com/v1',
      apiKeyRequired: true,
      models: [
        { id: 'claude-3-5-sonnet-20241022', name: 'Claude 3.5 Sonnet', contextLength: 200000, costPer1KTokens: 0.003 },
        { id: 'claude-3-haiku-20240307', name: 'Claude 3 Haiku', contextLength: 200000, costPer1KTokens: 0.00025 },
        { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus', contextLength: 200000, costPer1KTokens: 0.015 }
      ]
    };

    // Google Provider
    const googleProvider: AIProvider = {
      name: 'google',
      displayName: 'Google',
      baseUrl: 'https://generativelanguage.googleapis.com/v1',
      apiKeyRequired: true,
      models: [
        { id: 'gemini-pro', name: 'Gemini Pro', contextLength: 32768, costPer1KTokens: 0.0005 },
        { id: 'gemini-pro-vision', name: 'Gemini Pro Vision', contextLength: 16384, costPer1KTokens: 0.0025 },
        { id: 'gemini-ultra', name: 'Gemini Ultra', contextLength: 32768, costPer1KTokens: 0.001 }
      ]
    };

    // Azure OpenAI Provider
    const azureProvider: AIProvider = {
      name: 'azure',
      displayName: 'Azure OpenAI',
      baseUrl: 'https://your-resource.openai.azure.com',
      apiKeyRequired: true,
      models: [
        { id: 'gpt-4', name: 'GPT-4 (Azure)', contextLength: 8192 },
        { id: 'gpt-35-turbo', name: 'GPT-3.5 Turbo (Azure)', contextLength: 4096 }
      ]
    };

    // Ollama Provider (Local)
    const ollamaProvider: AIProvider = {
      name: 'ollama',
      displayName: 'Ollama (Local)',
      baseUrl: 'http://localhost:11434',
      apiKeyRequired: false,
      isLocal: true,
      models: [
        { id: 'llama3', name: 'Llama 3', contextLength: 8192 },
        { id: 'codellama', name: 'Code Llama', contextLength: 16384 },
        { id: 'mistral', name: 'Mistral', contextLength: 8192 }
      ]
    };

    // OpenRouter Provider
    const openrouterProvider: AIProvider = {
      name: 'openrouter',
      displayName: 'OpenRouter',
      baseUrl: 'https://openrouter.ai/api/v1',
      apiKeyRequired: true,
      models: [
        { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet (OpenRouter)', contextLength: 200000, costPer1KTokens: 0.003 },
        { id: 'openai/gpt-4-turbo', name: 'GPT-4 Turbo (OpenRouter)', contextLength: 128000, costPer1KTokens: 0.01 },
        { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini (OpenRouter)', contextLength: 128000, costPer1KTokens: 0.0001 },
        { id: 'openai/gpt-3.5-turbo', name: 'GPT-3.5 Turbo (OpenRouter)', contextLength: 4096, costPer1KTokens: 0.002 },
        { id: 'openai/gpt-oss-20b:free', name: 'GPT OSS 20B Free (OpenRouter)', contextLength: 32768, costPer1KTokens: 0 },
        { id: 'meta-llama/llama-3.1-8b-instruct:free', name: 'Llama 3.1 8B Free (OpenRouter)', contextLength: 131072, costPer1KTokens: 0 },
        { id: 'mistralai/mistral-7b-instruct:free', name: 'Mistral 7B Free (OpenRouter)', contextLength: 32768, costPer1KTokens: 0 },
        { id: 'google/gemini-pro', name: 'Gemini Pro (OpenRouter)', contextLength: 32768, costPer1KTokens: 0.0005 }
      ]
    };

    this.providers.set('openai', openaiProvider);
    this.providers.set('anthropic', anthropicProvider);
    this.providers.set('google', googleProvider);
    this.providers.set('azure', azureProvider);
    this.providers.set('ollama', ollamaProvider);
    this.providers.set('openrouter', openrouterProvider);
  }

  public async setApiKey(provider: string, apiKey: string): Promise<void> {
    await this.secretStorage.store(`kp-ai-${provider}-key`, apiKey);
  }

  public async getApiKey(provider: string): Promise<string | undefined> {
    return await this.secretStorage.get(`kp-ai-${provider}-key`);
  }

  public getProviders(): AIProvider[] {
    return Array.from(this.providers.values());
  }

  public getProvider(name: string): AIProvider | undefined {
    return this.providers.get(name);
  }

  public getCurrentProvider(): string {
    console.log('ProviderManager: getCurrentProvider() returning:', this.currentProvider);
    return this.currentProvider;
  }

  public getCurrentModel(): string {
    console.log('ProviderManager: getCurrentModel() returning:', this.currentModel);
    return this.currentModel;
  }

  public forceReloadSettings(): void {
    console.log('ProviderManager: Force reloading settings');
    this.loadSettingsSync();
    console.log('ProviderManager: After reload - provider:', this.currentProvider, 'model:', this.currentModel);
  }

  public setCurrentProvider(provider: string): void {
    if (this.providers.has(provider)) {
      this.currentProvider = provider;
      const providerData = this.providers.get(provider);
      if (providerData && providerData.models.length > 0) {
        this.currentModel = providerData.models[0].id;
      }
      this.saveSettings(); // Persist the selection
    }
  }

  public setCurrentModel(model: string): void {
    const provider = this.providers.get(this.currentProvider);
    if (provider && provider.models.some(m => m.id === model)) {
      this.currentModel = model;
      this.saveSettings(); // Persist the selection
    }
  }

  public getModelsForProvider(provider: string): AIModel[] {
    const providerData = this.providers.get(provider);
    return providerData ? providerData.models : [];
  }

  public async testConnection(provider: string): Promise<boolean> {
    try {
      const providerData = this.providers.get(provider);
      if (!providerData) return false;

      if (providerData.apiKeyRequired) {
        const apiKey = await this.getApiKey(provider);
        if (!apiKey) return false;
      }

      // Simple test - would implement actual API call
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Get provider-specific configuration
   * @param provider Provider name
   * @param key Configuration key
   * @returns Configuration value or undefined
   */
  public async getProviderConfig(provider: string, key: string): Promise<string | undefined> {
    try {
      const configKey = `kp-ai-${provider}-${key}`;
      return await this.secretStorage.get(configKey);
    } catch (error) {
      console.error(`Error getting provider config for ${provider}.${key}:`, error);
      return undefined;
    }
  }

  /**
   * Set provider-specific configuration
   * @param provider Provider name
   * @param key Configuration key
   * @param value Configuration value
   */
  public async setProviderConfig(provider: string, key: string, value: string): Promise<void> {
    try {
      const configKey = `kp-ai-${provider}-${key}`;
      await this.secretStorage.store(configKey, value);
    } catch (error) {
      console.error(`Error setting provider config for ${provider}.${key}:`, error);
    }
  }
}
