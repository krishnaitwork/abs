import { CompletionRequest, CompletionResponse } from '../types';
import { AnthropicProvider } from './AnthropicProvider';
import { GoogleProvider } from './GoogleProvider';
import { OpenAIProvider } from './OpenAIProvider';
import { OpenRouterProvider } from './OpenRouterProvider';
import { ProviderManager } from './ProviderManager';
import { ProviderRegistry } from './ProviderRegistry';

export interface IAIProvider {
    createCompletion(request: CompletionRequest): Promise<CompletionResponse>;
}

export class ProviderFactory {
    private static instance: ProviderFactory;
    private providers: Map<string, new (apiKey: string, ...args: any[]) => IAIProvider> = new Map();
    private providerManager: ProviderManager;

    private constructor(providerManager: ProviderManager) {
        this.providerManager = providerManager;
        this.registerDefaultProviders();
        // Register additional providers from registry
        ProviderRegistry.registerProviders(this);
    }

    public static getInstance(providerManager: ProviderManager): ProviderFactory {
        if (!ProviderFactory.instance) {
            ProviderFactory.instance = new ProviderFactory(providerManager);
        }
        return ProviderFactory.instance;
    }

    private registerDefaultProviders(): void {
        // Register core providers
        this.registerProvider('openai', OpenAIProvider);
        this.registerProvider('openrouter', OpenRouterProvider);
        this.registerProvider('anthropic', AnthropicProvider);
        this.registerProvider('google', GoogleProvider);
    }

    /**
     * Register a new provider type
     * @param name Provider name (e.g., 'azure', 'ollama')
     * @param providerClass Provider class constructor
     */
    public registerProvider(name: string, providerClass: new (apiKey: string, ...args: any[]) => IAIProvider): void {
        this.providers.set(name, providerClass);
        console.log(`Registered provider: ${name}`);
    }

    /**
     * Get a provider instance by name
     * @param providerName Provider name
     * @returns Provider instance
     */
    public async getProvider(providerName: string): Promise<IAIProvider | null> {
        try {
            const ProviderClass = this.providers.get(providerName);
            if (!ProviderClass) {
                console.warn(`Provider '${providerName}' not registered`);
                return null;
            }

            const apiKey = await this.providerManager.getApiKey(providerName);
            if (!apiKey) {
                console.warn(`API key not configured for provider '${providerName}'`);
                return null;
            }

            // Check if provider needs additional configuration
            if (ProviderRegistry.requiresAdditionalConfig(providerName)) {
                // For providers like Azure OpenAI that need baseUrl and deployment
                const config = ProviderRegistry.getProviderConfig(providerName);
                if (config) {
                    // Get additional config from provider manager or settings
                    const baseUrl = await this.providerManager.getProviderConfig(providerName, 'baseUrl') || config.baseUrl;
                    const deploymentName = await this.providerManager.getProviderConfig(providerName, 'deploymentName') || config.deploymentName;
                    return new ProviderClass(apiKey, baseUrl, deploymentName);
                }
            }

            return new ProviderClass(apiKey);
        } catch (error) {
            console.error(`Error creating provider '${providerName}':`, error);
            return null;
        }
    }

    /**
     * Get the current active provider
     * @returns Current provider instance
     */
    public async getCurrentProvider(): Promise<IAIProvider | null> {
        const currentProviderName = this.providerManager.getCurrentProvider();
        return await this.getProvider(currentProviderName);
    }

    /**
     * Check if a provider is supported
     * @param providerName Provider name
     * @returns True if provider is supported
     */
    public isProviderSupported(providerName: string): boolean {
        return this.providers.has(providerName);
    }

    /**
     * Get list of all registered provider names
     * @returns Array of provider names
     */
    public getRegisteredProviders(): string[] {
        return Array.from(this.providers.keys());
    }

    /**
     * Create completion using the current provider
     * @param request Completion request
     * @returns Completion response
     */
    public async createCompletion(request: CompletionRequest): Promise<CompletionResponse> {
        const provider = await this.getCurrentProvider();
        if (!provider) {
            throw new Error('No provider available. Please check your configuration.');
        }

        return await provider.createCompletion(request);
    }

    /**
     * Create completion using a specific provider
     * @param providerName Provider name
     * @param request Completion request
     * @returns Completion response
     */
    public async createCompletionWithProvider(
        providerName: string,
        request: CompletionRequest
    ): Promise<CompletionResponse> {
        const provider = await this.getProvider(providerName);
        if (!provider) {
            throw new Error(`Provider '${providerName}' not available or not configured.`);
        }

        return await provider.createCompletion(request);
    }

    /**
     * Get provider configuration information
     * @param providerName Provider name
     * @returns Provider configuration object
     */
    public getProviderInfo(providerName: string): any {
        return ProviderRegistry.getProviderConfig(providerName);
    }

    /**
     * Get all available provider configurations
     * @returns Object with all provider configurations
     */
    public getAllProviderInfo(): { [key: string]: any } {
        const info: { [key: string]: any } = {};
        for (const providerName of this.getRegisteredProviders()) {
            info[providerName] = this.getProviderInfo(providerName);
        }
        return info;
    }
}
