import axios from 'axios';
import { CompletionRequest, CompletionResponse } from '../types';
import { IAIProvider } from './ProviderFactory';

export class GoogleProvider implements IAIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://generativelanguage.googleapis.com/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  public async createCompletion(request: CompletionRequest): Promise<CompletionResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/models/${request.model}:generateContent?key=${this.apiKey}`,
        {
          contents: request.messages.map(msg => ({
            role: msg.role === 'assistant' ? 'model' : msg.role,
            parts: [{ text: msg.content }]
          })),
          generationConfig: {
            maxOutputTokens: request.maxTokens || 1000,
            temperature: request.temperature || 0.7
          }
        },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );

      const content = response.data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      
      return {
        content: content,
        model: request.model,
        tokens: {
          prompt: response.data.usageMetadata?.promptTokenCount || 0,
          completion: response.data.usageMetadata?.candidatesTokenCount || 0,
          total: (response.data.usageMetadata?.promptTokenCount || 0) + (response.data.usageMetadata?.candidatesTokenCount || 0)
        },
        finishReason: response.data.candidates?.[0]?.finishReason || 'stop'
      };
    } catch (error) {
      console.error('Google Gemini API error:', error);
      throw new Error(`Google Gemini API error: ${error}`);
    }
  }
}
