import { AzureOpenAIProvider } from './AzureOpenAIProvider';
import { ProviderFactory } from './ProviderFactory';

/**
 * Provider Registry - Centralized configuration for all AI providers
 * 
 * To add a new provider:
 * 1. Create the provider class implementing IAIProvider
 * 2. Add it to the registerProviders() method below
 * 3. That's it! No other files need to be modified.
 */
export class ProviderRegistry {

    /**
     * Register all available providers with the factory
     * @param factory The provider factory instance
     */
    public static registerProviders(factory: ProviderFactory): void {
        // Register Azure OpenAI provider
        factory.registerProvider('azure-openai', AzureOpenAIProvider);

        // Example: Register Ollama provider (local models)
        // factory.registerProvider('ollama', OllamaProvider);

        // Example: Register Cohere provider
        // factory.registerProvider('cohere', CohereProvider);

        // Example: Register Hugging Face provider
        // factory.registerProvider('huggingface', HuggingFaceProvider);

        // Example: Register custom enterprise provider
        // factory.registerProvider('enterprise', EnterpriseAIProvider);
    }

    /**
     * Get provider configuration details
     * @param providerName Provider name
     * @returns Provider configuration object
     */
    public static getProviderConfig(providerName: string): any {
        const configs: { [key: string]: any } = {
            'openai': {
                name: 'OpenAI',
                models: ['gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo', 'o1-preview', 'o1-mini'],
                baseUrl: 'https://api.openai.com/v1',
                authType: 'bearer'
            },
            'anthropic': {
                name: 'Anthropic',
                models: ['claude-3-5-sonnet', 'claude-3-haiku', 'claude-3-opus'],
                baseUrl: 'https://api.anthropic.com/v1',
                authType: 'x-api-key'
            },
            'google': {
                name: 'Google Gemini',
                models: ['gemini-pro', 'gemini-pro-vision', 'gemini-ultra'],
                baseUrl: 'https://generativelanguage.googleapis.com/v1',
                authType: 'api-key'
            },
            'openrouter': {
                name: 'OpenRouter',
                models: ['openai/gpt-4', 'anthropic/claude-3-5-sonnet', 'meta-llama/llama-3-8b'],
                baseUrl: 'https://openrouter.ai/api/v1',
                authType: 'bearer'
            },
            'azure-openai': {
                name: 'Azure OpenAI',
                models: ['gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo'],
                baseUrl: 'https://your-resource.openai.azure.com',
                authType: 'api-key',
                requiresDeployment: true
            }
        };

        return configs[providerName] || null;
    }

    /**
     * Get all registered provider names
     * @returns Array of provider names
     */
    public static getRegisteredProviderNames(): string[] {
        return [
            'openai',
            'anthropic',
            'google',
            'openrouter',
            'azure-openai'
        ];
    }

    /**
     * Check if a provider requires additional configuration
     * @param providerName Provider name
     * @returns True if additional config is needed
     */
    public static requiresAdditionalConfig(providerName: string): boolean {
        const config = this.getProviderConfig(providerName);
        return config?.requiresDeployment || false;
    }
}
