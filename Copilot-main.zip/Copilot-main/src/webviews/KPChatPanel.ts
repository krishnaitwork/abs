import * as vscode from 'vscode';
import { KPAgentMode } from '../modes/AgentMode';
import { KPChatMode } from '../modes/ChatMode';
import { ProviderManager } from '../providers/ProviderManager';

export class KPChatPanel {
  public static currentPanel: KPChatPanel | undefined;
  private readonly _panel: vscode.WebviewPanel;
  private readonly _extensionUri: vscode.Uri;
  private readonly chatMode: KPChatMode;
  private readonly agentMode: KPAgentMode;
  private readonly providerManager: ProviderManager;

  public static readonly viewType = 'kpAiAssistant.chatPanel';

  public static createOrShow(extensionUri: vscode.Uri, providerManager?: ProviderManager) {
    // Get user's preferred chat location from settings
    const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
    const chatLocation = config.get<string>('chatLocation', 'beside');

    let column: vscode.ViewColumn;
    switch (chatLocation) {
      case 'sidebar':
        // Use ViewColumn.Two to create a proper sidebar panel
        column = vscode.ViewColumn.Two;
        break;
      case 'editor':
        // Use ViewColumn.One to open in the main editor area
        column = vscode.ViewColumn.One;
        break;
      case 'beside':
      default:
        // Use ViewColumn.Two for proper side panel (main editor stays in ViewColumn.One)
        column = vscode.ViewColumn.Two;
        break;
    }

    if (KPChatPanel.currentPanel) {
      KPChatPanel.currentPanel._panel.reveal(column);
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      KPChatPanel.viewType,
      'KP AI Assistant Chat',
      column,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [extensionUri]
      }
    );

    KPChatPanel.currentPanel = new KPChatPanel(panel, extensionUri, providerManager);
  }

  private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri, providerManager?: ProviderManager) {
    this._panel = panel;
    this._extensionUri = extensionUri;
    this.providerManager = providerManager || ProviderManager.getInstance();
    this.chatMode = new KPChatMode(this.providerManager);
    this.agentMode = new KPAgentMode(this.providerManager);
    this._panel.webview.html = this._getHtmlForWebview();
    this._setupWebviewMessageListener();
    this._panel.onDidDispose(() => {
      KPChatPanel.currentPanel = undefined;
    }, null, []);
  }

  private _getHtmlForWebview(): string {
    return `<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KP AI Assistant</title>
        <style>
    * {
            margin: 0; 
            padding: 0; 
      box-sizing: border-box;
    }

    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
      background: #0d1117;
      color: #f0f6fc;
            display: flex;
            flex-direction: column;
            height: 100vh;
      overflow: hidden;
          }

    /* Header Styles */
          .header { 
      background: linear-gradient(135deg, #1f6feb 0%, #0969da 100%);
      padding: 12px 16px;
      border-bottom: 1px solid #30363d;
            flex-shrink: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
          }

          .header-title {
            display: flex;
            align-items: center;
      gap: 10px;
      font-size: 16px;
      font-weight: 600;
    }

    .kp-logo { 
      background: linear-gradient(135deg, #00cfff 0%, #0099cc 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      font-weight: 800;
      font-size: 20px;
      text-shadow: 0 0 16px rgba(0, 207, 255, 0.3);
    }

          .header-actions {
            display: flex;
      gap: 6px;
          }

          .settings-btn {
      background: rgba(255,255,255,0.15);
      border: 1px solid rgba(255,255,255,0.2);
      border-radius: 6px;
            color: white;
            width: 32px;
            height: 32px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
      font-size: 14px;
      transition: all 0.2s ease;
      backdrop-filter: blur(10px);
          }

          .settings-btn:hover {
      background: rgba(255,255,255,0.25);
      border-color: rgba(255,255,255,0.3);
      transform: translateY(-1px);
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }

    /* Navigation Tabs */
    .nav-tabs {
      background: #161b22;
      border-bottom: 1px solid #30363d;
      padding: 0 16px;
      flex-shrink: 0;
      display: flex;
      gap: 1px;
    }

    .nav-tab {
      background: transparent;
      border: none;
      color: #8b949e;
      padding: 12px 18px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 500;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
      position: relative;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .nav-tab:hover {
      color: #f0f6fc;
      background: rgba(177, 186, 196, 0.08);
    }

    .nav-tab.active {
      color: #58a6ff;
      border-bottom-color: #58a6ff;
      background: rgba(88, 166, 255, 0.1);
    }

    .nav-tab-icon {
      font-size: 14px;
      opacity: 0.8;
    }

    /* Main Content Area */
    .main-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .content-header {
      background: #161b22;
      padding: 12px 16px;
      border-bottom: 1px solid #30363d;
      flex-shrink: 0;
    }

    .content-title {
      font-size: 14px;
      font-weight: 600;
      color: #f0f6fc;
      margin-bottom: 6px;
    }

    .content-subtitle {
      font-size: 12px;
      color: #8b949e;
      line-height: 1.3;
    }

    /* Chat Container */
          .chat-container { 
            flex: 1;
            overflow-y: auto;
            padding: 16px; 
      background: #0d1117;
    }

    .chat-container::-webkit-scrollbar {
      width: 6px;
    }

    .chat-container::-webkit-scrollbar-track {
      background: #161b22;
    }

    .chat-container::-webkit-scrollbar-thumb {
      background: #30363d;
      border-radius: 3px;
    }

    .chat-container::-webkit-scrollbar-thumb:hover {
      background: #484f58;
    }

    /* Message Styles */
          .message {
            margin-bottom: 16px;
      padding: 16px;
            border-radius: 8px;
      border: 1px solid transparent;
      transition: all 0.2s ease;
      position: relative;
          }

    .message:hover {
      border-color: #30363d;
    }

          .message.user {
      background: linear-gradient(135deg, #1f6feb 0%, #0969da 100%);
      margin-left: 32px;
      margin-right: 0;
      box-shadow: 0 3px 12px rgba(31, 111, 235, 0.2);
    }

          .message.assistant {
      background: #161b22;
      margin-right: 32px;
      margin-left: 0;
      border: 1px solid #30363d;
      box-shadow: 0 3px 12px rgba(0,0,0,0.1);
    }

          .message.error {
      background: linear-gradient(135deg, #da3633 0%, #b62324 100%);
      margin-right: 32px;
      margin-left: 0;
      box-shadow: 0 3px 12px rgba(218, 54, 51, 0.2);
    }

    .message-header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 10px;
      font-size: 12px;
      font-weight: 600;
    }

    .message-avatar {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: 700;
    }

    .message.user .message-avatar {
      background: rgba(255,255,255,0.2);
      color: white;
    }

    .message.assistant .message-avatar {
      background: linear-gradient(135deg, #00cfff 0%, #0099cc 100%);
      color: white;
    }

    .message.error .message-avatar {
      background: rgba(255,255,255,0.2);
      color: white;
    }

    .message-content {
      line-height: 1.5;
      font-size: 13px;
    }

    .message-content p {
      margin-bottom: 8px;
    }

    .message-content p:last-child {
      margin-bottom: 0;
    }

    /* Code Block Styles */
    .code-block {
      background: #0d1117;
      border: 1px solid #30363d;
      border-radius: 6px;
      margin: 12px 0;
      overflow: hidden;
      position: relative;
    }

    .code-header {
      background: #161b22;
      padding: 8px 12px;
      border-bottom: 1px solid #30363d;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .code-language {
      font-size: 11px;
      font-weight: 600;
      color: #8b949e;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .code-actions {
      display: flex;
      gap: 6px;
    }

    .code-action-btn {
      background: transparent;
      border: 1px solid #30363d;
      color: #8b949e;
      padding: 3px 6px;
      border-radius: 3px;
      cursor: pointer;
      font-size: 10px;
      transition: all 0.2s ease;
    }

    .code-action-btn:hover {
      background: #30363d;
      color: #f0f6fc;
      border-color: #484f58;
    }

    .code-content {
      padding: 12px;
      overflow-x: auto;
      font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
      font-size: 12px;
      line-height: 1.4;
      color: #f0f6fc;
    }

    .code-content pre {
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
    }

    /* Inline Code */
    .inline-code {
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 3px;
      padding: 1px 4px;
      font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
      font-size: 12px;
      color: #58a6ff;
    }

    /* Input Container */
          .input-container {
      background: #161b22;
      border-top: 1px solid #30363d;
            padding: 16px;
            flex-shrink: 0;
          }

          .input-row {
            display: flex;
      gap: 10px;
      align-items: flex-end;
          }

    .input-wrapper {
            flex: 1;
      position: relative;
    }

    #messageInput {
      width: 100%;
      min-height: 40px;
      max-height: 100px;
      padding: 10px 12px;
      background: #0d1117;
      border: 2px solid #30363d;
      border-radius: 8px;
      color: #f0f6fc;
      font-size: 13px;
      line-height: 1.4;
      resize: vertical;
      transition: all 0.2s ease;
      font-family: inherit;
    }

    #messageInput:focus {
      outline: none;
      border-color: #58a6ff;
      box-shadow: 0 0 0 2px rgba(88, 166, 255, 0.1);
    }

    #messageInput::placeholder {
      color: #8b949e;
    }

          #sendButton {
      background: linear-gradient(135deg, #1f6feb 0%, #0969da 100%);
            border: none;
      border-radius: 8px;
      color: white;
      padding: 10px 20px;
            cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      transition: all 0.2s ease;
      min-width: 70px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }

          #sendButton:hover {
      transform: translateY(-1px);
      box-shadow: 0 3px 12px rgba(31, 111, 235, 0.3);
    }

    #sendButton:active {
      transform: translateY(0);
    }

    #sendButton:disabled {
      background: #30363d !important;
      color: #8b949e !important;
      cursor: not-allowed !important;
      opacity: 0.6 !important;
    }

    #sendButton:not(:disabled) {
      background: linear-gradient(135deg, #1f6feb 0%, #0969da 100%) !important;
      color: white !important;
      cursor: pointer !important;
      opacity: 1 !important;
    }

    .send-icon {
      font-size: 14px;
    }

    /* Footer */
          .footer { 
      background: #0d1117;
      border-top: 1px solid #30363d;
      padding: 10px 16px;
            text-align: center; 
      font-size: 11px;
      color: #8b949e;
            flex-shrink: 0;
          }

    /* Model Info */
    .model-info {
      background: rgba(88, 166, 255, 0.1);
      border: 1px solid rgba(88, 166, 255, 0.2);
      border-radius: 6px;
      padding: 6px 10px;
      margin-top: 10px;
      font-size: 11px;
      color: #58a6ff;
      display: inline-block;
    }

    /* Agent Status */
    .agent-status {
      background: linear-gradient(135deg, #6f42c1 0%, #5a32a3 100%);
      color: white;
      padding: 10px 12px;
      border-radius: 6px;
      margin: 12px 0;
      font-size: 12px;
      display: inline-block;
      box-shadow: 0 3px 12px rgba(111, 66, 193, 0.2);
    }

    .agent-step {
      background: #161b22;
      border: 1px solid #30363d;
      color: #f0f6fc;
      padding: 10px 12px;
      border-radius: 6px;
      margin: 6px 0;
      font-size: 12px;
      display: block;
      border-left: 3px solid #58a6ff;
    }

    /* Typing Indicator */
          .typing {
            opacity: 0.7;
            font-style: italic;
      color: #8b949e;
    }

    .typing-dots {
      display: inline-block;
      animation: typing 1.4s infinite;
    }

    @keyframes typing {
      0%, 20% { opacity: 0; }
      50% { opacity: 1; }
      100% { opacity: 0; }
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .header {
        padding: 10px 12px;
      }
      
      .nav-tabs {
        padding: 0 12px;
      }
      
      .nav-tab {
        padding: 10px 12px;
        font-size: 12px;
      }
      
      .chat-container {
        padding: 12px;
      }
      
      .message {
        margin-left: 16px;
        margin-right: 16px;
      }
      
      .input-container {
        padding: 12px;
      }
    }

    /* Welcome Message */
    .welcome-message {
      text-align: center;
      padding: 32px 16px;
      color: #8b949e;
    }

    .welcome-icon {
      font-size: 36px;
      margin-bottom: 12px;
      opacity: 0.6;
    }

    .welcome-title {
      font-size: 20px;
      font-weight: 600;
      color: #f0f6fc;
      margin-bottom: 10px;
    }

    .welcome-subtitle {
      font-size: 14px;
      line-height: 1.5;
      margin-bottom: 20px;
    }

    .welcome-features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 12px;
      margin-top: 20px;
    }

    .feature-card {
      background: #161b22;
      border: 1px solid #30363d;
            border-radius: 6px;
      padding: 12px;
      text-align: left;
    }

    .feature-icon {
      font-size: 20px;
      margin-bottom: 6px;
      color: #58a6ff;
    }

    .feature-title {
      font-size: 12px;
      font-weight: 600;
      color: #f0f6fc;
      margin-bottom: 3px;
    }

    .feature-desc {
      font-size: 11px;
      color: #8b949e;
      line-height: 1.3;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-title">
      <span class="kp-logo">KP</span> AI Assistant
          </div>
          <div class="header-actions">
      <button class="settings-btn" id="settingsBtn" title="Open Settings">⚙️</button>
          </div>
        </div>

  <div class="nav-tabs">
    <button class="nav-tab active" data-mode="ask" id="askTab">
      <span class="nav-tab-icon">💬</span>
      Ask
    </button>
    <button class="nav-tab" data-mode="edit" id="editTab">
      <span class="nav-tab-icon">✏️</span>
      Edit
    </button>
    <button class="nav-tab" data-mode="explain" id="explainTab">
      <span class="nav-tab-icon">📖</span>
      Explain
    </button>
    <button class="nav-tab" data-mode="agent" id="agentTab">
      <span class="nav-tab-icon">🤖</span>
      Agent
    </button>
  </div>

  <div class="main-content">
    <div class="content-header">
      <div class="content-title" id="contentTitle">Ask me anything about coding</div>
      <div class="content-subtitle" id="contentSubtitle">I can help you with code explanations, debugging, refactoring, and more</div>
    </div>

        <div class="chat-container" id="chatContainer">
      <div class="welcome-message">
        <div class="welcome-icon">🚀</div>
        <div class="welcome-title">Welcome to KP AI Assistant</div>
        <div class="welcome-subtitle">Your intelligent coding companion powered by advanced AI models</div>
        <div class="welcome-features">
          <div class="feature-card">
            <div class="feature-icon">💡</div>
            <div class="feature-title">Smart Code Analysis</div>
            <div class="feature-desc">Understand and explain complex code structures</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🔧</div>
            <div class="feature-title">Code Refactoring</div>
            <div class="feature-desc">Improve code quality and maintainability</div>
        </div>
          <div class="feature-card">
            <div class="feature-icon">🧪</div>
            <div class="feature-title">Test Generation</div>
            <div class="feature-desc">Create comprehensive test suites</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🤖</div>
            <div class="feature-title">AI Agent</div>
            <div class="feature-desc">Execute complex multi-step tasks</div>
          </div>
        </div>
      </div>
    </div>

    <div class="input-container">
          <div class="input-row">
        <div class="input-wrapper">
          <textarea 
            id="messageInput" 
            placeholder="Ask me anything about coding..."
            rows="1"
          ></textarea>
          </div>
        <button id="sendButton">
          <span class="send-icon">➤</span>
          Send
        </button>
        </div>
    </div>
  </div>

     <div class="footer">
     Powered by <span class="kp-logo">KP</span> AI &copy; 2025 • Model: <span id="currentModel">Loading...</span>
   </div>
        
        <script>
          const vscode = acquireVsCodeApi();
          const messageInput = document.getElementById('messageInput');
          const sendButton = document.getElementById('sendButton');
          const chatContainer = document.getElementById('chatContainer');
    const contentTitle = document.getElementById('contentTitle');
    const contentSubtitle = document.getElementById('contentSubtitle');
    const settingsBtn = document.getElementById('settingsBtn');
    const askTab = document.getElementById('askTab');
    const editTab = document.getElementById('editTab');
    const explainTab = document.getElementById('explainTab');
    const agentTab = document.getElementById('agentTab');
    
          let currentMode = 'ask';
          let streamingMessageId = null;
    
    // Function to update send button state
    function updateSendButtonState() {
      if (sendButton && messageInput) {
        const hasText = messageInput.value.trim().length > 0;
        sendButton.disabled = !hasText;
        console.log('Send button state updated:', { hasText, disabled: !hasText });
      }
    }

    // Auto-resize textarea
    if (messageInput) {
      messageInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        // Update button state when input changes
        updateSendButtonState();
      });

      // Enter to send, Shift+Enter for new line
      messageInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
    }
          
          function setMode(mode) {
            currentMode = mode;
      
      // Remove active class from all tabs
      askTab.classList.remove('active');
      editTab.classList.remove('active');
      explainTab.classList.remove('active');
      agentTab.classList.remove('active');
      
      // Add active class to selected tab
      switch(mode) {
        case 'ask':
          askTab.classList.add('active');
          break;
        case 'edit':
          editTab.classList.add('active');
          break;
        case 'explain':
          explainTab.classList.add('active');
          break;
        case 'agent':
          agentTab.classList.add('active');
          break;
      }
      
      // Update content header based on mode
      const modeConfigs = {
        ask: {
          title: 'Ask me anything about coding',
          subtitle: 'I can help you with code explanations, debugging, refactoring, and more'
        },
        edit: {
          title: 'Edit and improve your code',
          subtitle: 'Describe the changes you want to make and I\'ll help you implement them'
        },
        explain: {
          title: 'Get code explanations and insights',
          subtitle: 'I\'ll break down complex code and explain how it works'
        },
        agent: {
          title: 'AI Agent Mode',
          subtitle: 'Let me execute complex multi-step tasks autonomously'
        }
      };
      
      const config = modeConfigs[mode];
      contentTitle.textContent = config.title;
      contentSubtitle.textContent = config.subtitle;
      
      // Update placeholder
            const placeholders = {
        ask: 'Ask me anything about coding...',
              edit: 'Describe the changes you want to make...',
              explain: 'Ask me to explain code or concepts...',
        agent: 'Describe a task for the AI agent to execute...'
            };
            messageInput.placeholder = placeholders[mode];
          }
          
          function sendMessage() {
            const message = messageInput.value.trim();
      if (!message) return;
      
      // Add user message to chat
      addMessage('user', message);
      
      // Clear input
      messageInput.value = '';
      messageInput.style.height = 'auto';
      
      // Update button state after clearing input
      updateSendButtonState();
      
      // Send to extension
              vscode.postMessage({
                command: 'sendMessage',
        message: message,
                mode: currentMode
              });
      
      // Show typing indicator
      showTypingIndicator();
    }

    function addMessage(role, content, metadata = {}) {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + role;
      
      const avatar = role === 'user' ? '👤' : role === 'assistant' ? '🤖' : '❌';
      const name = role === 'user' ? 'You' : 'KP AI';
      
      let messageContent = content;
      
      // Format code blocks
      if (content.includes('\`\`\`')) {
        messageContent = formatCodeBlocks(content);
      }
      
      // Format inline code
      messageContent = formatInlineCode(messageContent);
      
      messageDiv.innerHTML = \`
        <div class="message-header">
          <div class="message-avatar">\${avatar}</div>
          <span>\${name}</span>
          \${metadata.timestamp ? '<span style="color: #8b949e; font-weight: normal;">• ' + metadata.timestamp + '</span>' : ''}
        </div>
        <div class="message-content">\${messageContent}</div>
      \`;
      
      // Remove typing indicator if present
      const typingIndicator = chatContainer.querySelector('.typing-indicator');
      if (typingIndicator) {
        typingIndicator.remove();
      }
      
      chatContainer.appendChild(messageDiv);
      chatContainer.scrollTop = chatContainer.scrollHeight;
      
      return messageDiv;
    }

    function formatCodeBlocks(content) {
      return content.replace(/\`\`\`(\w+)?\n([\s\S]*?)\n\`\`\`/g, function(match, language, code) {
        const lang = language || 'text';
        return \`
          <div class="code-block">
            <div class="code-header">
              <span class="code-language">\${lang}</span>
              <div class="code-actions">
                <button class="code-action-btn" onclick="copyCode(this)">Copy</button>
              </div>
            </div>
            <div class="code-content">
              <pre>\${escapeHtml(code)}</pre>
            </div>
          </div>
        \`;
      });
    }

    function formatInlineCode(content) {
      return content.replace(/\`([^\`]+)\`/g, '<code class="inline-code">$1</code>');
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function copyCode(button) {
      const codeBlock = button.closest('.code-block');
      const codeContent = codeBlock.querySelector('pre').textContent;
      
      navigator.clipboard.writeText(codeContent).then(() => {
        const originalText = button.textContent;
        button.textContent = 'Copied!';
        button.style.background = '#28a745';
        button.style.color = 'white';
        
        setTimeout(() => {
          button.textContent = originalText;
          button.style.background = '';
          button.style.color = '';
        }, 2000);
      });
    }

    function showTypingIndicator() {
            const typingDiv = document.createElement('div');
      typingDiv.className = 'message assistant typing-indicator';
      typingDiv.innerHTML = \`
        <div class="message-header">
          <div class="message-avatar">🤖</div>
          <span>KP AI</span>
        </div>
        <div class="message-content">
          <span class="typing">Thinking<span class="typing-dots">...</span></span>
        </div>
      \`;
      
            chatContainer.appendChild(typingDiv);
            chatContainer.scrollTop = chatContainer.scrollHeight;
          }
          
          function openSettings() {
            vscode.postMessage({
              command: 'openSettings'
            });
          }
          
        // Event listeners
    if (sendButton) {
          sendButton.addEventListener('click', sendMessage);
      // Initialize send button state based on input content
      updateSendButtonState();
    }
    
    // Tab navigation event listeners
    if (askTab) askTab.addEventListener('click', () => setMode('ask'));
    if (editTab) editTab.addEventListener('click', () => setMode('edit'));
    if (explainTab) explainTab.addEventListener('click', () => setMode('explain'));
    if (agentTab) agentTab.addEventListener('click', () => setMode('agent'));
    
    // Settings button event listener
    if (settingsBtn) {
      settingsBtn.addEventListener('click', openSettings);
    }
    
    // Handle messages from extension
          window.addEventListener('message', event => {
            const message = event.data;
      
            switch (message.command) {
              case 'addMessage':
          addMessage(message.role, message.content, message.metadata);
                break;
        case 'updateMessage':
          // Update existing message (for streaming)
          break;
                 case 'clearChat':
           chatContainer.innerHTML = '';
           break;
         case 'updateModelInfo':
           // Update the model information in the footer
           const modelSpan = document.getElementById('currentModel');
           if (modelSpan && message.provider && message.model) {
             modelSpan.textContent = message.provider + ' - ' + message.model;
           }
           break;
       }
     });

     // Focus input on load and initialize button state
     if (messageInput) {
       messageInput.focus();
       // Initial button state check
       updateSendButtonState();
     }

     // Update model information in footer
     function updateModelInfo() {
       const modelSpan = document.getElementById('currentModel');
       if (modelSpan) {
         // Get model info from extension
         vscode.postMessage({
           command: 'getModelInfo'
         });
       }
     }

     // Call updateModelInfo after a short delay to ensure everything is loaded
     setTimeout(updateModelInfo, 100);
   </script>
      </body>
</html>`;
  }

  private _setupWebviewMessageListener() {
    this._panel.webview.onDidReceiveMessage(
      async message => {
        switch (message.command) {
          case 'sendMessage':
            try {
              if (message.mode === 'agent') {
                // Handle agent mode specially
                this._panel.webview.postMessage({
                  command: 'addMessage',
                  content: message.message,
                  role: 'user'
                });

                this._panel.webview.postMessage({
                  command: 'addMessage',
                  content: 'KP AI Agent: Starting autonomous task execution...',
                  role: 'assistant'
                });

                // Execute agent task
                const agentTask = await this.agentMode.startTask(message.message);

                this._panel.webview.postMessage({
                  command: 'addMessage',
                  content: `KP AI Agent: Task completed with status: ${agentTask.status}`,
                  role: 'assistant'
                });

                return;
              }

              // Get current editor selection as context
              const editor = vscode.window.activeTextEditor;
              let context = '';
              if (editor && !editor.selection.isEmpty) {
                const selectedText = editor.document.getText(editor.selection);
                const language = editor.document.languageId;

                if (message.mode === 'edit') {
                  context = 'Please help me edit this ' + language + ' code:\\n\`\`\`' + language + '\\n' + selectedText + '\\n\`\`\`\\n\\nInstructions: ';
                } else if (message.mode === 'explain') {
                  context = 'Please explain this ' + language + ' code:\\n\`\`\`' + language + '\\n' + selectedText + '\\n\`\`\`\\n\\nQuestion: ';
                } else {
                  context = 'Current code selection:\\n\`\`\`' + language + '\\n' + selectedText + '\\n\`\`\`\\n\\n';
                }
              } else if (message.mode === 'edit') {
                context = 'Edit request (no code selected): ';
              } else if (message.mode === 'explain') {
                context = 'Explanation request: ';
              }

              const response = await this.chatMode.sendMessage(
                message.message,
                context,
                (token: string) => {
                  // Stream tokens to webview
                  this._panel.webview.postMessage({
                    command: 'addToken',
                    token: token
                  });
                }
              );

              this._panel.webview.postMessage({
                command: 'addMessage',
                content: response.content,
                role: response.role,
                model: response.model
              });
            } catch (error) {
              this._panel.webview.postMessage({
                command: 'addMessage',
                content: `Error: ${error}`,
                role: 'error'
              });
            }
            break;
          case 'openSettings':
            vscode.commands.executeCommand('kpAiAssistant.openSettings');
            break;
          case 'applyCodeChanges':
            // Apply code changes to the active editor or create new file
            if (message.codeBlocks && message.codeBlocks.length > 0) {
              const codeBlock = message.codeBlocks[0];
              // Extract code from the first code block
              const codeMatch = codeBlock.match(/```(?:(\w+))?\n([\s\S]*?)\n```/);
              if (codeMatch && codeMatch[2]) {
                const language = codeMatch[1] || 'plaintext';
                const newCode = codeMatch[2];
                const editor = vscode.window.activeTextEditor;

                // Check if this looks like a file creation request
                const fileNameMatch = newCode.match(/\/\/ (\w+\.\w+)|\/\* (\w+\.\w+) \*\/|# (\w+\.\w+)/);
                const fileName = fileNameMatch ? (fileNameMatch[1] || fileNameMatch[2] || fileNameMatch[3]) : null;

                if (fileName || !editor) {
                  // Create new file in the main editor column (left side)
                  const newFileName = fileName || `new-file.${this.getFileExtension(language)}`;
                  const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
                  if (workspaceFolder) {
                    const uri = vscode.Uri.file(workspaceFolder.uri.fsPath + '/' + newFileName);
                    vscode.workspace.fs.writeFile(uri, Buffer.from(newCode, 'utf8')).then(() => {
                      // Open the file in the main editor column (ViewColumn.One)
                      vscode.window.showTextDocument(uri, {
                        viewColumn: vscode.ViewColumn.One,
                        preserveFocus: false
                      }).then(() => {
                        // Ensure the chat panel remains visible in ViewColumn.Two
                        if (KPChatPanel.currentPanel) {
                          const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
                          const chatLocation = config.get<string>('chatLocation', 'beside');
                          const column = chatLocation === 'editor' ? vscode.ViewColumn.One : vscode.ViewColumn.Two;
                          KPChatPanel.currentPanel._panel.reveal(column, false);
                        }
                      });
                      vscode.window.showInformationMessage(`KP AI: Created ${newFileName}!`);
                    });
                  } else {
                    vscode.window.showErrorMessage('KP AI: No workspace folder found');
                  }
                } else if (!editor.selection.isEmpty) {
                  // Replace selected text
                  const edit = new vscode.WorkspaceEdit();
                  edit.replace(editor.document.uri, editor.selection, newCode);
                  vscode.workspace.applyEdit(edit);
                  vscode.window.showInformationMessage('KP AI: Code changes applied!');
                } else {
                  // Insert at cursor position
                  editor.edit(editBuilder => {
                    editBuilder.insert(editor.selection.active, newCode);
                  });
                  vscode.window.showInformationMessage('KP AI: Code inserted!');
                }
              }
            } else {
              vscode.window.showWarningMessage('KP AI: No code found to apply');
            }
            break;
          case 'getModelInfo':
            // Send current model information to webview
            this._panel.webview.postMessage({
              command: 'updateModelInfo',
              provider: this.providerManager.getCurrentProvider(),
              model: this.providerManager.getCurrentModel()
            });
            break;
          case 'createNewFile':
            // Create a new file with the provided code
            if (message.codeBlocks && message.codeBlocks.length > 0 && message.fileName) {
              const codeBlock = message.codeBlocks[0];
              const codeMatch = codeBlock.match(/```(?:(\w+))?\n([\s\S]*?)\n```/);
              if (codeMatch && codeMatch[2]) {
                const newCode = codeMatch[2];
                const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
                if (workspaceFolder) {
                  const uri = vscode.Uri.file(workspaceFolder.uri.fsPath + '/' + message.fileName);
                  vscode.workspace.fs.writeFile(uri, Buffer.from(newCode, 'utf8')).then(() => {
                    // Open the file in the main editor column (ViewColumn.One)
                    vscode.window.showTextDocument(uri, {
                      viewColumn: vscode.ViewColumn.One,
                      preserveFocus: false
                    }).then(() => {
                      // Ensure the chat panel remains visible in ViewColumn.Two
                      if (KPChatPanel.currentPanel) {
                        const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
                        const chatLocation = config.get<string>('chatLocation', 'beside');
                        const column = chatLocation === 'editor' ? vscode.ViewColumn.One : vscode.ViewColumn.Two;
                        KPChatPanel.currentPanel._panel.reveal(column, false);
                      }
                    });
                    vscode.window.showInformationMessage(`KP AI: Created ${message.fileName}!`);
                  });
                } else {
                  vscode.window.showErrorMessage('KP AI: No workspace folder found');
                }
              }
            }
            break;
        }
      },
      undefined,
      []
    );
  }

  private getFileExtension(language: string): string {
    const extensions: { [key: string]: string } = {
      'javascript': 'js',
      'typescript': 'ts',
      'python': 'py',
      'java': 'java',
      'csharp': 'cs',
      'cpp': 'cpp',
      'c': 'c',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'xml': 'xml',
      'yaml': 'yml',
      'markdown': 'md',
      'sql': 'sql',
      'shell': 'sh',
      'bash': 'sh',
      'powershell': 'ps1'
    };
    return extensions[language] || 'txt';
  }

  public dispose() {
    this._panel.dispose();
  }
}
