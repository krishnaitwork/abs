import * as vscode from 'vscode';
import { ProviderManager } from '../providers/ProviderManager';

export class KPSettingsPanel {
  public static currentPanel: KPSettingsPanel | undefined;
  private readonly _panel: vscode.WebviewPanel;
  private readonly _extensionUri: vscode.Uri;
  private readonly providerManager: ProviderManager;

  public static readonly viewType = 'kpAiAssistant.settingsPanel';

  public static createOrShow(extensionUri: vscode.Uri, providerManager: ProviderManager) {
    const column = vscode.ViewColumn.One;
    if (KPSettingsPanel.currentPanel) {
      KPSettingsPanel.currentPanel._panel.reveal(column);
      return;
    }
    const panel = vscode.window.createWebviewPanel(
      KPSettingsPanel.viewType,
      'KP AI Assistant Settings',
      column,
      {
        enableScripts: true,
        retainContextWhenHidden: true
      }
    );
    KPSettingsPanel.currentPanel = new KPSettingsPanel(panel, extensionUri, providerManager);
  }

  private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri, providerManager: ProviderManager) {
    this._panel = panel;
    this._extensionUri = extensionUri;
    this.providerManager = providerManager;
    this._initializeWebview();
    this._panel.onDidDispose(() => {
      KPSettingsPanel.currentPanel = undefined;
    }, null, []);
  }

  private async _initializeWebview() {
    this._panel.webview.html = await this._getHtmlForWebview();
    this._setupWebviewMessageListener();
  }

  private async _getHtmlForWebview(): Promise<string> {
    const providers = this.providerManager.getProviders();
    // Ensure OpenRouter settings are shown on top
    const sortedProviders = [...providers].sort((a, b) => {
      if (a.name === 'openrouter') return -1;
      if (b.name === 'openrouter') return 1;
      return 0;
    });
    const currentProvider = this.providerManager.getCurrentProvider();
    const currentModel = this.providerManager.getCurrentModel();

    // Load existing API keys
    const apiKeys: { [key: string]: string } = {};
    for (const provider of providers) {
      if (provider.apiKeyRequired) {
        const existingKey = await this.providerManager.getApiKey(provider.name);
        if (existingKey) {
          // Show masked version of the key (first 4 chars + dots + last 4 chars)
          const masked = existingKey.length > 8 
            ? existingKey.substring(0, 4) + '••••••••' + existingKey.substring(existingKey.length - 4)
            : '••••••••';
          apiKeys[provider.name] = masked;
        }
      }
    }

    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>KP AI Assistant Settings</title>
        <style>
          body { 
            font-family: Segoe UI, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: #1e1e1e; 
            color: #fff; 
          }
          .header { 
            background: #007acc; 
            padding: 16px; 
            margin: -20px -20px 20px -20px; 
            font-size: 1.3em; 
            font-weight: bold; 
          }
          .kp-logo { 
            font-weight: bold; 
            color: #00cfff; 
          }
          .section {
            background: #252526;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
          }
          .section h3 {
            margin-top: 0;
            color: #007acc;
          }
          .form-group {
            margin-bottom: 16px;
          }
          label {
            display: block;
            margin-bottom: 4px;
            font-weight: 500;
          }
          input, select, textarea {
            width: 100%;
            padding: 8px;
            background: #3c3c3c;
            border: 1px solid #6c6c6c;
            border-radius: 4px;
            color: #fff;
            box-sizing: border-box;
          }
          button {
            padding: 10px 16px;
            background: #007acc;
            border: none;
            border-radius: 4px;
            color: #fff;
            cursor: pointer;
            margin-right: 8px;
          }
          button:hover {
            background: #005a9e;
          }
          button.secondary {
            background: #6c6c6c;
          }
          button.secondary:hover {
            background: #555;
          }
          .provider-card {
            border: 1px solid #3e3e42;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
          }
          .provider-card.active {
            border-color: #007acc;
            background: #0e4f79;
          }
          .status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            margin-left: 8px;
          }
          .status.connected {
            background: #196f3d;
            color: #a9dfbf;
          }
          .status.disconnected {
            background: #922b21;
            color: #f1948a;
          }
          .models-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 8px;
            margin-top: 8px;
          }
          .model-item {
            background: #3c3c3c;
            padding: 8px;
            border-radius: 4px;
            cursor: pointer;
            border: 1px solid transparent;
          }
          .model-item:hover {
            background: #4c4c4c;
          }
          .model-item.selected {
            border-color: #007acc;
            background: #0e4f79;
          }
          .model-info {
            font-size: 0.8em;
            color: #aaa;
          }
        </style>
      </head>
      <body>
        <div class="header"><span class="kp-logo">KP</span> AI Assistant Settings</div>
        
        <div class="section">
          <h3>AI Providers</h3>
          <div id="providers-container">
            ${sortedProviders.map(provider => `
              <div class="provider-card ${provider.name === currentProvider ? 'active' : ''}">
                <h4>${provider.displayName} <span class="status disconnected" id="status-${provider.name}">Not configured</span></h4>
                <div class="form-group">
                  <label for="apiKey-${provider.name}">API Key:</label>
                  <div style="display: flex; gap: 8px;">
                    <input type="password" id="apiKey-${provider.name}" 
                           placeholder="${apiKeys[provider.name] ? 'API Key configured (enter new key to update)' : 'Enter API key'}" 
                           value="${apiKeys[provider.name] || ''}"
                           style="flex: 1;"
                           ${provider.apiKeyRequired ? '' : 'disabled'}>
                    ${apiKeys[provider.name] ? `<button type="button" onclick="clearApiKey('${provider.name}')" class="secondary" style="white-space: nowrap;">Clear Key</button>` : ''}
                  </div>
                </div>
                <div class="form-group">
                  <label for="baseUrl-${provider.name}">Base URL:</label>
                  <input type="text" id="baseUrl-${provider.name}" value="${provider.baseUrl}" ${provider.isLocal ? '' : 'readonly'}>
                </div>
                <div class="models-grid">
                  ${provider.models.map(model => `
                    <div class="model-item ${provider.name === currentProvider && model.id === currentModel ? 'selected' : ''}" 
                         data-provider="${provider.name}" data-model="${model.id}">
                      <div>${model.name}</div>
                      <div class="model-info">${model.contextLength} tokens${model.costPer1KTokens ? ` • $${model.costPer1KTokens}/1K` : ''}</div>
                    </div>
                  `).join('')}
                </div>
                <button onclick="testProvider('${provider.name}')">Test Connection</button>
                <button onclick="saveProvider('${provider.name}')" class="secondary">Save</button>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="section">
          <h3>General Settings</h3>
          <div class="form-group">
            <label for="inlineCompletions">
              <input type="checkbox" id="inlineCompletions" checked> Enable inline code completions
            </label>
          </div>
          <div class="form-group">
            <label for="contextLines">Context lines to include:</label>
            <input type="number" id="contextLines" value="50" min="10" max="200">
          </div>
          <div class="form-group">
            <label for="temperature">AI Temperature (creativity):</label>
            <input type="range" id="temperature" min="0" max="1" step="0.1" value="0.7">
            <span id="temperatureValue">0.7</span>
          </div>
          <button onclick="saveGeneralSettings()">Save Settings</button>
        </div>

        <div class="section">
          <h3>Usage Statistics</h3>
          <div id="usage-stats">
            <p>Total requests: <span id="totalRequests">0</span></p>
            <p>Total tokens: <span id="totalTokens">0</span></p>
            <p>Estimated cost: $<span id="estimatedCost">0.00</span></p>
          </div>
          <button onclick="resetStats()" class="secondary">Reset Statistics</button>
        </div>

        <script>
          const vscode = acquireVsCodeApi();

          // Update status based on API key configuration
          function updateProviderStatuses() {
            // Start with OpenRouter for prominence
            const providers = ['openrouter', 'openai', 'anthropic', 'google', 'azure', 'ollama'];
            providers.forEach(provider => {
              const input = document.getElementById('apiKey-' + provider);
              const status = document.getElementById('status-' + provider);
              if (input && status && input.value && input.value.trim() !== '') {
                status.textContent = 'Configured';
                status.className = 'status connected';
              }
            });
          }

          // Initialize status on page load
          document.addEventListener('DOMContentLoaded', updateProviderStatuses);
          setTimeout(updateProviderStatuses, 100); // Fallback for dynamic content

          // Model selection
          document.querySelectorAll('.model-item').forEach(item => {
            item.addEventListener('click', () => {
              // Remove previous selection
              document.querySelectorAll('.model-item').forEach(i => i.classList.remove('selected'));
              item.classList.add('selected');
              
              const provider = item.dataset.provider;
              const model = item.dataset.model;
              
              vscode.postMessage({
                command: 'selectModel',
                provider: provider,
                model: model
              });
            });
          });

          // Temperature slider
          document.getElementById('temperature').addEventListener('input', (e) => {
            document.getElementById('temperatureValue').textContent = e.target.value;
          });

          function testProvider(providerName) {
            const apiKey = document.getElementById('apiKey-' + providerName).value;
            const baseUrl = document.getElementById('baseUrl-' + providerName).value;
            
            vscode.postMessage({
              command: 'testProvider',
              provider: providerName,
              apiKey: apiKey,
              baseUrl: baseUrl
            });
          }

          function saveProvider(providerName) {
            const apiKey = document.getElementById('apiKey-' + providerName).value;
            const baseUrl = document.getElementById('baseUrl-' + providerName).value;
            
            vscode.postMessage({
              command: 'saveProvider',
              provider: providerName,
              apiKey: apiKey,
              baseUrl: baseUrl
            });
          }

          function clearApiKey(providerName) {
            if (confirm('Are you sure you want to clear the API key for ' + providerName + '?')) {
              vscode.postMessage({
                command: 'clearApiKey',
                provider: providerName
              });
            }
          }

          function saveGeneralSettings() {
            const settings = {
              inlineCompletions: document.getElementById('inlineCompletions').checked,
              contextLines: parseInt(document.getElementById('contextLines').value),
              temperature: parseFloat(document.getElementById('temperature').value)
            };
            
            vscode.postMessage({
              command: 'saveGeneralSettings',
              settings: settings
            });
          }

          function resetStats() {
            vscode.postMessage({
              command: 'resetStats'
            });
          }

          // Listen for messages from extension
          window.addEventListener('message', event => {
            const message = event.data;
            switch (message.command) {
              case 'updateConnectionStatus':
                const statusEl = document.getElementById('status-' + message.provider);
                if (statusEl) {
                  statusEl.textContent = message.connected ? 'Connected' : 'Not connected';
                  statusEl.className = 'status ' + (message.connected ? 'connected' : 'disconnected');
                }
                break;
              case 'updateUsageStats':
                document.getElementById('totalRequests').textContent = message.stats.totalRequests;
                document.getElementById('totalTokens').textContent = message.stats.totalTokens;
                document.getElementById('estimatedCost').textContent = message.stats.estimatedCost.toFixed(2);
                break;
            }
          });
        </script>
      </body>
      </html>
    `;
  }

  private _setupWebviewMessageListener() {
    this._panel.webview.onDidReceiveMessage(
      async message => {
        switch (message.command) {
          case 'selectModel':
            this.providerManager.setCurrentProvider(message.provider);
            this.providerManager.setCurrentModel(message.model);
            vscode.window.showInformationMessage(`KP AI: Switched to ${message.provider} - ${message.model}`);
            break;

          case 'testProvider':
            try {
              // Only save API key if it's not a masked value and not empty
              if (message.apiKey && !message.apiKey.includes('••••••••')) {
                await this.providerManager.setApiKey(message.provider, message.apiKey);
              }
              
              const connected = await this.providerManager.testConnection(message.provider);
              
              this._panel.webview.postMessage({
                command: 'updateConnectionStatus',
                provider: message.provider,
                connected: connected
              });

              if (connected) {
                vscode.window.showInformationMessage(`KP AI: ${message.provider} connection successful`);
              } else {
                vscode.window.showErrorMessage(`KP AI: ${message.provider} connection failed`);
              }
            } catch (error) {
              vscode.window.showErrorMessage(`KP AI: Connection test failed - ${error}`);
            }
            break;

          case 'saveProvider':
            try {
              // Only save API key if it's not a masked value and not empty
              if (message.apiKey && !message.apiKey.includes('••••••••')) {
                await this.providerManager.setApiKey(message.provider, message.apiKey);
                vscode.window.showInformationMessage(`KP AI: ${message.provider} settings saved with new API key`);
                // Refresh the webview to show the masked key
                this._panel.webview.html = await this._getHtmlForWebview();
              } else {
                vscode.window.showInformationMessage(`KP AI: ${message.provider} settings saved (API key unchanged)`);
              }
            } catch (error) {
              vscode.window.showErrorMessage(`KP AI: Failed to save settings - ${error}`);
            }
            break;

          case 'clearApiKey':
            try {
              await this.providerManager.setApiKey(message.provider, '');
              vscode.window.showInformationMessage(`KP AI: ${message.provider} API key cleared`);
              // Refresh the webview to remove the masked key
              this._panel.webview.html = await this._getHtmlForWebview();
            } catch (error) {
              vscode.window.showErrorMessage(`KP AI: Failed to clear API key - ${error}`);
            }
            break;

          case 'saveGeneralSettings':
            const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
            await config.update('inlineCompletions', message.settings.inlineCompletions, true);
            await config.update('contextLines', message.settings.contextLines, true);
            vscode.window.showInformationMessage('KP AI: General settings saved');
            break;

          case 'resetStats':
            // Reset usage statistics
            vscode.window.showInformationMessage('KP AI: Statistics reset');
            this._panel.webview.postMessage({
              command: 'updateUsageStats',
              stats: {
                totalRequests: 0,
                totalTokens: 0,
                estimatedCost: 0
              }
            });
            break;
        }
      },
      undefined,
      []
    );
  }
}
