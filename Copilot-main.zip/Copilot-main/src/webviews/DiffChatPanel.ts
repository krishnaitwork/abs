import * as vscode from 'vscode';
import { DiffResult } from '../types';

export class DiffChatPanel {
    public static currentPanel: DiffChatPanel | undefined;
    private readonly _panel: vscode.WebviewPanel;
    private readonly _extensionUri: vscode.Uri;
    private _disposables: vscode.Disposable[] = [];

    public static createOrShow(extensionUri: vscode.Uri, diffResult: DiffResult, fileName: string): void {
        const column = vscode.window.activeTextEditor
            ? vscode.window.activeTextEditor.viewColumn
            : undefined;

        // If we already have a panel, show it
        if (DiffChatPanel.currentPanel) {
            DiffChatPanel.currentPanel._panel.reveal(column);
            DiffChatPanel.currentPanel.updateDiff(diffResult, fileName);
            return;
        }

        // Otherwise, create a new panel
        const panel = vscode.window.createWebviewPanel(
            'kpDiffChat',
            'KP AI Diff Chat',
            column || vscode.ViewColumn.One,
            {
                enableScripts: true,
                localResourceRoots: [extensionUri]
            }
        );

        DiffChatPanel.currentPanel = new DiffChatPanel(panel, extensionUri, diffResult, fileName);
    }

    private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri, diffResult: DiffResult, fileName: string) {
        this._panel = panel;
        this._extensionUri = extensionUri;

        // Set the webview's initial html content
        this.updateDiff(diffResult, fileName);

        // Listen for when the panel is disposed
        // This happens when the user closes the panel or when the panel is closed programmatically
        this._panel.onDidDispose(() => this.dispose(), null, this._disposables);

        // Handle messages from the webview
        this._panel.webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'applyDiff':
                        this.applyDiff(diffResult);
                        return;
                    case 'rejectDiff':
                        this.rejectDiff();
                        return;
                    case 'showFullDiff':
                        this.showFullDiff(diffResult, fileName);
                        return;
                    case 'openDiffFile':
                        this.openDiffFile(diffResult, fileName);
                        return;
                }
            },
            undefined,
            this._disposables
        );
    }

    public updateDiff(diffResult: DiffResult, fileName: string): void {
        this._panel.webview.html = this.getWebviewContent(diffResult, fileName);
    }

    private getWebviewContent(diffResult: DiffResult, fileName: string): string {
        const insertCount = diffResult.changes.filter((c: any) => c.type === 'insert').length;
        const deleteCount = diffResult.changes.filter((c: any) => c.type === 'delete').length;
        const replaceCount = diffResult.changes.filter((c: any) => c.type === 'replace').length;

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KP AI Diff Chat</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--vscode-editor-background);
            color: var(--vscode-editor-foreground);
        }
        .header {
            background: var(--vscode-badge-background);
            color: var(--vscode-badge-foreground);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .file-change-card {
            background: var(--vscode-editor-background);
            border: 1px solid var(--vscode-panel-border);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .file-change-card:hover {
            border-color: var(--vscode-focusBorder);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateY(-2px);
        }
        .file-icon {
            font-size: 24px;
            color: var(--vscode-textLink-foreground);
        }
        .file-name {
            font-weight: bold;
            font-size: 16px;
            color: var(--vscode-foreground);
            flex: 1;
        }
        .change-summary {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .click-hint {
            font-size: 12px;
            color: var(--vscode-descriptionForeground);
            font-style: italic;
        }
        .change-count {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
        }
        .insert { background: var(--vscode-diffEditor-insertedTextBackground); color: var(--vscode-diffEditor-insertedTextForeground); }
        .delete { background: var(--vscode-diffEditor-removedTextBackground); color: var(--vscode-diffEditor-removedTextForeground); }
        .replace { background: var(--vscode-diffEditor-modifiedTextBackground); color: var(--vscode-diffEditor-modifiedTextBackground); }
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            justify-content: center;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        .btn-primary {
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
        }
        .btn-primary:hover {
            background: var(--vscode-button-hoverBackground);
        }
        .btn-secondary {
            background: var(--vscode-button-secondaryBackground);
            color: var(--vscode-button-secondaryForeground);
        }
        .btn-secondary:hover {
            background: var(--vscode-button-secondaryHoverBackground);
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>🤖 KP AI Code Improvements</h2>
        <p>Review the suggested changes below</p>
    </div>

    <div class="file-change-card" onclick="openDiffFile()">
        <div class="file-icon">📄</div>
        <div class="file-name">${fileName.split('/').pop() || fileName}</div>
        <div class="change-summary">
            <span class="change-count insert">+${insertCount}</span>
            <span class="change-count delete">-${deleteCount}</span>
            <span class="change-count replace">~${replaceCount}</span>
        </div>
        <div class="click-hint">Click to open diff</div>
    </div>

    </div>

    <div class="actions">
        <button class="btn btn-primary" onclick="applyDiff()">✅ Apply Changes</button>
        <button class="btn btn-secondary" onclick="rejectDiff()">❌ Reject Changes</button>
        <button class="btn btn-secondary" onclick="showFullDiff()">📋 Show Full Diff</button>
    </div>

    <script>
        // Expose vscode API to webview
        const vscode = acquireVsCodeApi();

        function toggleDiff(event) {
            if (event) event.stopPropagation();
            const details = document.getElementById('diffDetails');
            const chevron = document.querySelector('.chevron');
            details.classList.toggle('show');
            chevron.classList.toggle('rotated');
        }

        function openDiffFile(event) {
            if (event) event.stopPropagation();
            vscode.postMessage({
                command: 'openDiffFile'
            });
        }

        function applyDiff() {
            vscode.postMessage({
                command: 'applyDiff'
            });
        }

        function rejectDiff() {
            vscode.postMessage({
                command: 'rejectDiff'
            });
        }

        function showFullDiff() {
            vscode.postMessage({
                command: 'showFullDiff'
            });
        }
    </script>
</body>
</html>`;
    }

    private applyDiff(diffResult: DiffResult): void {
        // This would integrate with the DiffManager to apply changes
        vscode.window.showInformationMessage('KP AI: Applying changes...');
        // TODO: Implement actual diff application
    }

    private rejectDiff(): void {
        vscode.window.showInformationMessage('KP AI: Changes rejected');
        this._panel.dispose();
    }

    private openDiffFile(diffResult: DiffResult, fileName: string): void {
        // Create a diff file content
        const diffContent = this.createDiffFileContent(diffResult, fileName);
        
        // Open the diff content in a new untitled document
        vscode.workspace.openTextDocument({
            content: diffContent,
            language: 'diff'
        }).then(document => {
            vscode.window.showTextDocument(document);
            vscode.window.showInformationMessage(`KP AI: Opened diff for ${fileName.split('/').pop()}`);
        });
    }

    private showFullDiff(diffResult: DiffResult, fileName: string): void {
        // Show the full diff in a new document
        const diffContent = this.createFullDiffContent(diffResult, fileName);
        vscode.workspace.openTextDocument({
            content: diffContent,
            language: 'diff'
        }).then(doc => {
            vscode.window.showTextDocument(doc, vscode.ViewColumn.Beside);
        });
    }

    private createDiffFileContent(diffResult: DiffResult, fileName: string): string {
        const timestamp = new Date().toLocaleString();
        let content = `--- ${fileName} (original)\n`;
        content += `+++ ${fileName} (modified)\n`;
        content += `@@ Generated by KP AI Assistant on ${timestamp} @@\n\n`;
        
        content += `Summary: ${diffResult.summary}\n`;
        content += `Source: ${diffResult.source}\n`;
        content += `Total changes: ${diffResult.changes.length}\n\n`;
        
        diffResult.changes.forEach((change, index) => {
            content += `Change ${index + 1}: ${change.type.toUpperCase()}\n`;
            content += `Line: ${change.range.startLine + 1}\n`;
            content += `Description: ${change.description}\n`;
            
            if (change.originalContent) {
                content += `- ${change.originalContent}\n`;
            }
            if (change.content) {
                content += `+ ${change.content}\n`;
            }
            content += `\n`;
        });
        
        return content;
    }

    private createFullDiffContent(diffResult: DiffResult, fileName: string): string {
        let content = `# Full Diff for ${fileName}\n\n`;
        content += `Generated by KP AI Assistant\n\n`;
        content += `---\n\n`;

        diffResult.changes.forEach((change: any, index: number) => {
            content += `## Change ${index + 1}: ${change.type.toUpperCase()}\n\n`;
            content += `**Description:** ${change.description}\n\n`;
            
            if (change.originalContent) {
                content += `**Original:**\n\`\`\`\n${change.originalContent}\n\`\`\`\n\n`;
            }
            
            if (change.content) {
                content += `**New:**\n\`\`\`\n${change.content}\n\`\`\`\n\n`;
            }
            
            content += `---\n\n`;
        });

        return content;
    }

    public dispose(): void {
        DiffChatPanel.currentPanel = undefined;

        // Clean up our resources
        this._panel.dispose();

        while (this._disposables.length) {
            const x = this._disposables.pop();
            if (x) {
                x.dispose();
            }
        }
    }
}
