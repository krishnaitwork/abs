import * as path from 'path';
import * as vscode from 'vscode';
import { KPAgentMode } from '../modes/AgentMode';
import { KPChatMode } from '../modes/ChatMode';
import { ProviderManager } from '../providers/ProviderManager';
import { DIFF_SCHEME, ensureDiffContentProvider } from '../utils/DiffContentProvider';
import { DiffManager } from '../utils/DiffManager';

export class KPSidebarProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'kp-ai-chat';
  private readonly providerManager: ProviderManager;
  private readonly chatMode: KPChatMode;
  private readonly agentMode: KPAgentMode;
  private _view?: vscode.WebviewView;
  private currentMode: string = 'ask';
  private conversationStarted: boolean = false;
  private _storedEdits = new Map<string, any>();
  private _cleanupTimers = new Map<string, NodeJS.Timeout>();
  private diffManager: DiffManager;

  constructor(
    private readonly _extensionUri: vscode.Uri,
    providerManager?: ProviderManager
  ) {
    this.providerManager = providerManager || ProviderManager.getInstance();
    this.chatMode = new KPChatMode(this.providerManager);
    this.agentMode = new KPAgentMode(this.providerManager);
  this.diffManager = new DiffManager();
  // Provide chat-based approval for Agent steps (no popups)
  this.agentMode.setApprovalHandler(async (step: any) => {
    try {
      const diffId = `agentapprove_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const filePath = step?.parameters?.filePath || '';
      const ws = vscode.workspace.workspaceFolders?.[0];
      const pretty = (ws && filePath && filePath.startsWith(ws.uri.fsPath))
        ? filePath.substring(ws.uri.fsPath.length + 1).replace(/\\/g, '/')
        : (filePath ? path.basename(filePath) : '');

      // Build a robust documentUri (supports relative filePath)
      let approvalDocUri = '';
      try {
        const isAbs = filePath && (/^[A-Za-z]:\\/.test(filePath) || /^\\\\/.test(filePath));
        if (filePath && isAbs) {
          approvalDocUri = vscode.Uri.file(filePath).toString();
        } else if (filePath && ws) {
          approvalDocUri = vscode.Uri.joinPath(ws.uri, filePath.replace(/^\\+|^\/+/, '')).toString();
        }
      } catch {}

      const payload = {
        editId: diffId,
        documentUri: approvalDocUri,
        fileName: filePath,
        languageId: '',
        originalText: step?.parameters?.originalContent || '',
        newText: step?.parameters?.newContent || '',
        useSelection: false,
        selectionRange: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } },
        timestamp: Date.now()
      };
      const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64');

      // Compute simple change counts
      const originalLines = (payload.originalText || '').split('\n');
      const newLines = (payload.newText || '').split('\n');
      let removedLines = 0, addedLines = 0;
      for (let i = 0; i < Math.max(originalLines.length, newLines.length); i++) {
        const o = originalLines[i] || '';
        const n = newLines[i] || '';
        if (o !== n) { if (o) removedLines++; if (n) addedLines++; }
      }

      // Render approval message with clickable diff link and buttons
      const content = [
        `🤖 **Approval Needed**`,
        `**Action:** ${step?.action || 'modify_file'}`,
        `**File:** <a href="#" data-open-diff="${diffId}" data-edit-payload="${payloadB64}" title="Click to view full diff">${pretty || '(unspecified file)'}</a>`,
        `**Changes:** ${removedLines} lines removed, ${addedLines} lines added`,
        `<div class="edit-actions" data-approve-id="${diffId}">`+
          `<button class="edit-btn approve" data-approve="yes">Approve</button>`+
          `<button class="edit-btn reject" data-approve="no">Reject</button>`+
        `</div>`
      ].join('\n');

      // Post to chat
      const messageId = `approval_${diffId}`;
      this._view?.webview.postMessage({ type: 'response', content, id: messageId });

      // Cache edit for diff opening reliability
      this._storedEdits.set(diffId, {
        id: diffId,
        documentUri: (function(){
          try {
            const isAbs = filePath && (/^[A-Za-z]:\\/.test(filePath) || /^\\\\/.test(filePath));
            if (filePath && isAbs) return vscode.Uri.file(filePath);
            if (filePath && ws) return vscode.Uri.joinPath(ws.uri, filePath.replace(/^\\+|^\/+/, ''));
          } catch {}
          return undefined;
        })(),
        selectionRange: new vscode.Selection(new vscode.Position(0,0), new vscode.Position(0,0)),
        originalText: payload.originalText,
        newText: payload.newText,
        useSelection: false,
        fileName: filePath,
        timestamp: Date.now()
      });
      this._scheduleEditCleanup(diffId, 5 * 60 * 1000);

      // Wait for user decision from webview
      const decision = await new Promise<boolean>((resolve) => {
        const sub = this._view?.webview.onDidReceiveMessage(async (data) => {
          if (data && data.type === 'approvalDecision' && data.editId === diffId) {
            resolve(Boolean(data.approved));
            sub?.dispose();
          }
        });
      });

      return decision;
    } catch (err) {
      console.error('KP AI: Chat approval failed', err);
      return false;
    }
  });

  // Subscribe to Agent mode diffs and surface them in chat
  try {
    this.agentMode.onDiffProposed?.((evt: { filePath: string; originalContent: string; newContent: string; }) => {
      try {
        const diffId = `agentdiff_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const ws = vscode.workspace.workspaceFolders?.[0];
        const filePath = typeof evt.filePath === 'string' ? evt.filePath : '';
        const pretty = (ws && filePath && filePath.startsWith(ws.uri.fsPath))
          ? filePath.substring(ws.uri.fsPath.length + 1).replace(/\\/g, '/')
          : (filePath ? path.basename(filePath) : '');

        // Build a robust documentUri (supports relative filePath)
        let proposedDocUri = '';
        try {
          const isAbs = filePath && (/^[A-Za-z]:\\/.test(filePath) || /^\\\\/.test(filePath));
          if (filePath && isAbs) {
            proposedDocUri = vscode.Uri.file(filePath).toString();
          } else if (filePath && ws) {
            proposedDocUri = vscode.Uri.joinPath(ws.uri, filePath.replace(/^\\+|^\/+/, '')).toString();
          }
        } catch {}

        const payload = {
          editId: diffId,
          documentUri: proposedDocUri,
          fileName: filePath,
          languageId: '',
          originalText: evt.originalContent || '',
          newText: evt.newContent || '',
          useSelection: false,
          selectionRange: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } },
          timestamp: Date.now()
        };
        const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64');

        // Compute a simple added/removed lines summary (parity with Edit mode)
        const originalLines = (evt.originalContent || '').split('\n');
        const newLines = (evt.newContent || '').split('\n');
        let removedLines = 0;
        let addedLines = 0;
        for (let i = 0; i < Math.max(originalLines.length, newLines.length); i++) {
          const o = originalLines[i] || '';
          const n = newLines[i] || '';
          if (o !== n) {
            if (o) removedLines++;
            if (n) addedLines++;
          }
        }

        const content = `📊 **Proposed Changes (Agent)**\n**File:** <a href=\"#\" data-open-diff=\"${diffId}\" data-edit-payload=\"${payloadB64}\" title=\"Click to view full diff\">${pretty}</a>\n**Changes:** ${removedLines} lines removed, ${addedLines} lines added`;
        this._view?.webview.postMessage({
          type: 'response',
          content,
          id: `response_${diffId}`
        });

    if (filePath) {
          // Cache a short-lived entry so clicking without payload still works
          this._storedEdits.set(diffId, {
            id: diffId,
      documentUri: (function(){
              try {
        const isAbs = filePath && (/^[A-Za-z]:\\/.test(filePath) || /^\\\\/.test(filePath));
                if (filePath && isAbs) return vscode.Uri.file(filePath);
                if (filePath && ws) return vscode.Uri.joinPath(ws.uri, filePath.replace(/^\\+|^\/+/, ''));
              } catch {}
              return undefined;
            })(),
            selectionRange: new vscode.Selection(new vscode.Position(0,0), new vscode.Position(0,0)),
            originalText: evt.originalContent || '',
            newText: evt.newContent || '',
            useSelection: false,
      fileName: filePath,
            timestamp: Date.now()
          });
          this._scheduleEditCleanup(diffId, 2 * 60 * 1000);
        }
      } catch (e) {
        console.error('KP AI: Failed to post Agent diff to chat', e);
      }
    });
  } catch {}
  }

  public resolveWebviewView(
    webviewView: vscode.WebviewView,
    context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken,
  ) {
    this._view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [this._extensionUri]
    };

    webviewView.webview.html = this._getHtmlForWebview();

    webviewView.webview.onDidReceiveMessage(async (data) => {
      console.log('📨 Received message:', data);

      if (data.type === 'send') {
        console.log('🔧 Processing send message with mode:', data.mode, 'message:', data.message);
        await this._handleChat(data.mode || 'ask', data.message, data.editOptions);
      } else if (data.type === 'ready') {
        console.log('🚀 Webview ready, sending initial data');
        // Try to send initial data with retry mechanism
        this._sendInitialDataWithRetry(webviewView);
      } else if (data.type === 'clearHistory') {
        console.log('🗑️ Clearing conversation history');
        await this._clearConversation();
      } else if (data.type === 'openSettings') {
        // Open the existing KP AI Assistant Settings panel
        vscode.commands.executeCommand('kpAiAssistant.openSettings');
      } else if (data.type === 'editAction') {
        console.log('🔧 Edit action requested:', data.action, data.editId);
        await this._handleEditAction(data.action, data.editId);
      } else if (data.type === 'openDiff') {
        console.log('📝 Open diff requested for edit:', data.editId);
        await this._openEditDiff(data.editId, data.payload);
             } else if (data.type === 'stopAgent') {
         console.log('⏹️ Stop agent requested');
         this.agentMode.stopExecution();
         // Hide the stop button
         webviewView.webview.postMessage({ type: 'hideStopButton' });
       } else if (data.type === 'stopRequest') {
         console.log('⏹️ Stop request requested');
         // Stop the current request and notify the webview
         webviewView.webview.postMessage({ type: 'requestStopped' });
       }
    });
  }

  private async _handleChat(mode: string, message: string, editOptions?: any): Promise<void> {
    console.log('🔧 _handleChat called with mode:', mode, 'message:', message);

    try {
      let response = '';

      // Start new conversation only if mode changed or it's the first time
      if (mode !== this.currentMode || !this.conversationStarted) {
        console.log(`� Mode changed from ${this.currentMode} to ${mode}, starting new conversation`);
        await this.chatMode.startNewConversation();
        this.currentMode = mode;
        this.conversationStarted = true;
      }

      switch (mode) {
        case 'ask':
          console.log('💬 Continuing Ask mode conversation');
          const askResult = await this.chatMode.sendMessage(message, 'user');
          response = askResult.content;
          break;

        case 'edit':
          console.log('✏️ Processing Edit mode with options:', editOptions);
          const editor = vscode.window.activeTextEditor;
          if (!editor) {
            response = '⚠️ Please open a file in the editor first to use Edit mode.';
          } else {
            const document = editor.document;
            const selection = editor.selection;
            const selectedText = document.getText(selection);
            const fullText = document.getText();

            // Determine what to edit based on options
            const useSelection = editOptions?.selectionOnly && selectedText.length > 0;
            const targetText = useSelection ? selectedText : fullText;
            const context = useSelection ? 'selected code' : `file (${document.fileName})`;

            // Don't start new conversation for edit mode - continue the conversation
            const editPrompt = `Edit the ${context}:\n\`\`\`\n${targetText}\n\`\`\`\n\nRequest: ${message}\n\nPlease provide ONLY the modified code in a code block, without explanations.`;

            const editResult = await this.chatMode.sendMessage(editPrompt, 'user');
            response = editResult.content;

            // Extract code from response
            const codeMatch = response.match(/\`\`\`[\s\S]*?\n([\s\S]*?)\n\`\`\`/);
            if (codeMatch && codeMatch[1]) {
              const newCode = codeMatch[1].trim();

              // Show compact change summary and clickable link (no large diff block)
              if (editOptions?.showDiff !== false) {
                const diffId = `diff_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

                // Add the diff content to the response with proper formatting
                response += `\n\n📊 **Code Changes Preview**\n`;

                // Calculate change summary
                const originalLines = targetText.split('\n');
                const newLines = newCode.split('\n');
                let removedLines = 0;
                let addedLines = 0;

                for (let i = 0; i < Math.max(originalLines.length, newLines.length); i++) {
                  const originalLine = originalLines[i] || '';
                  const newLine = newLines[i] || '';
                  if (originalLine !== newLine) {
                    if (originalLine) removedLines++;
                    if (newLine) addedLines++;
                  }
                }

                const prettyPath = this._getPrettyPath(document.fileName);
                // Prepare payload so diff can be opened even if in-memory cache is gone
                const payload = {
                  editId: diffId,
                  documentUri: document.uri.toString(),
                  fileName: document.fileName,
                  languageId: document.languageId,
                  originalText: targetText,
                  newText: newCode,
                  useSelection: useSelection,
                  selectionRange: {
                    start: { line: selection.start.line, character: selection.start.character },
                    end: { line: selection.end.line, character: selection.end.character }
                  },
                  timestamp: Date.now()
                };
                const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64');
                // Clickable link to open a full diff view for this edit
                response += `**File:** <a href="#" data-open-diff="${diffId}" data-edit-payload="${payloadB64}" title="Click to view full diff">${prettyPath}</a>\n`;
                response += `**Changes:** ${removedLines} lines removed, ${addedLines} lines added\n`;

                // Store the edit information for later application
                this._storedEdits.set(diffId, {
                  id: diffId,
                  documentUri: document.uri,
                  selectionRange: selection,
                  originalText: targetText,
                  newText: newCode,
                  useSelection: useSelection,
                  timestamp: Date.now()
                });

                // Keep edit info available for a while so the link remains valid
                this._scheduleEditCleanup(diffId, 5 * 60 * 1000); // 5 minutes

                // No inline action buttons to keep chat compact
              }

              // If auto-apply is enabled, apply changes immediately
              if (editOptions?.autoApply === true) {
                try {
                  const edit = new vscode.WorkspaceEdit();
                  if (useSelection) {
                    edit.replace(document.uri, selection, newCode);
                  } else {
                    const fullRange = new vscode.Range(
                      document.positionAt(0),
                      document.positionAt(fullText.length)
                    );
                    edit.replace(document.uri, fullRange, newCode);
                  }

                  const applied = await vscode.workspace.applyEdit(edit);
                  if (applied) {
                    response += `\n\n✅ Code has been automatically applied to your ${useSelection ? 'selection' : 'file'}.`;
                  } else {
                    response += '\n\n❌ Could not apply code automatically. Use the buttons above to apply manually.';
                  }
                } catch (error) {
                  response += `\n\n❌ Error applying changes: ${error instanceof Error ? error.message : String(error)}`;
                }
              } else {
                response += `\n\n📝 Review the changes above and use the buttons to apply, reject, or copy the code.`;
              }
            } else if (editOptions?.autoApply === false) {
              response += '\n\n📋 Auto-apply is disabled. Copy the code manually if you want to use it.';
            }
          }
          break;

        case 'agent':
          console.log('🤖 Starting Agent mode task');
          const agentResult = await this.agentMode.startTask(message);
          response = `🤖 Agent task started: ${agentResult.description}\n\nI'll work on this task for you. You may see approval requests as I proceed.`;
          
          // Show the stop button when agent starts
          this._view?.webview.postMessage({
            type: 'showStopButton'
          });
          break;

        default:
          response = 'Unknown mode. Please try again.';
      }

             console.log('📤 Sending response:', response);
       this._view?.webview.postMessage({
         type: 'response',
         content: response,
         id: `response_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
       });

       // Notify that response is complete
       this._view?.webview.postMessage({ type: 'responseComplete' });

       console.log('✅ Response sent successfully');
         } catch (error) {
       console.error('❌ Error in _handleChat:', error);
       this._view?.webview.postMessage({
         type: 'response',
         content: `Error: ${error instanceof Error ? error.message : String(error)}`,
         id: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
       });
       
       // Notify that response is complete (even for errors)
       this._view?.webview.postMessage({ type: 'responseComplete' });
     }
  }

  private _getHtmlForWebview(): string {
    return String.raw`<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
      color: var(--vscode-foreground);
      background: var(--vscode-sideBar-background);
      margin: 0; 
      padding: 8px;
      line-height: 1.3;
    }

    .container { 
      display: flex; 
      flex-direction: column; 
      height: calc(100vh - 16px); 
      gap: 8px;
    }

    /* Header Section */
    .header { 
      text-align: center;
      padding: 12px 6px;
      background: linear-gradient(135deg, var(--vscode-button-background) 0%, var(--vscode-button-hoverBackground) 100%);
      border-radius: 8px;
      border: 1px solid var(--vscode-button-border);
      margin-bottom: 6px;
    }

    .header h3 { 
      margin: 0; 
      font-size: 14px; 
      font-weight: 600;
      color: var(--vscode-button-foreground);
      margin-bottom: 2px;
    }

    .header-subtitle {
      font-size: 10px;
      color: var(--vscode-descriptionForeground);
      opacity: 0.8;
    }

    



    .menu-btn {
      background: var(--vscode-button-secondaryBackground);
      color: var(--vscode-button-secondaryForeground);
      border: 1px solid var(--vscode-button-border);
      border-radius: 3px;
      padding: 6px 8px;
      cursor: pointer;
      font-size: 10px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0;
      min-width: 32px;
      height: 28px;
      position: relative;
      overflow: visible;
      flex-shrink: 0;
      opacity: 1;
      visibility: visible;
    }

    .menu-btn:hover {
      background: var(--vscode-button-secondaryHoverBackground);
      color: var(--vscode-button-secondaryHoverForeground);
      border-color: var(--vscode-button-hoverBorder);
      transform: none;
      box-shadow: none;
    }

    .menu-btn-icon {
      font-size: 14px;
      font-weight: bold;
      opacity: 1;
      visibility: visible;
      display: block;
    }

    /* Stop Button */
    .stop-btn {
      padding: 8px 12px;
      font-size: 10px;
      font-weight: 500;
      background: var(--vscode-errorForeground);
      color: var(--vscode-button-foreground);
      border: 1px solid var(--vscode-errorForeground);
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      gap: 6px;
      min-height: 32px;
      margin-left: 8px;
      flex-shrink: 0;
    }

    .stop-btn:hover {
      background: var(--vscode-errorForeground);
      opacity: 0.8;
      transform: translateY(-1px);
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    .stop-btn-icon {
      font-size: 12px;
    }

    .stop-btn-text {
      font-size: 9px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
      white-space: nowrap;
    }

    /* Dropdown Menu */
    .dropdown-menu {
      position: absolute;
      bottom: 100%;
      right: 0;
      background: var(--vscode-dropdown-background);
      border: 1px solid var(--vscode-widget-border);
      border-radius: 4px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transform: translateY(10px);
      transition: all 0.2s ease;
      margin-bottom: 2px;
      min-width: 120px;
    }

    .dropdown-menu.active {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .menu-item {
      width: 100%;
      padding: 8px 12px;
      font-size: 10px;
      background: transparent;
      color: var(--vscode-foreground);
      border: none;
      border-radius: 0;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      gap: 8px;
      text-align: left;
    }

    .menu-item:first-child {
      border-radius: 4px 4px 0 0;
    }

    .menu-item:last-child {
      border-radius: 0 0 4px 4px;
    }

    .menu-item:hover {
      background: var(--vscode-list-hoverBackground);
      color: var(--vscode-list-hoverForeground);
    }

    .menu-item-icon {
      font-size: 12px;
      opacity: 0.8;
    }

         /* Edit Options Panel */
     .edit-options {
       display: none;
       flex-direction: column;
       margin-bottom: 8px;
       border: 1px solid var(--vscode-widget-border);
       border-radius: 6px;
       background: var(--vscode-input-background);
       border-left: 3px solid var(--vscode-focusBorder);
       overflow: hidden;
     }

     .edit-options.active {
       display: flex;
     }

     .edit-options-header {
       display: flex;
       justify-content: space-between;
       align-items: center;
       padding: 8px;
       cursor: pointer;
       user-select: none;
       background: var(--vscode-input-background);
       transition: background-color 0.2s ease;
     }

     .edit-options-header:hover {
       background: var(--vscode-list-hoverBackground);
     }

     .edit-options-title {
       font-size: 10px;
       font-weight: 600;
       color: var(--vscode-foreground);
       text-transform: uppercase;
       letter-spacing: 0.3px;
     }

     .edit-options-toggle {
       font-size: 10px;
       color: var(--vscode-descriptionForeground);
       transition: transform 0.2s ease;
     }

     .edit-options-toggle.collapsed {
       transform: rotate(-90deg);
     }

     .edit-options-content {
       padding: 0 8px 8px 8px;
       display: flex;
       flex-direction: column;
       gap: 6px;
       transition: all 0.3s ease;
       overflow: hidden;
     }

     .edit-options-content.collapsed {
       max-height: 0;
       padding: 0 8px;
       opacity: 0;
     }

    .checkbox-row {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 2px 0;
    }

    .checkbox-row input[type="checkbox"] {
      margin: 0;
      accent-color: var(--vscode-focusBorder);
    }

    .checkbox-row label {
      font-size: 10px;
      color: var(--vscode-foreground);
      cursor: pointer;
      user-select: none;
    }

    /* Messages Container */
    .messages {
      flex: 1; 
      overflow-y: auto; 
      margin-bottom: 8px; 
      padding: 8px;
      border: 1px solid var(--vscode-widget-border); 
      border-radius: 6px;
      background: var(--vscode-input-background);
      font-size: 11px;
      scrollbar-width: thin;
      scrollbar-color: var(--vscode-scrollbarSlider-background) transparent;
    }

    .messages::-webkit-scrollbar {
      width: 4px;
    }

    .messages::-webkit-scrollbar-track {
      background: transparent;
    }

    .messages::-webkit-scrollbar-thumb {
      background: var(--vscode-scrollbarSlider-background);
      border-radius: 2px;
    }

    .messages::-webkit-scrollbar-thumb:hover {
      background: var(--vscode-scrollbarSlider-hoverBackground);
    }

    /* Message Styles */
    .message { 
      margin-bottom: 8px; 
      padding: 8px; 
      border-radius: 6px; 
      line-height: 1.3;
      border: 1px solid transparent;
      transition: all 0.2s ease;
    }

    .message:hover {
      border-color: var(--vscode-widget-border);
    }

    .user { 
      background: var(--vscode-textBlockQuote-background); 
      border-left: 3px solid var(--vscode-textBlockQuote-border);
      margin-left: 6px;
    }

    .ai { 
      background: var(--vscode-textCodeBlock-background); 
      border-left: 3px solid var(--vscode-focusBorder);
      margin-right: 6px;
    }

    .message strong {
      color: var(--vscode-textLink-foreground);
      margin-bottom: 4px;
      display: block;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .message-content {
      margin-top: 4px;
      font-size: 11px;
      line-height: 1.4;
    }

    .message-content p {
      margin: 2px 0;
    }

    .message-content ul, .message-content ol {
      margin: 4px 0;
      padding-left: 16px;
    }

    .message-content li {
      margin: 1px 0;
    }

    .message-content blockquote {
      border-left: 2px solid var(--vscode-textBlockQuote-border);
      background: var(--vscode-textBlockQuote-background);
      padding: 4px 8px;
      margin: 4px 0;
      font-style: italic;
      border-radius: 0 3px 3px 0;
    }

    /* Diff Summary Styling */
    .message-content strong {
      color: var(--vscode-textLink-foreground);
      font-weight: 600;
    }

    .diff-summary {
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-widget-border);
      border-radius: 4px;
      padding: 6px 8px;
      margin: 6px 0;
      font-size: 10px;
      line-height: 1.3;
    }

    /* Code Block Styles */
    .code-block {
      position: relative;
      margin: 6px 0;
      border-radius: 4px;
      overflow: hidden;
      border: 1px solid var(--vscode-widget-border);
    }

    .diff-block {
      position: relative;
      margin: 8px 0;
      border-radius: 6px;
      overflow: hidden;
      border: 1px solid var(--vscode-focusBorder);
      background: var(--vscode-textCodeBlock-background);
    }

    .diff-header {
      background: var(--vscode-editor-background);
      border-bottom: 1px solid var(--vscode-focusBorder);
      padding: 6px 10px;
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .diff-label {
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
      color: var(--vscode-focusBorder);
    }

    .diff-content {
      background: var(--vscode-textCodeBlock-background);
      border: none;
      border-radius: 0;
      padding: 10px;
      margin: 0;
      overflow-x: auto;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      font-size: 10px;
      line-height: 1.3;
      color: var(--vscode-foreground);
    }

    /* Inline Diff Styles */
    .inline-diff {
      margin: 8px 0;
      border-radius: 6px;
      overflow: hidden;
      border: 1px solid var(--vscode-focusBorder);
      background: var(--vscode-textCodeBlock-background);
    }

    .inline-diff .diff-header {
      background: var(--vscode-editor-background);
      border-bottom: 1px solid var(--vscode-focusBorder);
      padding: 8px 12px;
      font-size: 10px;
      color: var(--vscode-descriptionForeground);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .inline-diff .diff-content {
      background: var(--vscode-textCodeBlock-background);
      padding: 8px 12px;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      font-size: 10px;
      line-height: 1.4;
      max-height: 200px;
      overflow-y: auto;
    }

    .diff-line {
      padding: 2px 4px;
      margin: 1px 0;
      border-radius: 2px;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      white-space: pre-wrap;
      word-break: break-all;
    }

    .diff-line.removed {
      background: var(--vscode-diffEditor-removedTextBackground);
      color: var(--vscode-diffEditor-removedTextForeground);
      border-left: 3px solid var(--vscode-diffEditor-removedTextBorder);
    }

    .diff-line.added {
      background: var(--vscode-diffEditor-insertedTextBackground);
      color: var(--vscode-diffEditor-insertedTextForeground);
      border-left: 3px solid var(--vscode-diffEditor-insertedTextBorder);
    }

    .diff-line.unchanged {
      background: transparent;
      color: var(--vscode-foreground);
      border-left: 3px solid transparent;
    }

    /* Edit Action Buttons */
    .edit-actions {
      display: flex;
      gap: 6px;
      margin: 12px 0;
      flex-wrap: wrap;
      padding: 8px;
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-widget-border);
      border-radius: 6px;
      border-left: 3px solid var(--vscode-focusBorder);
    }

    .edit-btn {
      padding: 6px 10px;
      font-size: 9px;
      font-weight: 500;
      border: 1px solid var(--vscode-button-border);
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
      min-width: 60px;
      text-align: center;
    }

    .edit-btn.approve {
      background: var(--vscode-notifications-successIcon-foreground);
      color: white;
      border-color: var(--vscode-notifications-successIcon-foreground);
    }

    .edit-btn.approve:hover {
      background: var(--vscode-notifications-successIcon-foreground);
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .edit-btn.reject {
      background: var(--vscode-notifications-errorIcon-foreground);
      color: white;
      border-color: var(--vscode-notifications-errorIcon-foreground);
    }

    .edit-btn.reject:hover {
      background: var(--vscode-notifications-errorIcon-foreground);
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .edit-btn.copy {
      background: var(--vscode-button-secondaryBackground);
      color: var(--vscode-button-secondaryForeground);
      border-color: var(--vscode-button-border);
    }

    .edit-btn.copy:hover {
      background: var(--vscode-button-secondaryHoverBackground);
      transform: translateY(-1px);
    }

    /* Edit Status Styles */
    .edit-status {
      padding: 6px 10px;
      font-size: 9px;
      font-weight: 500;
      border-radius: 4px;
      text-align: center;
      min-width: 60px;
    }

    .edit-status.approved {
      background: var(--vscode-notifications-successIcon-foreground);
      color: white;
    }

    .edit-status.rejected {
      background: var(--vscode-notifications-errorIcon-foreground);
      color: white;
    }

    .edit-actions.approved,
    .edit-actions.rejected {
      pointer-events: none;
      opacity: 0.7;
    }

    .code-header {
      background: var(--vscode-editor-background);
      border-bottom: 1px solid var(--vscode-widget-border);
      padding: 4px 8px;
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .language-label {
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .message pre {
      background: var(--vscode-textCodeBlock-background);
      border: none;
      border-radius: 0;
      padding: 8px;
      margin: 0;
      overflow-x: auto;
      font-family: var(--vscode-editor-font-family);
      font-size: 10px;
      line-height: 1.2;
    }

    .message code {
      background: var(--vscode-textCodeBlock-background);
      border: 1px solid var(--vscode-widget-border);
      border-radius: 2px;
      padding: 1px 3px;
      font-family: var(--vscode-editor-font-family);
      font-size: 10px;
    }

    .message pre code {
      background: none;
      border: none;
      padding: 0;
      border-radius: 0;
    }

    /* Diff Code Block Styles */
    .message pre.language-diff {
      background: var(--vscode-textCodeBlock-background);
      border: 1px solid var(--vscode-focusBorder);
      border-radius: 4px;
      padding: 8px;
      margin: 6px 0;
      overflow-x: auto;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      font-size: 10px;
      line-height: 1.4;
    }

    .message pre.language-diff code {
      background: none;
      border: none;
      padding: 0;
      border-radius: 0;
      font-family: inherit;
      font-size: inherit;
      line-height: inherit;
    }

    /* Diff Line Styling */
    .message pre.language-diff .diff-line-removed {
      color: var(--vscode-diffEditor-removedTextForeground);
      background: var(--vscode-diffEditor-removedTextBackground);
      border-left: 3px solid var(--vscode-diffEditor-removedTextBorder);
      padding-left: 8px;
      margin: 1px 0;
    }

    .message pre.language-diff .diff-line-added {
      color: var(--vscode-diffEditor-insertedTextForeground);
      background: var(--vscode-diffEditor-insertedTextBackground);
      border-left: 3px solid var(--vscode-diffEditor-insertedTextBorder);
      padding-left: 8px;
      margin: 1px 0;
    }

    .message pre.language-diff .diff-line-unchanged {
      color: var(--vscode-foreground);
      padding-left: 8px;
      margin: 1px 0;
    }

    /* Copy Button */
    .copy-btn {
      position: absolute;
      top: 4px;
      right: 4px;
      background: var(--vscode-button-secondaryBackground);
      color: var(--vscode-button-secondaryForeground);
      border: 1px solid var(--vscode-button-border);
      border-radius: 3px;
      padding: 2px 4px;
      cursor: pointer;
      font-size: 8px;
      opacity: 0.8;
      transition: all 0.2s ease;
      font-weight: 500;
    }

    .copy-btn:hover {
      opacity: 1;
      background: var(--vscode-button-secondaryHoverBackground);
      transform: scale(1.05);
    }

    .copy-btn.copied {
      background: var(--vscode-notifications-successIcon-foreground);
      color: white;
      border-color: var(--vscode-notifications-successIcon-foreground);
    }

         /* Input Container */
     .input-container { 
       display: flex; 
       flex-direction: column;
       gap: 0; 
       align-items: stretch;
       border: 1px solid var(--vscode-input-border);
       border-radius: 8px;
       background: var(--vscode-input-background);
       overflow: visible;
       transition: all 0.2s ease;
       position: relative;
     }

     .input-container:focus-within {
       border-color: var(--vscode-focusBorder);
       box-shadow: 0 0 0 2px var(--vscode-focusBorder);
     }

           /* Top Row - Main Input Area */
      .input-top-row {
        display: flex;
        gap: 0;
        align-items: stretch;
        flex: 1;
      }

           /* Bottom Row - Mode Dropdown and Buttons */
     .input-bottom-row {
       display: flex;
       justify-content: space-between;
       align-items: center;
       padding: 4px 8px;
       border-top: 1px solid var(--vscode-input-border);
       background: var(--vscode-input-background);
       gap: 8px;
     }

           /* Mode Dropdown */
     .mode-dropdown-container {
       flex-shrink: 0;
       margin-right: auto;
     }

      .mode-dropdown {
        padding: 4px 8px;
        font-size: 9px;
        border: none;
        background: transparent;
        color: var(--vscode-input-foreground);
        cursor: pointer;
        min-width: 70px;
        font-family: inherit;
        border-radius: 3px;
      }

      .mode-dropdown:focus {
        outline: none;
        background: var(--vscode-list-hoverBackground);
      }

      .mode-dropdown option {
        padding: 4px 8px;
        font-size: 9px;
      }

         textarea {
       flex: 1; 
       padding: 8px 10px; 
       border: none;
       border-radius: 0; 
       background: transparent;
       color: var(--vscode-input-foreground); 
       font-size: 10px;
       resize: vertical; 
       min-height: 48px;
       max-height: 120px;
       font-family: inherit;
       line-height: 1.2;
       transition: all 0.2s ease;
       border-right: 1px solid var(--vscode-input-border);
     }

     textarea:focus {
       outline: none;
       background: var(--vscode-input-background);
     }

    textarea::placeholder {
      color: var(--vscode-input-placeholderForeground);
    }

         button {
       padding: 6px 10px; 
       background: var(--vscode-button-background);
       color: var(--vscode-button-foreground); 
       border: 1px solid var(--vscode-button-border);
       border-radius: 4px; 
       cursor: pointer; 
       font-size: 10px;
       font-weight: 500;
       transition: all 0.2s ease;
       white-space: nowrap;
       min-width: 50px;
     }

     button:hover {
       background: var(--vscode-button-hoverBackground);
       transform: translateY(-1px);
       box-shadow: 0 2px 6px rgba(0,0,0,0.15);
     }

     button:active {
       transform: translateY(0);
     }

     /* Send/Stop Button */
     .send-btn {
       display: flex;
       align-items: center;
       justify-content: center;
       min-width: 32px;
       height: 28px;
       border: none;
       border-radius: 3px;
       background: var(--vscode-button-background);
       color: var(--vscode-button-foreground);
       margin: 0;
       padding: 6px 8px;
       flex-shrink: 0;
     }

     .send-btn:hover {
       background: var(--vscode-button-hoverBackground);
       transform: none;
       box-shadow: none;
     }

     .send-btn.sending {
       background: var(--vscode-errorForeground);
       color: white;
       border-color: var(--vscode-errorForeground);
     }

     .send-btn.sending:hover {
       background: var(--vscode-errorForeground);
       opacity: 0.8;
       transform: none;
       box-shadow: none;
     }

           .send-icon, .stop-icon {
        font-size: 14px;
      }

    /* Emoji and Status Icons */
    .emoji {
      font-size: 12px;
      vertical-align: middle;
      margin: 0 1px;
    }

    .status-indicator {
      display: inline-block;
      width: 6px;
      height: 6px;
      border-radius: 50%;
      margin-right: 4px;
      background: var(--vscode-descriptionForeground);
    }

    .status-indicator.active {
      background: var(--vscode-notifications-successIcon-foreground);
    }

    .status-indicator.error {
      background: var(--vscode-notifications-errorIcon-foreground);
    }

    /* Responsive Design */
    @media (max-width: 300px) {
      .mode-selector {
        flex-direction: column;
        align-items: stretch;
      }
      
      .mode-btn {
        min-width: auto;
        max-width: none;
      }
      
      .menu-container {
        margin-left: 0;
        margin-top: 4px;
        justify-content: center;
      }
    }

    /* Loading States */
    .loading {
      opacity: 0.6;
      pointer-events: none;
    }

    .loading::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 14px;
      height: 14px;
      margin: -7px 0 0 -7px;
      border: 2px solid var(--vscode-focusBorder);
      border-top: 2px solid transparent;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    /* Welcome Message */
    .welcome-message {
      text-align: center;
      padding: 16px 8px;
      color: var(--vscode-descriptionForeground);
    }

    .welcome-icon {
      font-size: 24px;
      margin-bottom: 8px;
      opacity: 0.7;
    }

    .welcome-title {
      font-size: 12px;
      font-weight: 600;
      color: var(--vscode-foreground);
      margin-bottom: 4px;
    }

    .welcome-subtitle {
      font-size: 10px;
      line-height: 1.3;
      margin-bottom: 12px;
    }

    .welcome-features {
      display: grid;
      grid-template-columns: 1fr;
      gap: 6px;
      margin-top: 12px;
    }

    .feature-card {
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-widget-border);
      border-radius: 4px;
      padding: 8px;
      text-align: left;
      border-left: 2px solid var(--vscode-focusBorder);
    }

    .feature-icon {
      font-size: 14px;
      margin-bottom: 4px;
      color: var(--vscode-focusBorder);
    }

    .feature-title {
      font-size: 10px;
      font-weight: 600;
      color: var(--vscode-foreground);
      margin-bottom: 2px;
    }

    .feature-desc {
      font-size: 9px;
      color: var(--vscode-descriptionForeground);
      line-height: 1.2;
    }
  </style>
</head>
<body>
  <div class="container">    

    
         <!-- Edit Mode Options -->
     <div class="edit-options" id="edit-options">
       <div class="edit-options-header" id="edit-options-header">
         <div class="edit-options-title">Edit Options</div>
         <div class="edit-options-toggle collapsed">▶</div>
       </div>
                <div class="edit-options-content collapsed" id="edit-options-content">
           <div class="checkbox-row">
             <input type="checkbox" id="show-diff" checked>
             <label for="show-diff">📊 Show diff preview</label>
           </div>
           <div class="checkbox-row">
             <input type="checkbox" id="selection-only">
             <label for="selection-only">🎯 Selection only</label>
           </div>
           <div class="checkbox-row">
             <input type="checkbox" id="auto-apply">
             <label for="auto-apply">⚡ Auto-apply (skip confirmation)</label>
           </div>
         </div>
     </div>
    
    <div class="messages" id="messages">
      <div class="welcome-message">
        <div class="welcome-icon">🚀</div>
        <div class="welcome-title">Welcome to KP AI Assistant</div>
        <div class="welcome-subtitle">Ready to help with your coding tasks</div>
        <div class="welcome-features">
          <div class="feature-card">
            <div class="feature-icon">💡</div>
            <div class="feature-title">Smart Code Analysis</div>
            <div class="feature-desc">Understand and explain complex code</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🔧</div>
            <div class="feature-title">Code Refactoring</div>
            <div class="feature-desc">Improve code quality automatically</div>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🤖</div>
            <div class="feature-title">AI Agent</div>
            <div class="feature-desc">Execute multi-step tasks</div>
          </div>
        </div>
      </div>
    </div>
    
         <div class="input-container">
       <div class="input-top-row">
         <textarea id="input" placeholder="Type your message..." rows="3"></textarea>
       </div>
       <div class="input-bottom-row">
         <div class="mode-dropdown-container">
           <select id="mode-select" class="mode-dropdown">
             <option value="ask">💬 Ask</option>
             <option value="edit">✏️ Edit</option>
             <option value="agent">🤖 Agent</option>
           </select>
         </div>
         <button class="menu-btn" id="menu-btn" title="More options">
           <span class="menu-btn-icon">⋮</span>
         </button>
         <div class="dropdown-menu" id="dropdown-menu">
           <button class="menu-item" id="settings-btn">
             <span class="menu-item-icon">⚙️</span>
             Settings
           </button>
           <button class="menu-item" id="clear-btn">
             <span class="menu-item-icon">🗑️</span>
             Clear History
           </button>
         </div>
         <button id="send-btn" class="send-btn" title="Send message">
           <span class="send-icon">📤</span>
         </button>
       </div>
     </div>
  </div>

  <script>
         const vscode = acquireVsCodeApi();
     let currentMode = vscode.getState()?.currentMode || 'ask';
     let chatHistory = vscode.getState()?.chatHistory || [];
    
         // Restore chat history and mode when webview loads
     function restoreHistory() {
       const messagesDiv = document.getElementById('messages');
       if (chatHistory.length === 0) {
         // Keep the default welcome message
         return;
       } else {
         // Clear and restore from history
         messagesDiv.innerHTML = '';
         chatHistory.forEach(function(msg) {
           addMessage(msg.type, msg.content);
         });
         messagesDiv.lastElementChild?.scrollIntoView();
       }
       
       // Restore selected mode
       const modeSelect = document.getElementById('mode-select');
       if (modeSelect) {
         modeSelect.value = currentMode;
       }
       
       // Show/hide edit options panel based on restored mode
       const editOptions = document.getElementById('edit-options');
       if (editOptions) {
         editOptions.classList.toggle('active', currentMode === 'edit');
       }
       
       // Update placeholder text based on restored mode
       const input = document.getElementById('input');
       if (input) {
         switch(currentMode) {
           case 'ask':
             input.placeholder = 'Ask me anything about coding...';
             break;
           case 'edit':
             input.placeholder = 'Describe how to edit your code...';
             break;
           case 'agent':
             input.placeholder = 'Describe the task to execute...';
             break;
         }
       }
     }

                   function selectMode(mode) {
        try {
          console.log('KP AI: Selecting mode:', mode);
          currentMode = mode;
          
          // Save mode to persistent storage
          vscode.setState({ 
            chatHistory: chatHistory,
            currentMode: currentMode 
          });
          
          // Update dropdown selection
          const modeSelect = document.getElementById('mode-select');
          if (modeSelect) {
            modeSelect.value = mode;
          }
          
          // Show/hide edit options panel
          const editOptions = document.getElementById('edit-options');
          if (editOptions) {
            editOptions.classList.toggle('active', mode === 'edit');
          }
          
          // Update placeholder text
          const input = document.getElementById('input');
          if (input) {
            switch(mode) {
              case 'ask':
                input.placeholder = 'Ask me anything about coding...';
                break;
              case 'edit':
                input.placeholder = 'Describe how to edit your code...';
                break;
              case 'agent':
                input.placeholder = 'Describe the task to execute...';
                break;
            }
          }
          console.log('KP AI: Mode selection complete');
        } catch (error) {
          console.error('KP AI: Error in selectMode:', error);
        }
      }
    
    function openSettings() {
      vscode.postMessage({ type: 'openSettings' });
    }
    
         function clearHistory() {
       vscode.postMessage({ type: 'clearHistory' });
       chatHistory = [];
       vscode.setState({ 
         chatHistory: chatHistory,
         currentMode: currentMode 
       });
       
       // Clear messages - the extension will add the "History cleared" message
       const messages = document.getElementById('messages');
       if (messages) {
         messages.innerHTML = '';
       }
     }

    function toggleMenu() {
      const dropdown = document.getElementById('dropdown-menu');
      if (dropdown) {
        dropdown.classList.toggle('active');
      }
    }

         function closeMenu() {
       const dropdown = document.getElementById('dropdown-menu');
       if (dropdown) {
         dropdown.classList.remove('active');
       }
     }

     function toggleEditOptions() {
       const content = document.getElementById('edit-options-content');
       const toggle = document.querySelector('.edit-options-toggle');
       
       if (content && toggle) {
         const isCollapsed = content.classList.contains('collapsed');
         
         if (isCollapsed) {
           // Expand
           content.classList.remove('collapsed');
           toggle.classList.remove('collapsed');
           toggle.textContent = '▼';
         } else {
           // Collapse
           content.classList.add('collapsed');
           toggle.classList.add('collapsed');
           toggle.textContent = '▶';
         }
       }
     }
    
         function setSendButtonState(isSending) {
       const sendBtn = document.getElementById('send-btn');
       if (!sendBtn) return;
       
       if (isSending) {
         sendBtn.classList.add('sending');
         sendBtn.innerHTML = '<span class="stop-icon">⏹️</span>';
         sendBtn.title = 'Stop current request';
       } else {
         sendBtn.classList.remove('sending');
         sendBtn.innerHTML = '<span class="send-icon">📤</span>';
         sendBtn.title = 'Send message';
       }
     }

     function send() {
       try {
         console.log('KP AI: Send function called');
         const input = document.getElementById('input');
         if (!input) {
           console.error('KP AI: Input element not found');
           return;
         }
         
         const message = input.value.trim();
         if (!message) return;
         
         // Check if already sending
         const sendBtn = document.getElementById('send-btn');
         if (sendBtn && sendBtn.classList.contains('sending')) {
           // Stop the current request
           vscode.postMessage({ type: 'stopRequest' });
           setSendButtonState(false);
           return;
         }
         
         // Set button to sending state
         setSendButtonState(true);
         
         // Add user message
         addMessage('user', message);
         input.value = '';
         input.style.height = 'auto';
         
         // Get edit options if in edit mode
         let editOptions = {};
         if (currentMode === 'edit') {
           const showDiff = document.getElementById('show-diff');
           const selectionOnly = document.getElementById('selection-only');
           const autoApply = document.getElementById('auto-apply');
           
           editOptions = {
             showDiff: showDiff ? showDiff.checked : true,
             selectionOnly: selectionOnly ? selectionOnly.checked : false,
             autoApply: autoApply ? autoApply.checked : false
           };
         }
         
         // Send to extension with current mode and options
         vscode.postMessage({ 
           type: 'send', 
           message: message,
           mode: currentMode,
           editOptions: editOptions
         });
         console.log('KP AI: Message sent successfully');
       } catch (error) {
         console.error('KP AI: Error in send function:', error);
       }
     }
    
    function addMessage(type, content) {
      try {
        console.log('KP AI: Adding message:', type, content.substring(0, 50));
        const messages = document.getElementById('messages');
        if (!messages) {
          console.error('KP AI: Messages element not found');
          return;
        }
        
        // Remove welcome message if it exists
        const welcomeMessage = messages.querySelector('.welcome-message');
        if (welcomeMessage) {
          welcomeMessage.remove();
        }
        
        const div = document.createElement('div');
        div.className = 'message ' + type;
        
        // Create header
        const header = document.createElement('strong');
        header.textContent = type === 'user' ? 'You' : 'KP AI';
        div.appendChild(header);
        
        // Create content container
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        // Format content based on type and content
        const formattedContent = formatMessageContent(content);
        contentDiv.innerHTML = formattedContent;
        
        div.appendChild(contentDiv);
        messages.appendChild(div);
        div.scrollIntoView({ behavior: 'smooth' });
        
        // Add copy buttons to code blocks
        addCopyButtons(div);
        
                 // Save to history (only save user and AI messages, not system messages like "history cleared")
         if (type === 'user' || (type === 'ai' && !content.includes('Conversation history cleared'))) {
           chatHistory.push({ type, content });
           vscode.setState({ 
             chatHistory: chatHistory,
             currentMode: currentMode 
           });
         }
        
        // Delegate clicks for diff links
        try {
          div.querySelectorAll('a[data-open-diff]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
              e.preventDefault();
              const editId = anchor.getAttribute('data-open-diff');
              const payload = anchor.getAttribute('data-edit-payload');
              if (editId) {
                vscode.postMessage({ type: 'openDiff', editId: editId, payload: payload });
              }
            });
          });

          // Delegate clicks for approval buttons
          div.querySelectorAll('[data-approve-id] .edit-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
              e.preventDefault();
              const container = btn.closest('[data-approve-id]');
              const decision = btn.getAttribute('data-approve');
              const editId = container ? container.getAttribute('data-approve-id') : null;
              if (editId && (decision === 'yes' || decision === 'no')) {
                vscode.postMessage({ type: 'approvalDecision', editId: editId, approved: decision === 'yes' });
                // Replace buttons with a status label
                if (container) {
                  container.innerHTML = '<span class="edit-status ' + (decision === 'yes' ? 'approved' : 'rejected') + '\">' + (decision === 'yes' ? '✅ Approved' : '🚫 Rejected') + '</span>';
                }
              }
            });
          });
        } catch (err) {
          console.error('KP AI: failed to wire diff link click', err);
        }
        console.log('KP AI: Message added successfully');
      } catch (error) {
        console.error('KP AI: Error in addMessage function:', error);
      }
    }
    
    function formatMessageContent(content) {
      // 1) Extract code blocks first and replace with safe placeholders
      const codeBlocks = [];
      content = content.replace(/\`\`\`(\w+)?\n?([\s\S]*?)\`\`\`/g, function(match, language, code) {
        const lang = language || 'text';
        const normalized = (code || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
        
        let html;
        if (lang === 'diff') {
          // Special handling for diff blocks
          const lines = normalized.split('\n');
          let diffHtml = '<div class="code-block"><div class="code-header"><span class="language-label">' + lang + '</span></div><pre class="language-diff"><code>';
          
          lines.forEach(function(line) {
            if (line.startsWith('- ')) {
              diffHtml += '<div class="diff-line-removed">' + escapeHtml(line) + '</div>';
            } else if (line.startsWith('+ ')) {
              diffHtml += '<div class="diff-line-added">' + escapeHtml(line) + '</div>';
            } else if (line.startsWith('  ')) {
              diffHtml += '<div class="diff-line-unchanged">' + escapeHtml(line) + '</div>';
            } else {
              diffHtml += '<div>' + escapeHtml(line) + '</div>';
            }
          });
          
          diffHtml += '</code></pre></div>';
          html = diffHtml;
        } else {
          html = '<div class="code-block"><div class="code-header"><span class="language-label">' + lang + '</span></div><pre><code class="language-' + lang + '">' + escapeHtml(normalized) + '</code></pre></div>';
        }
        
        const token = '\u0001CB' + codeBlocks.length + '\u0001';
        codeBlocks.push({ token: token, html: html });
        return token;
      });

      // 2) Extract diff blocks and replace with safe placeholders
      const diffBlocks = [];
      content = content.replace(/(\-\-\-[\s\S]*?\+\+\+[\s\S]*?)(?=\n|$)/g, function(match, diff) {
        const normalized = diff.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
        const html = '<div class="diff-block"><div class="diff-header"><span class="diff-label">📊 Diff Changes</span></div><pre class="diff-content">' + escapeHtml(normalized) + '</pre></div>';
        const token = '\u0002DB' + diffBlocks.length + '\u0002';
        diffBlocks.push({ token: token, html: html });
        return token;
      });

      // 2) Inline code
      content = content.replace(/\`([^\`]+)\`/g, '<code>$1</code>');

      // 3) Emphasis and strong
      content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      content = content.replace(/__(.*?)__/g, '<strong>$1</strong>');
      content = content.replace(/\*(.*?)\*/g, '<em>$1</em>');
      content = content.replace(/_(.*?)_/g, '<em>$1</em>');

      // 4) Lists
      content = content.replace(/^\* (.+)$/gm, '<li>$1</li>');
      content = content.replace(/^- (.+)$/gm, '<li>$1</li>');
      content = content.replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>');
      content = content.replace(/(?:\s*<li>.*?<\/li>\s*)+/g, function(m) { return '<ul>' + m + '</ul>'; });

      // 5) Blockquotes
      content = content.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');

      // 6) Replace newlines with <br> (outside code/list placeholders)
      const listBlocks = [];
      content = content.replace(/<ul>[\s\S]*?<\/ul>/g, function(m) {
        const token = '\u0002LB' + listBlocks.length + '\u0002';
        listBlocks.push({ token: token, html: m });
        return token;
      });
      content = content.replace(/\n/g, '<br>');
      listBlocks.forEach(function(item) {
        content = content.split(item.token).join(item.html);
      });
      codeBlocks.forEach(function(item) {
        content = content.split(item.token).join(item.html);
      });
      diffBlocks.forEach(function(item) {
        content = content.split(item.token).join(item.html);
      });

      // 7) Emojis and symbols
      content = content.replace(/(✅|❌|⚠️|🚫|📋|🤖|💬|✏️|🗑️|⚙️|🔧|📤|📨|🚀|💡)/g, '<span class="emoji">$1</span>');

      return content;
    }
    
    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }
    
    function addCopyButtons(messageDiv) {
      const codeBlocks = messageDiv.querySelectorAll('.code-block');
      codeBlocks.forEach(function(block) {
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.textContent = 'Copy';
        copyBtn.onclick = function() {
          const codeEl = block.querySelector('code');
          const code = codeEl ? codeEl.textContent : '';
          let normalizedCode = code.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
          normalizedCode = normalizedCode.replace(/^\n+/, '').replace(/\n+$/, '');
          
          navigator.clipboard.writeText(normalizedCode).then(function() {
            copyBtn.textContent = 'Copied!';
            copyBtn.classList.add('copied');
            setTimeout(function() {
              copyBtn.textContent = 'Copy';
              copyBtn.classList.remove('copied');
            }, 2000);
          });
        };
        block.appendChild(copyBtn);
      });
    }

    // Edit action functions
    function approveEdit(editId) {
      console.log('KP AI: Approving edit:', editId);
      vscode.postMessage({ 
        type: 'editAction', 
        action: 'approve', 
        editId: editId 
      });
      
      // Update button state
      const actionDiv = document.querySelector('[data-edit-id="' + editId + '"]');
      if (actionDiv) {
        actionDiv.innerHTML = '<span class="edit-status approved">✅ Changes Applied</span>';
        actionDiv.classList.add('approved');
      }
    }

    function rejectEdit(editId) {
      console.log('KP AI: Rejecting edit:', editId);
      vscode.postMessage({ 
        type: 'editAction', 
        action: 'reject', 
        editId: editId 
      });
      
      // Update button state
      const actionDiv = document.querySelector('[data-edit-id="' + editId + '"]');
      if (actionDiv) {
        actionDiv.innerHTML = '<span class="edit-status rejected">🚫 Changes Rejected</span>';
        actionDiv.classList.add('rejected');
      }
    }

    function copyEditCode(editId) {
      console.log('KP AI: Copying edit code:', editId);
      vscode.postMessage({ 
        type: 'editAction', 
        action: 'copy', 
        editId: editId 
      });
      
      // Update button state temporarily
      const actionDiv = document.querySelector('[data-edit-id="' + editId + '"]');
      if (actionDiv) {
        const copyBtn = actionDiv.querySelector('.edit-btn.copy');
        if (copyBtn) {
          const originalText = copyBtn.textContent;
          copyBtn.textContent = '📋 Copied!';
          copyBtn.classList.add('copied');
          setTimeout(function() {
            copyBtn.textContent = originalText;
            copyBtn.classList.remove('copied');
          }, 2000);
        }
      }
    }
    
    function setupEventListeners() {
      try {
        console.log('KP AI: Setting up event listeners');
        
        // Handle Enter key
        const input = document.getElementById('input');
        if (input) {
          input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          });
          
          // Auto-resize textarea
          input.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
          });
        } else {
          console.error('KP AI: Input element not found for event listener');
        }
        
        // Handle send button
        const sendBtn = document.getElementById('send-btn');
        if (sendBtn) {
          sendBtn.addEventListener('click', send);
        } else {
          console.error('KP AI: Send button not found');
        }
        
                 // Handle mode dropdown
         const modeSelect = document.getElementById('mode-select');
         if (modeSelect) {
           modeSelect.addEventListener('change', (e) => selectMode(e.target.value));
         }
        
                 // Handle menu button
         const menuBtn = document.getElementById('menu-btn');
         if (menuBtn) {
           menuBtn.addEventListener('click', toggleMenu);
         }

         // Handle edit options toggle
         const editOptionsHeader = document.getElementById('edit-options-header');
         if (editOptionsHeader) {
           editOptionsHeader.addEventListener('click', toggleEditOptions);
         }

        // Handle menu items
        const settingsBtn = document.getElementById('settings-btn');
        const clearBtn = document.getElementById('clear-btn');
        
        if (settingsBtn) {
          settingsBtn.addEventListener('click', () => {
            openSettings();
            closeMenu();
          });
        }
        if (clearBtn) {
          clearBtn.addEventListener('click', () => {
            clearHistory();
            closeMenu();
          });
        }
        
        // Stop button functionality
        const stopBtn = document.getElementById('stop-btn');
        if (stopBtn) {
          stopBtn.addEventListener('click', () => {
            vscode.postMessage({ type: 'stopAgent' });
            stopBtn.style.display = 'none';
          });
        }

        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
          const menuContainer = document.querySelector('.menu-container');
          if (menuContainer && !menuContainer.contains(event.target)) {
            closeMenu();
          }
        });
        
        console.log('KP AI: Event listeners setup complete');
      } catch (error) {
        console.error('KP AI: Error in setupEventListeners function:', error);
      }
    }
    
         // Initialize when DOM is ready
     function initialize() {
       try {
         console.log('KP AI: Initializing application');
         restoreHistory();
         setupEventListeners();
         addMessageListener(); // Add message listener only once
         selectMode(currentMode); // Use the restored mode instead of hardcoded 'ask'
         vscode.postMessage({ type: 'ready' });
         console.log('KP AI: Initialization complete');
       } catch (error) {
         console.error('KP AI: Error in initialize function:', error);
       }
     }
    
    // Track processed messages to prevent duplicates
    const processedMessages = new Set();
    
    // Ensure only one message listener is active
    let messageListenerAdded = false;
    
    function addMessageListener() {
      if (messageListenerAdded) {
        console.log('KP AI: Message listener already added, skipping');
        return;
      }
      
      messageListenerAdded = true;
      console.log('KP AI: Adding message listener');
      
      // Listen for messages from extension
      window.addEventListener('message', event => {
                const message = event.data;
        console.log('KP AI: Received message from extension:', message.type, message.name || message.content?.substring(0, 50));
      
      if (message.type === 'response') {
        // Create a unique identifier for this message
        const messageId = message.id || (message.type + '_' + Date.now() + '_' + Math.random());
        const contentHash = message.content ? message.content.substring(0, 50) : '';
        
        // Check if we've already processed this exact message
        if (processedMessages.has(messageId) || processedMessages.has(contentHash)) {
          console.log('KP AI: Duplicate message detected, skipping:', contentHash);
          return;
        }
        
        // Mark this message as processed
        processedMessages.add(messageId);
        processedMessages.add(contentHash);
        
        // Clean up old processed messages (keep only last 50)
        if (processedMessages.size > 50) {
          const entries = Array.from(processedMessages);
          entries.slice(0, 25).forEach(entry => processedMessages.delete(entry));
        }
        
        addMessage('ai', message.content);
      } else if (message.type === 'hideStopButton') {
        const stopBtn = document.getElementById('stop-btn');
        if (stopBtn) {
          stopBtn.style.display = 'none';
        }
        return;
      } else if (message.type === 'showStopButton') {
        const stopBtn = document.getElementById('stop-btn');
        if (stopBtn) {
          stopBtn.style.display = 'flex';
        }
        return;
             } else if (message.type === 'clearMessages') {
         chatHistory = [];
         vscode.setState({ 
           chatHistory: chatHistory,
           currentMode: currentMode 
         });
         processedMessages.clear(); // Clear processed messages too
         restoreHistory();
      } else if (message.type === 'provider') {
        console.log('KP AI: Received provider info:', message.name);
        // Update provider info in the UI if needed
        const providerElement = document.getElementById('provider-info');
        if (providerElement) {
          providerElement.textContent = message.name;
        }
             } else if (message.type === 'model') {
         console.log('KP AI: Received model info:', message.name);
         // Update model info in the UI if needed
         const modelElement = document.getElementById('model-info');
         if (modelElement) {
           modelElement.textContent = message.name;
         }
       } else if (message.type === 'responseComplete') {
         // Reset send button to normal state when response is complete
         setSendButtonState(false);
       } else if (message.type === 'requestStopped') {
         // Reset send button to normal state when request is stopped
         setSendButtonState(false);
       }
    });
    }
    
    // Initialize when page loads (only once)
    let initialized = false;
    function safeInitialize() {
      if (!initialized) {
        initialized = true;
        initialize();
      }
    }
    
    window.onload = safeInitialize;
    document.addEventListener('DOMContentLoaded', function() {
      console.log('KP AI: DOM Content Loaded');
      safeInitialize();
    });
  </script>
</body>
</html>`;
  }

  private _sendInitialDataWithRetry(webviewView: vscode.WebviewView, retryCount: number = 0): void {
    const maxRetries = 5;
    const retryDelay = 200;
    
    try {
      console.log(`🔍 _sendInitialDataWithRetry: Attempt ${retryCount + 1}/${maxRetries + 1}`);
      
      // Check if ProviderManager is ready
      if (!this.providerManager) {
        console.error('❌ ProviderManager is not initialized');
        if (retryCount < maxRetries) {
          setTimeout(() => this._sendInitialDataWithRetry(webviewView, retryCount + 1), retryDelay);
        }
        return;
      }
      
      // Force reload settings from VS Code configuration
      try {
        const config = vscode.workspace.getConfiguration('kpAiCodingAssistant');
        const savedProvider = config.get<string>('currentProvider');
        const savedModel = config.get<string>('currentModel');
        console.log('🔍 _sendInitialDataWithRetry: VS Code config - provider:', savedProvider, 'model:', savedModel);
        
        // Force ProviderManager to reload settings
        if (this.providerManager && typeof (this.providerManager as any).forceReloadSettings === 'function') {
          (this.providerManager as any).forceReloadSettings();
        }
      } catch (configError) {
        console.log('🔍 _sendInitialDataWithRetry: Could not read VS Code config:', configError);
      }
      
      // Send provider info
      const provider = this.providerManager.getCurrentProvider();
      console.log('🔍 _sendInitialDataWithRetry: provider =', provider);
      
      if (!provider) {
        console.error('❌ No current provider found');
        if (retryCount < maxRetries) {
          setTimeout(() => this._sendInitialDataWithRetry(webviewView, retryCount + 1), retryDelay);
        }
        return;
      }
      
      const providerData = this.providerManager.getProvider(provider);
      console.log('🔍 _sendInitialDataWithRetry: providerData =', providerData);
      
      const providerMessage = {
        type: 'provider',
        name: providerData?.displayName || provider
      };
      console.log('🔍 _sendInitialDataWithRetry: Sending provider message:', providerMessage);
      webviewView.webview.postMessage(providerMessage);

      // Send model info
      const model = this.providerManager.getCurrentModel();
      console.log('🔍 _sendInitialDataWithRetry: model =', model);
      
      if (!model) {
        console.error('❌ No current model found');
        if (retryCount < maxRetries) {
          setTimeout(() => this._sendInitialDataWithRetry(webviewView, retryCount + 1), retryDelay);
        }
        return;
      }
      
      const modelMessage = {
        type: 'model',
        name: model
      };
      console.log('🔍 _sendInitialDataWithRetry: Sending model message:', modelMessage);
      webviewView.webview.postMessage(modelMessage);
      
      console.log('🔍 _sendInitialDataWithRetry: Initial data sent successfully');
    } catch (error) {
      console.error('❌ Error sending initial data:', error);
      if (retryCount < maxRetries) {
        setTimeout(() => this._sendInitialDataWithRetry(webviewView, retryCount + 1), retryDelay);
      }
    }
  }

  private _sendInitialData(webviewView: vscode.WebviewView): void {
    try {
      console.log('🔍 _sendInitialData: Starting to send initial data');
      
      // Check if ProviderManager is ready
      if (!this.providerManager) {
        console.error('❌ ProviderManager is not initialized');
        return;
      }
      
      // Send provider info
      const provider = this.providerManager.getCurrentProvider();
      console.log('🔍 _sendInitialData: provider =', provider);
      
      if (!provider) {
        console.error('❌ No current provider found');
        return;
      }
      
      const providerData = this.providerManager.getProvider(provider);
      console.log('🔍 _sendInitialData: providerData =', providerData);
      
      const providerMessage = {
        type: 'provider',
        name: providerData?.displayName || provider
      };
      console.log('🔍 _sendInitialData: Sending provider message:', providerMessage);
      webviewView.webview.postMessage(providerMessage);

      // Send model info
      const model = this.providerManager.getCurrentModel();
      console.log('🔍 _sendInitialData: model =', model);
      
      if (!model) {
        console.error('❌ No current model found');
        return;
      }
      
      const modelMessage = {
        type: 'model',
        name: model
      };
      console.log('🔍 _sendInitialData: Sending model message:', modelMessage);
      webviewView.webview.postMessage(modelMessage);
      
      console.log('🔍 _sendInitialData: Initial data sent successfully');
    } catch (error) {
      console.error('❌ Error sending initial data:', error);
    }
  }

  private _getPrettyPath(fullPath: string): string {
    try {
      const ws = vscode.workspace.workspaceFolders?.[0];
      if (ws && fullPath.startsWith(ws.uri.fsPath)) {
        const rel = fullPath.substring(ws.uri.fsPath.length + 1).replace(/\\/g, '/');
        return rel;
      }
      return path.basename(fullPath);
    } catch {
      return path.basename(fullPath || '');
    }
  }

  private async _openEditDiff(editId: string, payloadB64?: string): Promise<void> {
    let info = this._storedEdits.get(editId);
    if (!info && payloadB64) {
      try {
        const json = Buffer.from(payloadB64, 'base64').toString('utf-8');
        const parsed = JSON.parse(json);
        info = {
          id: parsed.editId,
          documentUri: parsed.documentUri ? vscode.Uri.parse(parsed.documentUri) : undefined,
          selectionRange: new vscode.Range(
            new vscode.Position(parsed.selectionRange.start.line, parsed.selectionRange.start.character),
            new vscode.Position(parsed.selectionRange.end.line, parsed.selectionRange.end.character)
          ),
          originalText: parsed.originalText,
          newText: parsed.newText,
          useSelection: parsed.useSelection,
          fileName: parsed.fileName,
          timestamp: parsed.timestamp
        };
        // Cache it briefly again
        this._storedEdits.set(editId, info);
        this._scheduleEditCleanup(editId, 2 * 60 * 1000);
      } catch (e) {
        console.error('KP AI: Failed to parse diff payload', e);
      }
    }
    if (!info) {
      vscode.window.showWarningMessage('KP AI: Edit information not found for diff');
      return;
    }

    try {
      // Try to open the real document if we have a resolvable URI
      let document: vscode.TextDocument | undefined;
      let editor: vscode.TextEditor | undefined;
      if (info.documentUri) {
        try {
          document = await vscode.workspace.openTextDocument(info.documentUri);
          editor = await vscode.window.showTextDocument(document, vscode.ViewColumn.One, true);
        } catch {
          // Document couldn’t be opened; continue with virtual diff only
        }
      }

      // Ensure our virtual content provider is registered
      ensureDiffContentProvider();

  const base = document ? path.basename(document.fileName) : (info.fileName ? path.basename(info.fileName) : 'changes');
  const lang = document ? document.languageId : '';

      const leftData = encodeURIComponent(Buffer.from(info.originalText, 'utf-8').toString('base64'));
      const rightData = encodeURIComponent(Buffer.from(info.newText, 'utf-8').toString('base64'));

  const leftUri = vscode.Uri.parse(`${DIFF_SCHEME}:${base} (original)?data=${leftData}&lang=${encodeURIComponent(lang)}`);
  const rightUri = vscode.Uri.parse(`${DIFF_SCHEME}:${base} (proposed)?data=${rightData}&lang=${encodeURIComponent(lang)}`);

      const title = `${base} (original) ↔ proposed changes`;
      await vscode.commands.executeCommand('vscode.diff', leftUri, rightUri, title);

      // Also show inline diff via our DiffManager if we have an editor
      if (editor) {
        const diff = await this.diffManager.createDiff(info.originalText, info.newText, 'Proposed changes');
        await this.diffManager.showDiff(editor, diff);
      } else {
        vscode.window.showInformationMessage('KP AI: Opened virtual diff (target file not found)');
      }
    } catch (err) {
      vscode.window.showErrorMessage(`KP AI: Failed to open diff: ${err}`);
    }
  }

  // Content provider is now shared via utils/DiffContentProvider

  private async _clearConversation(): Promise<void> {
    try {
      await this.chatMode.startNewConversation();
      this.conversationStarted = false;

      this._view?.webview.postMessage({
        type: 'clearMessages'
      });

      this._view?.webview.postMessage({
        type: 'response',
        content: '🗑️ Conversation history cleared.',
        id: `clear_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      });
    } catch (error) {
      console.error('Error clearing conversation:', error);
    }
  }

  private _generateInlineDiff(originalText: string, newText: string): string {
    // Simple line-by-line diff generation
    const originalLines = originalText.split('\n');
    const newLines = newText.split('\n');

    let diffContent = '<div class="inline-diff">\n';
    diffContent += '<div class="diff-header">📊 Code Changes Preview</div>\n';
    diffContent += '<div class="diff-content">\n';

    // Generate a simple diff visualization
    const maxLines = Math.max(originalLines.length, newLines.length);

    for (let i = 0; i < maxLines; i++) {
      const originalLine = originalLines[i] || '';
      const newLine = newLines[i] || '';

      if (originalLine !== newLine) {
        if (originalLine) {
          diffContent += `<div class="diff-line removed">- ${this._escapeHtml(originalLine)}</div>\n`;
        }
        if (newLine) {
          diffContent += `<div class="diff-line added">+ ${this._escapeHtml(newLine)}</div>\n`;
        }
      } else {
        diffContent += `<div class="diff-line unchanged">  ${this._escapeHtml(originalLine)}</div>\n`;
      }
    }

    diffContent += '</div>\n</div>';
    return diffContent;
  }

  private _escapeHtml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  private _scheduleEditCleanup(editId: string, delayMs: number): void {
    try {
      const existing = this._cleanupTimers.get(editId);
      if (existing) {
        clearTimeout(existing);
      }
      const timer = setTimeout(() => {
        this._storedEdits.delete(editId);
        this._cleanupTimers.delete(editId);
      }, delayMs);
      this._cleanupTimers.set(editId, timer);
    } catch (err) {
      console.error('KP AI: Failed to schedule cleanup for edit', editId, err);
    }
  }

  private async _handleEditAction(action: string, editId: string): Promise<void> {
    try {
      // Get edit info from stored edits
      const editInfo = this._storedEdits.get(editId);
      if (!editInfo) {
        console.error('Edit info not found for ID:', editId);
        return;
      }

      const { documentUri, selectionRange, newText, useSelection } = editInfo;

      switch (action) {
        case 'approve':
          try {
            const edit = new vscode.WorkspaceEdit();
            if (useSelection) {
              edit.replace(documentUri, selectionRange, newText);
            } else {
              // Get the current document
              const document = await vscode.workspace.openTextDocument(documentUri);
              const fullText = document.getText();
              const fullRange = new vscode.Range(
                document.positionAt(0),
                document.positionAt(fullText.length)
              );
              edit.replace(documentUri, fullRange, newText);
            }

            const applied = await vscode.workspace.applyEdit(edit);
            if (applied) {
              // Update the message to show success
              this._view?.webview.postMessage({
                type: 'editApplied',
                editId: editId,
                success: true
              });
            } else {
              this._view?.webview.postMessage({
                type: 'editApplied',
                editId: editId,
                success: false,
                error: 'Could not apply changes'
              });
            }
          } catch (error) {
            this._view?.webview.postMessage({
              type: 'editApplied',
              editId: editId,
              success: false,
              error: error instanceof Error ? error.message : String(error)
            });
          }
          break;

        case 'reject':
          // Update the message to show rejection
          this._view?.webview.postMessage({
            type: 'editRejected',
            editId: editId
          });
          break;

        case 'copy':
          // Copy code to clipboard
          await vscode.env.clipboard.writeText(newText);
          this._view?.webview.postMessage({
            type: 'editCopied',
            editId: editId
          });
          break;
      }

  // Keep the edit info for a short grace period so the diff link still works
  this._scheduleEditCleanup(editId, 2 * 60 * 1000); // 2 minutes

    } catch (error) {
      console.error('Error handling edit action:', error);
    }
  }
}
