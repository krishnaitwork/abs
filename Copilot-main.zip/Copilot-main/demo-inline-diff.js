// Demo file for testing KP AI Assistant Inline Diff functionality
// Select any function below and use Ctrl+Shift+D to see AI improvements

function calculateSum(numbers) {
    let sum = 0;
    for (let i = 0; i < numbers.length; i++) {
        sum = sum + numbers[i];
    }
    return sum;
}

function findMaxValue(array) {
    let max = array[0];
    for (let i = 1; i < array.length; i++) {
        if (array[i] > max) {
            max = array[i];
        }
    }
    return max;
}

function filterEvenNumbers(numbers) {
    let result = [];
    for (let i = 0; i < numbers.length; i++) {
        if (numbers[i] % 2 === 0) {
            result.push(numbers[i]);
        }
    }
    return result;
}

function reverseString(str) {
    let reversed = '';
    for (let i = str.length - 1; i >= 0; i--) {
        reversed = reversed + str[i];
    }
    return reversed;
}

// Test the functions
const testNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

console.log('Sum:', calculateSum(testNumbers));
console.log('Max:', findMaxValue(testNumbers));
console.log('Even numbers:', filterEvenNumbers(testNumbers));
console.log('Reversed string:', reverseString('Hello World'));

// Instructions for testing inline diff:
// 1. Select any function above (e.g., calculateSum)
// 2. Press Ctrl+Shift+D to see AI improvements
// 3. Use F12/Shift+F12 to navigate between changes
// 4. Use Ctrl+Shift+Enter to apply all changes
// 5. Use Ctrl+Shift+Escape to reject changes
