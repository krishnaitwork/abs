# KP AI Assistant - Inline Diff Features

## Overview

The KP AI Assistant extension now includes comprehensive inline diff functionality that allows you to visualize, navigate, and apply code changes directly within the VS Code editor. This feature provides a seamless way to review AI-generated code improvements, compare different code versions, and manage changes with full control.

## Features

### 🎯 Core Diff Operations

- **Inline Diff Display**: Visual diff indicators directly in the editor
- **Gutter Indicators**: Clear visual markers in the editor gutter
- **Overview Ruler**: Quick overview of all changes in the right margin
- **Hover Information**: Detailed change information on hover
- **Change Navigation**: Easy navigation between different changes

### 🔧 Diff Management

- **AI-Generated Diffs**: Automatic diff creation from AI suggestions
- **Manual Diffs**: Compare any two code selections
- **Diff History**: Track and review previous diffs
- **Selective Application**: Apply individual changes or entire diffs
- **Diff Rejection**: Reject unwanted changes

### 🎨 Visual Customization

- **Configurable Display**: Customize what diff elements to show
- **Theme Integration**: Uses VS Code's built-in diff colors
- **Change Highlighting**: Enhanced visual indicators for different change types

## Commands

### Primary Diff Commands

| Command                                   | Description                              | Keyboard Shortcut   |
| ----------------------------------------- | ---------------------------------------- | ------------------- |
| `kpAiAssistant.showInlineDiff`            | Show AI-generated diff for selected code | `Ctrl+Shift+D`      |
| `kpAiAssistant.showDiffBetweenSelections` | Compare two code selections              | `Ctrl+Shift+=`      |
| `kpAiAssistant.applyCurrentDiff`          | Apply all changes in current diff        | `Ctrl+Shift+Enter`  |
| `kpAiAssistant.applySingleChange`         | Apply single change at cursor            | `Ctrl+Shift+.`      |
| `kpAiAssistant.rejectCurrentDiff`         | Reject all changes in current diff       | `Ctrl+Shift+Escape` |

### Navigation Commands

| Command                                  | Description           | Keyboard Shortcut |
| ---------------------------------------- | --------------------- | ----------------- |
| `kpAiAssistant.navigateToNextChange`     | Go to next change     | `F12`             |
| `kpAiAssistant.navigateToPreviousChange` | Go to previous change | `Shift+F12`       |

### History & Settings Commands

| Command                              | Description                    | Keyboard Shortcut |
| ------------------------------------ | ------------------------------ | ----------------- |
| `kpAiAssistant.showDiffHistory`      | View diff history              | None              |
| `kpAiAssistant.clearDiffHistory`     | Clear diff history             | None              |
| `kpAiAssistant.revertToPreviousDiff` | Revert to previous diff        | None              |
| `kpAiAssistant.showDiffSettings`     | Configure diff display options | None              |

## Usage Examples

### 1. AI-Generated Code Improvements

1. Select the code you want to improve
2. Press `Ctrl+Shift+D` or use the command palette
3. The AI will generate improved code and show it as an inline diff
4. Review the changes with visual indicators
5. Apply all changes with `Ctrl+Shift+Enter` or reject with `Ctrl+Shift+Escape`

### 2. Comparing Code Selections

1. Select the first code block
2. Hold `Ctrl` and select the second code block
3. Press `Ctrl+Shift+=` or use the command palette
4. View the differences between the two selections
5. Navigate between changes using `F12` and `Shift+F12`

### 3. Managing Diff History

1. Use `kpAiAssistant.showDiffHistory` to view previous diffs
2. Select any diff from history to review it again
3. Use `kpAiAssistant.revertToPreviousDiff` to go back to a previous state
4. Clear history when no longer needed

## Configuration

### Inline Diff Options

You can customize the diff display behavior through VS Code settings:

```json
{
  "kpAiCodingAssistant.inlineDiffOptions": {
    "showInline": true, // Show inline diff decorations
    "showGutter": true, // Show gutter indicators
    "showOverview": true, // Show overview ruler indicators
    "highlightChanges": true, // Enhanced change highlighting
    "autoApply": false // Auto-apply changes (not recommended)
  }
}
```

### Accessing Settings

1. Open Command Palette (`Ctrl+Shift+P`)
2. Run `KP AI: Show Diff Settings`
3. Select/deselect options as needed
4. Settings are automatically saved

## Visual Indicators

### Change Types

- **🟢 Insert**: Green background with `+` icon
- **🔴 Delete**: Red background with `-` icon
- **🔵 Replace**: Blue background with `✏️` icon

### Display Elements

- **Inline Decorations**: Background colors and borders around changed code
- **Gutter Icons**: Visual indicators in the left gutter
- **Overview Ruler**: Right margin indicators for quick navigation
- **Hover Messages**: Detailed information when hovering over changes

## Best Practices

### When to Use Inline Diffs

- **Code Reviews**: Review AI-generated improvements before applying
- **Refactoring**: Compare original and refactored code
- **Bug Fixes**: Review proposed fixes before implementation
- **Code Comparison**: Compare different approaches or versions

### Workflow Recommendations

1. **Review First**: Always review changes before applying
2. **Use Navigation**: Navigate between changes to understand the full scope
3. **Selective Application**: Consider applying changes individually for complex diffs
4. **History Management**: Keep diff history clean by clearing when no longer needed

## Troubleshooting

### Common Issues

**Diff not showing**: Ensure you have code selected and the command executed successfully
**Changes not applying**: Check if the diff is still active and the editor is in the correct state
**Visual glitches**: Try refreshing the diff or restarting VS Code

### Performance Tips

- Limit the size of code selections for better performance
- Clear diff history regularly if working with many diffs
- Use overview ruler for quick navigation in large files

## Integration with Other Features

### AI Commands

The inline diff system integrates seamlessly with other KP AI features:

- **Refactor Code**: Automatically shows diffs for refactoring suggestions
- **Fix Errors**: Displays proposed fixes as inline diffs
- **Generate Tests**: Shows differences between original and test code

### Git Integration

While primarily designed for AI-generated changes, the diff system can also work with:

- Manual code comparisons
- Code review workflows
- Before/after comparisons

## Advanced Features

### Custom Diff Sources

The system supports different diff sources:

- **AI**: Generated by AI providers
- **Manual**: Created by user selections
- **Git**: Future integration with Git diffs

### Extensibility

The diff system is designed to be extensible:

- Custom change types can be added
- Different diff algorithms can be implemented
- Integration with external diff tools is possible

## Support

For issues or feature requests related to inline diff functionality:

1. Check this documentation first
2. Review VS Code's developer console for error messages
3. Report issues through the extension's GitHub repository

---

_Inline Diff Features are part of KP AI Assistant v2.0+_
